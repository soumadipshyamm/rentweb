
export const tanentSidebar = [
    [
        {
            title: 'Dashboard',
            icon: 'Dashboard',
            to: '/dashboard',
            Children: null,
            id: 0
        },
        {
            title: 'Explore Properties',
            icon: 'mdi-view-dashboard-outline',
            to: '/explore-properties',
            Children: null,
            id: 1
        },
        {
            title: 'My Posts',
            icon: 'mdi-view-dashboard-outline',
            to: '/my-posts',
            Children: null,
            id: 2
        },
        {
            title: 'Schedule Visit',
            icon: 'mdi-view-dashboard-outline',
            to: '/schedule-visit',
            Children: null,
            id: 3
        },
        {
            title: 'Message',
            icon: 'mdi-view-dashboard-outline',
            to: '/message',
            Children: null,
            id: 4
        },
        {
            title: 'Saved Properties',
            icon: 'mdi-view-dashboard-outline',
            to: '/saved-properties',
            Children: null,
            id: 5
        }
    ],
    [
        {
            title: 'Settings',
            icon: 'mdi-view-dashboard-outline',
            to: '/settings',
            Children: null,
            id: 6,
        },
        {
            title: 'Help Center',
            icon: 'mdi-view-dashboard-outline',
            to: '/help-center',
            Children: null,
            id: 7
        },
        {
            title: 'FAQ',
            icon: 'mdi-view-dashboard-outline',
            to: '/faq',
            Children: null,
            id: 8
        },
        {
            title: 'Terms & Conditions',
            icon: 'mdi-view-dashboard-outline',
            to: '/terms-and-conditions',
            Children: null,
            id: 9
        },
        {
            title: 'Privacy Policy',
            icon: 'mdi-view-dashboard-outline',
            to: '/privacy-policy',
            Children: null,
            id: 10
        },
    ]
];

export const landLordSidebar = [
    [
        {
            title: 'Dashboard',
            icon: 'Dashboard',
            to: '/dashboard',
            Children: null,
            id: 0
        },
        {
            title: 'My Properties',
            icon: 'Properties',
            to: '/my-properties',
            Children: null,
            id: 2
        },
        {
            title: 'Find Tenant',
            icon: 'FindTenant',
            to: '/find-tanent',
            Children: null,
            id: 2
        },
        {
            title: 'Explore Properties',
            icon: 'Properties',
            to: '/explore-properties',
            Children: null,
            id: 3
        },
        {
            title: 'Schedule Visit',
            icon: 'ScheduleVisit',
            to: '/schedule-visit',
            Children: null,
            id: 4
        },
        {
            title: 'Message',
            icon: 'Message',
            to: '/message',
            Children: null,
            id: 5
        },
        {
            title: 'Saved Preference',
            icon: 'Star',
            to: '/saved-preference',
            Children: null,
            id: 6
        }
    ],
    [
        {
            title: 'Settings',
            icon: 'Settings',
            to: '/settings',
            Children: null,
            id: 6,
        },
        {
            title: 'Pricing and Plans',
            icon: 'Pricing',
            to: '/pricing-and-plans',
            Children: null,
            id: 7
        },
        {
            title: 'Help Center',
            icon: 'HelpCenetr',
            to: '/help-center',
            Children: null,
            id: 8
        },
        {
            title: 'FAQ',
            icon: 'FAQ',
            to: '/faq',
            Children: null,
            id: 9
        },
        {
            title: 'Terms & Conditions',
            icon: 'Terms',
            to: '/terms-and-conditions',
            Children: null,
            id: 10
        },
        {
            title: 'Privacy Policy',
            icon: 'Privacy',
            to: '/privacy-policy',
            Children: null,
            id: 11
        },
    ]
];

export const propertyManagerSidebar = [
    [
        {
            title: 'Dashboard',
            icon: 'Dashboard',
            to: '/dashboard',
            Children: null,
            id: 0
        },
        {
            title: 'My Properties',
            icon: 'Properties',
            to: '/my-properties',
            Children: null,
            id: 2
        },
        {
            title: 'Find Client',
            icon: 'FindTenant',
            to: '/find-client',
            Children: null,
            id: 2
        },
        {
            title: 'Explore Properties',
            icon: 'Properties',
            to: '/explore-properties',
            Children: null,
            id: 3
        },
        {
            title: 'Schedule Visit',
            icon: 'ScheduleVisit',
            to: '/schedule-visit',
            Children: null,
            id: 4
        },
        {
            title: 'Message',
            icon: 'Message',
            to: '/message',
            Children: null,
            id: 5
        },
        {
            title: 'Saved Preference',
            icon: 'Star',
            to: '/saved-preference',
            Children: null,
            id: 6
        }
    ],
    [
        {
            title: 'Settings',
            icon: 'Settings',
            to: '/settings',
            Children: null,
            id: 6,
        },
        {
            title: 'Pricing and Plans',
            icon: 'Pricing',
            to: '/pricing-and-plans',
            Children: null,
            id: 7
        },
        {
            title: 'Help Center',
            icon: 'HelpCenetr',
            to: '/help-center',
            Children: null,
            id: 8
        },
        {
            title: 'FAQ',
            icon: 'FAQ',
            to: '/faq',
            Children: null,
            id: 9
        },
        {
            title: 'Terms & Conditions',
            icon: 'Terms',
            to: '/terms-and-conditions',
            Children: null,
            id: 10
        },
        {
            title: 'Privacy Policy',
            icon: 'Privacy',
            to: '/privacy-policy',
            Children: null,
            id: 11
        },
    ]
];

export const adminSidebar = [
    [
        {
            title: 'Dashboard',
            icon: 'Dashboard',
            to: '/dashboard',
            Children: null,
            id: 0
        },
        {
            title: 'User Management',
            icon: 'UserManagement',
            to: '/admin',
            Children: [
                {
                    title: 'Admin',
                    icon: 'ArrowRight',
                    to: '/admin',
                    Children: null,
                    id: 8
                },
                {
                    title: 'member',
                    icon: 'ArrowRight',
                    to: '/member',
                    Children: null,
                    id: 9
                }
            ],
            id: 2
        },
        {
            title: 'Subscription Management',
            icon: 'SubscriptIcon',
            to: '/find-tanent',
            Children: [
                {
                    title: 'Data & Analytics',
                    icon: 'ArrowRight',
                    to: '/data-and-analytics',
                    Children: null,
                    id: 10
                },
                {
                    title: 'Plan',
                    icon: 'ArrowRight',
                    to: '/subscription/plans',
                    Children: null,
                    id: 11
                },
                {
                    title: 'All Subscriptions',
                    icon: 'ArrowRight',
                    to: '/all-subscriptions',
                    Children: null,
                    id: 12
                }
            ],
            id: 2
        },
        {
            title: 'Approval Requests',
            icon: 'Approvals',
            to: '/approval-requests',
            Children: null,
            id: 3
        },
        {
            title: 'Reports',
            icon: 'Reports',
            to: '/reports',
            Children: null,
            id: 4
        },
        {
            title: 'CMS',
            icon: 'CMS',
            to: '/cms',
            Children: [
                {
                    title: 'Property Types',
                    icon: 'ArrowRight',
                    to: '/property-type',
                    Children: null,
                    id: 8
                }
            ],
            id: 5
        },
        {
            title: 'Settings',
            icon: 'Settings',
            to: '/settings',
            Children: null,
            id: 6,
        },
        {
            title: 'Feedback & Support',
            icon: 'Feedback',
            to: '/feedback-and-support',
            Children: null,
            id: 7
        },
    ]
]
