import logo from "./images/logo.png";
import logo1 from "./images/logo1.png";
import apartment from "./images/apartment.png";
import house from "./images/house.png";
import granny_flat from "./images/granny-flat.png";
import duplex from "./images/duplex.png";
import villa from "./images/villa.png";
import office from "./images/office.png";
import object from "./images/object.png";
import dashboard_back from "./images/dashboard-back.png";
import house_icon from "./images/house-icon.png";
import villa_icon from "./images/villa-icon.png";
import office_icon from "./images/office-icon.png";
import apartment_icon from "./images/apartment-icon.png";
import discover_sets from "./images/discover-sets.png";
import right from "./images/right.png";
import quote from "./images/quote.png";
import drop_us from "./images/drop-us.png";
import youtube from "./images/youtube.png";
import instagram from "./images/instagram.png";
import pinterest from "./images/pinterest.png";
import twitter from "./images/twitter.png";
import linkedin from "./images/linkedin.png";
import facebook from "./images/facebook.png";
import apple_store from "./images/apple-store.png";
import play_store from "./images/play-store.png";
import user from "./images/user.png";
import object_slide from "./images/object-slide.png";
import star from "./images/star.png";
import beds from "./images/beds.png";
import baths from "./images/baths.png";
import sqft from "./images/sqft.png";
import villa_image from "./images/villa-image.jpg";
import user_img from "./images/user-img.png";
import up_arrow from "./images/up-arrow.png";
import login_image from "./images/login-image.png";
import home from "./images/home.png";
import edit from "./images/edit.png";
import watch from "./images/watch.png";
import save_property from "./images/save-property.png";
import preference from "./images/preference.png";
import query from "./images/query.png";
import calender from "./images/calender.png";
import message from "./images/message.png";
import connection from "./images/connection.png";
import verified from "./images/verified.png";
import fav from "./images/fav.png";
import share from "./images/share.png";
import add from "./images/add.png";
import chat from "./images/chat.png";
import property_criteria from "./images/property_criteria.png";
import search_properties from "./images/search_properties.png";
import save_favourite from "./images/save_favourite.png";
import property_owner from "./images/property_owner.png";
import search_tenents from "./images/search_tenents.png";
import rent_faster from "./images/rent_faster.png";
import dummy_img from "./images/dummy-img.png";
import location from "./images/location.png";
import real_estate from "./images/real-estate.png";
import dream_property1 from "./images/dream-property1.png";
import dream_property from "./images/dream-property.png";
import company from "./images/company.png";
import error from "./images/error.png";

export const IMAGES = {
  logo,
  logo1,
  apartment,
  house,
  granny_flat,
  duplex,
  villa,
  office,
  object,
  dashboard_back,
  house_icon,
  villa_icon,
  office_icon,
  apartment_icon,
  discover_sets,
  right,
  quote,
  drop_us,
  youtube,
  instagram,
  pinterest,
  twitter,
  linkedin,
  facebook,
  apple_store,
  play_store,
  user,
  object_slide,
  star,
  beds,
  baths,
  sqft,
  villa_image,
  user_img,
  up_arrow,
  login_image,
  home,
  edit,
  watch,
  save_property,
  preference,
  query,
  calender,
  message,
  connection,
  verified,
  fav,
  share,
  add,
  chat,
  property_criteria,
  search_properties,
  save_favourite,
  property_owner,
  search_tenents,
  rent_faster,
  dummy_img,
  location,
  real_estate,
  dream_property1,
  dream_property,
  company,
  error
};
