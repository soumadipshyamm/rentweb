import { genderDropdown, memberDropdown } from "@/src/types/memberTypes";

export const memberRoles : memberDropdown[] = [
    {
        id  : 0,
        value : "TENANT",
        title : "Tenant"
    },
    {
        id  : 1,
        value : "LANDLORD",
        title : "Landlord"
    },
    {
        id  : 2,
        value : "PROPERTY MANAGER",
        title : "Property Manager"
    }
]

export const genders : genderDropdown[] = [
    {
        id  : 0,
        value : "MALE",
        title : "Male"
    },
    {
        id  : 1,
        value : "FEMALE",
        title : "Female"
    },
    {
        id  : 2,
        value : "OTHERS",
        title : "Others"
    }
]