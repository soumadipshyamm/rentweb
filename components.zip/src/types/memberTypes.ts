export type memberType = "TENANT" | "LANDLORD" | "PROPERTY MANAGER";
export type genderType = "MALE" | "FEMALE" | "OTHERS";
export type adminType = "ADMIN" | "SUPER ADMIN";

export type memberDropdown = {
    value : memberType,
    id : number,
    title : string
}

export type genderDropdown = {
    value : genderType,
    id : number,
    title : string
}

export interface ProtectedRouteProps {
//   children: React.ReactElement;
  allowedRoles?: memberType[] | adminType[];
}