import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import NavbarSection from "./ContentMangementSystem/screens/Landing/sections/NavbarSection/NavbarSection";
import FooterSection from "./ContentMangementSystem/screens/Landing/sections/FooterSection/FooterSection";
import { IMAGES } from "../assets";
import Navbar from "./Layout/Navbar";
import Footer from "./Layout/Footer";

const AuthLayout = () => {
    const [isVisible, setIsVisible] = useState(false);
    

    useEffect(() => {
        const handleScroll = () => {
            const scrolled = window.scrollY;
            setIsVisible(scrolled > 600);
        };

        window.addEventListener("scroll", handleScroll);
        return () => {
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);

    const scrollToTop = () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    };
    const [sidebarOpen, setSidebarOpen] = useState(false);


    return (
        <div className="w-full bg-[#f3f7fd] font-sans ">
            <Navbar />
            <Outlet />
            <Footer />
        </div>
    );
};

export default AuthLayout;
