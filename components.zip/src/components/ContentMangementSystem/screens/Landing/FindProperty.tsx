import React from "react";
// import FooterSection from "./sections/FooterSection/FooterSection";
import ContactUsSection from "./sections/ContactUsSection/ContactUsSection";
import FeaturedListingsSection from "./sections/FeaturedListingsSection/FeaturedListingsSection";
// import NavbarSection from "./sections/NavbarSection/NavbarSection";
import RentalPlansSection from "./sections/RentalPlansSection/RentalPlansSection";
import FAQsSection from "./sections/FAQsSection/FAQsSection";
import ServicesSection from "./sections/ServicesSection/ServicesSection";
import TestimonialsSection from "./sections/TestimonialsSection/TestimonialsSection";
import SearchProperty from "./sections/SearchProperty/SearchProperty";
// import { IMAGES } from "../../../../assets/index";

// export const FindProperty = (): JSX.Element => {
const FindProperty = () => {
  return (
      <>
        <SearchProperty />

        <FeaturedListingsSection />

        <ServicesSection />

        <RentalPlansSection />

        <TestimonialsSection />

        <FAQsSection />

        <ContactUsSection />
      </>
  );
};
export default FindProperty;
