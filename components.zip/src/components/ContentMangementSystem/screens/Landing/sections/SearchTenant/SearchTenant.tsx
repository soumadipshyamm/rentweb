import React, { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../../ui/select";
import { Button } from "../../../../../ui/button";
import {
  MapPin,
  Search,
  Filter,
} from "lucide-react";
import { Input } from "../../../../../ui/input";
import Tenant from "../../../../../ChildComponent/Tenant";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from 'react-intersection-observer';


const SearchTenant= () => {
  const [searchRef, inSearchView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const [ref, inView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const properties = [
    {
      id: 1,
      user: {
        name: "Indranil Sen",
        image: IMAGES.user_img,
      },
      title:
        "Looking for 2BR apartment for rent ",
      location: "Downtown San Francisco",
      postedDate: "28 Aug 2024 | 19:35",
      price: "$1000 - $1500",
      type: "Apartment",
      sqft: "700Sqft - 1400Sqft",
      beds: 3,
      baths: 2,
      isUrgent: true,
    },
    {
      id: 2,
      user: {
        name: "Anonymous",
        image: IMAGES.user_img,
      },
      title: "Looking for 2BR apartment for rent",
      location: "Downtown San Francisco",
      postedDate: "28 Aug 2024 | 19:35",
      price: "$1000 - $1500",
      type: "Apartment",
      sqft: "700Sqft - 1400Sqft",
      beds: 3,
      baths: 2,
      isUrgent: false,
    },
    {
      id: 3,
      user: {
        name: "Anonymous",
        image: IMAGES.user_img,
      },
      title: "Looking for 2BR apartment for rent",
      location: "Downtown San Francisco",
      postedDate: "28 Aug 2024 | 19:35",
      price: "$1000 - $1500",
      type: "Apartment",
      sqft: "700Sqft - 1400Sqft",
      beds: 3,
      baths: 2,
      isUrgent: false,
    },
    {
      id: 4,
      user: {
        name: "Indranil Sen",
        image: IMAGES.user_img,
      },
      title: "Looking for 2BR apartment for rent",
      location: "Downtown San Francisco",
      postedDate: "28 Aug 2024 | 19:35",
      price: "$1000 - $1500",
      type: "Apartment",
      sqft: "700Sqft - 1400Sqft",
      beds: 3,
      baths: 2,
      isUrgent: false,
    },
  ];
  return (
    <div className="bg-[#f3f7fd] py-8">
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8">
        {/* Search Filters */}
        <div className={`rounded-lg mb-8 ${inSearchView ? 'animate__animated animate__slideInLeft' : ''}`} ref={searchRef}>
          <div className="grid sm:grid-cols-1 md:grid-cols-4 gap-4 items-end">
            <div>
              {/* <label className="block text-sm font-medium text-foreground mb-2">Location</label> */}
              <div className="relative">
                <Input
                  placeholder="Location"
                  className="pr-10 rounded-[99px] bg-white h-10"
                />
                <MapPin className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              </div>
            </div>
            <div>
              {/* <label className="block text-sm font-medium text-foreground mb-2">Type</label> */}
              <Select>
                <SelectTrigger className="w-full rounded-[99px] bg-white h-10">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="house">House</SelectItem>
                  <SelectItem value="apartment">Apartment</SelectItem>
                  <SelectItem value="villa">Villa</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              {/* <label className="block text-sm font-medium text-foreground mb-2">Price</label> */}
              <Select>
                <SelectTrigger className="w-full rounded-[99px] bg-white h-10">
                  <SelectValue placeholder="Price" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-500">$0 - $500</SelectItem>
                  <SelectItem value="500-1000">$500 - $1000</SelectItem>
                  <SelectItem value="1000+">$1000+</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button className="bg-white hover:bg-blue-700 text-dark flex-1 rounded-[99px] h-10">
                Search advanced
                <Filter className="h-4 w-4 mr-2" />
              </Button>
              <Button
                variant="outline"
                className="px-4 bg-white hover:bg-blue-700 rounded-[99px] h-10"
              >
                Search
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 bg-white">
        <div className="container mx-auto px-4 py-8">
          <div className={`grid sm:grid-cols-1 lg:grid-cols-2 gap-6 ${inView ? 'animate__animated animate__slideInUp' : ''}`} ref={ref}>
            {properties.map((property) => (
              <Tenant
                id={property.id}
                user={property.user}
                type={property.type}
                location={property.location}
                title={property.title}
                beds={property.beds}
                baths={property.baths}
                sqft={property.sqft}
                postedDate={property.postedDate}
                price={property.price}
                isUrgent={property.isUrgent}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
export default SearchTenant;