import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../../../../ui/accordion";
import { useInView } from 'react-intersection-observer';

const FAQsSection = () => {
  const [ref, inView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const [faqRef, inFaqView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const faqData = [
    {
      id: "item-1",
      question: "How Do I Get Started With Your Services?",
      answer:
        "Once your account is set up and you've familiarized yourself with the platform, you are ready to start using our services. Whether it's accessing specific features, making transactions, or utilizing our tools, you'll find everything you need at your fingertips.",
      defaultOpen: true,
    },
    {
      id: "item-2",
      question: "Why Should I Use Your Services?",
      answer: "Our services provide comprehensive property management solutions with 24/7 support, competitive pricing, and a user-friendly platform that makes finding and managing properties effortless.",
      defaultOpen: false,
    },
    {
      id: "item-3",
      question: "How Secure Are Your Services?",
      answer: "We use industry-standard encryption and security protocols to protect your data. All transactions are secured with SSL encryption and we comply with all relevant data protection regulations.",
      defaultOpen: false,
    },
    {
      id: "item-4",
      question: "Is There Customer Support Available?",
      answer: "Yes, we offer 24/7 customer support through multiple channels including live chat, email, and phone. Our dedicated support team is always ready to help you with any questions or issues.",
      defaultOpen: false,
    },
    {
      id: "item-5",
      question: "How Can I Update My Account Information?",
      answer: "You can easily update your account information by logging into your dashboard and navigating to the account settings section. Changes are saved automatically and take effect immediately.",
      defaultOpen: false,
    },
  ];

  return (
    <section className="w-full sm:py-8 md:py-[52px] bg-[#f3f7fd]" id="faq">
      <div className="max-w-[1717px] mx-auto sm:px-4 md:px-8 lg:px-[101px]">
        <div className="mb-8">
          <div className="inline-flex flex-col items-start gap-1">
            <div className="[font-family:'Manrope',Helvetica] font-semibold text-primary text-lg tracking-[1.44px] leading-6 whitespace-nowrap">
              FAQ
            </div>
            <h2 className="[font-family:'Manrope',Helvetica] font-extrabold text-foreground sm:text-2xl md:text-4xl tracking-[0] sm:leading-tight md:leading-[44px]">
              Frequently Asked Questions
            </h2>
          </div>
        </div>

        <Accordion
          type="single"
          collapsible
          defaultValue="item-1"
          className={`sm:space-y-3 md:space-y-[11px] ${inFaqView ? 'animate__animated animate__slideInUp' : ''}`} ref={faqRef}
        >
          {faqData.map((faq, index) => (
            <AccordionItem ref={ref}
              key={faq.id}
              value={faq.id}
              className={`bg-white rounded-2xl border-none ${inView ? 'animate__animated animate__slideInUp' : ''}`} style={{ animationDelay: `${index * 0.3}s` }}
            >
              <AccordionTrigger className="sm:px-4 md:px-[30px] sm:py-4 md:py-6 hover:no-underline [&[data-state=open]>div]:text-primary [&[data-state=open]>div]:font-extrabold">
                <div className="font-heading-heading-06 font-[number:var(--heading-heading-06-font-weight)] text-foreground sm:text-base md:text-[length:var(--heading-heading-06-font-size)] tracking-[var(--heading-heading-06-letter-spacing)] sm:leading-tight md:leading-[var(--heading-heading-06-line-height)] [font-style:var(--heading-heading-06-font-style)] text-left">
                  {faq.question}
                </div>
              </AccordionTrigger>
              {faq.answer && (
                <AccordionContent className="sm:px-4 md:px-[30px] sm:pb-4 md:pb-6 pt-0">
                  <div className="font-body-body-default font-[number:var(--body-body-default-font-weight)] text-[#5b6268] sm:text-sm md:text-[length:var(--body-body-default-font-size)] tracking-[var(--body-body-default-letter-spacing)] sm:leading-relaxed md:leading-[var(--body-body-default-line-height)] [font-style:var(--body-body-default-font-style)]">
                    {faq.answer}
                  </div>
                </AccordionContent>
              )}
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};
export default FAQsSection;
