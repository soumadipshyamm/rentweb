import React, { useEffect, useState } from "react";
import PropertyTypeCard from "./PropertyTypeCard";
import PropertyListing from "./PropertyListing";
import { Card, CardContent } from "../ui/card";
import { IMAGES } from "../../assets";
import PercentageViewer from "../ChildComponent/PercentageViewer";
import ToggleButton from "../ChildComponent/ToggleButton";
import { useAuth } from "../../context/AuthContext";
import { transmissionLowerCase } from "../../lib/utils";

const Dashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [percentage, setPercentage] = useState<number>(75);
  const { user }= useAuth();

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <>
      <div className="flex flex-col gap-8 common-container">
        <div className="grid sm:grid-cols-1 lg:grid-cols-12 gap-4">
          {/* <PropertyStats /> */}
          <div
            className={`sm:col-span-12 lg:col-span-8 flex-1 items-center bg-white rounded-2xl border border-[#e4e4e4] p-5`}
          >
            <div
              className={`w-full grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 mb-2`}
            >
              <div className="tenent-card-div">
                <Card className="tenent-card">
                  <CardContent className="flex items-center justify-center gap-2 h-full px-2 py-5">
                    <img
                      className="w-14 h-14 md:w-14 md:h-14"
                      alt={`Saved Properties icon`}
                      src={IMAGES.save_property}
                    />

                    <div className="flex flex-col justify-center gap-1">
                      <div className="font-bold text-xl text-[#3352A4]">
                        28
                      </div>
                      <div className="[font-family:'Manrope',Helvetica] text-foreground text-sm md:text-md text-center tracking-[0] leading-[25.2px]">
                        Saved Properties
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="tenent-card-div">
                <Card className="tenent-card">
                  <CardContent className="flex items-center justify-center gap-2 h-full px-2 py-5">
                    <img
                      className="w-14 h-14 md:w-14 md:h-14"
                      alt={`Saved Properties icon`}
                      src={IMAGES.connection}
                    />

                    <div className="flex flex-col justify-center gap-1">
                      <div className="font-bold text-xl text-[#3352A4]">
                        28
                      </div>
                      <div className="[font-family:'Manrope',Helvetica] text-foreground text-sm md:text-md text-center tracking-[0] leading-[25.2px]">
                        Connection Request
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div>
                <Card className="tenent-card">
                  <CardContent className="flex items-center justify-center gap-2 h-full px-2 py-5">
                    <img
                      className="w-14 h-14 md:w-14 md:h-14"
                      alt={`Saved Properties icon`}
                      src={IMAGES.preference}
                    />

                    <div className="flex flex-col justify-center gap-1">
                      <div className="font-bold text-xl text-[#3352A4]">
                        28
                      </div>
                      <div className="[font-family:'Manrope',Helvetica] text-foreground text-sm md:text-md text-center tracking-[0] leading-[25.2px]">
                        Posted Preference
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            <hr className="text-[#0000001A]"/>
            <div className="w-full grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 mt-2">
              <div className="tenent-card-div">
                <Card className="tenent-card">
                  <CardContent className="flex items-center justify-center gap-2 h-full px-2 py-5">
                    <img
                      className="w-14 h-14 md:w-14 md:h-14"
                      alt={`Saved Properties icon`}
                      src={IMAGES.message}
                    />

                    <div className="flex flex-col justify-center gap-1">
                      <div className="font-bold text-xl text-[#3352A4]">
                        28
                      </div>
                      <div className="[font-family:'Manrope',Helvetica] text-foreground text-sm md:text-md text-center tracking-[0] leading-[25.2px]">
                        New Messages
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="tenent-card-div">
                <Card className="tenent-card">
                  <CardContent className="flex items-center justify-center gap-2 h-full px-2 py-5">
                    <img
                      className="w-14 h-14 md:w-14 md:h-14"
                      alt={`Saved Properties icon`}
                      src={IMAGES.calender}
                    />

                    <div className="flex flex-col justify-center gap-1">
                      <div className="font-bold text-xl text-[#3352A4]">
                        28
                      </div>
                      <div className="[font-family:'Manrope',Helvetica] text-foreground text-sm md:text-md text-center tracking-[0] leading-[25.2px]">
                        Schedule Visit
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div>
                <Card className="tenent-card">
                  <CardContent className="flex items-center justify-center gap-2 h-full px-2 py-5">
                    <img
                      className="w-14 h-14 md:w-14 md:h-14"
                      alt={`Saved Properties icon`}
                      src={IMAGES.query}
                    />

                    <div className="flex flex-col justify-center gap-1">
                      <div className="font-bold text-xl text-[#3352A4]">
                        28
                      </div>
                      <div className="[font-family:'Manrope',Helvetica] text-foreground text-sm md:text-md text-center tracking-[0] leading-[25.2px]">
                        Query Feedback
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
          <div
            className={`sm:col-span-12 lg:col-span-4 flex-1 items-center bg-white rounded-2xl border border-[#e4e4e4] pr-5 pl-5`}
          >
            <div className="w-full grid sm:grid-cols-2 md:grid-cols-1 lg:grid-cols-1 mt-2">
              <Card className="tenent-card">
                <CardContent className="flex gap-2 h-full px-2 py-5">
                  <img
                    className="sm:w-20 sm:h-20 md:w-20 md:h-20 p-1 border border-chart-1 border-dashed rounded-full"
                    alt={`Saved Properties icon`}
                    src={IMAGES.user_img}
                  />

                  <div className="flex flex-col justify-center">
                    <div className="font-bold text-xl text-[#000]">
                      {`${user?.first_name} ${user?.middle_name} ${user?.last_name}`}
                    </div>
                    <div className="[font-family:'Manrope',Helvetica] text-foreground sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                      ID:RENTMATCH64746444
                    </div>
                    {user?.gender && <div className="[font-family:'Manrope',Helvetica] text-foreground sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                      {transmissionLowerCase(user?.gender)}
                    </div>}
                  </div>
                </CardContent>
              </Card>
              <hr />
              <Card className="tenent-card">
                <CardContent className="flex gap-2 h-full px-2 py-5 justify-between items-center">
                  <div className="flex flex-col justify-center">
                    <div className="flex gap-1">
                      <div className="[font-family:'Manrope',Helvetica] text-foreground sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                        {user?.email}
                      </div>
                      <img src={IMAGES.verified} alt="" className="w-5 h-5" />
                    </div>
                    <div className="[font-family:'Manrope',Helvetica] text-foreground sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                      {user?.phone_number}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="[font-family:'Manrope',Helvetica] text-foreground sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                        Profile Visibility
                      </div>
                      <ToggleButton defaultToggled={false} />
                    </div>
                  </div>
                  <div className="flex flex-col items-center justify-center">
                    <PercentageViewer percentage={percentage} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Property Types */}
        <PropertyTypeCard />
        <PropertyListing />
      </div>
    </>
  );
};
export default Dashboard;