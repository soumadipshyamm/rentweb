import React from "react";

const PostDetails: React.FC = () => {
    return <div></div>
}

export default PostDetails;