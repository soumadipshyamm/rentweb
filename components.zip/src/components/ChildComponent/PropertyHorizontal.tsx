import React from "react";
import {
  ArrowRightIcon,
  BathIcon,
  BedIcon,
  BookmarkIcon,
  MapPin,
  MapPinIcon,
  SquareIcon,
} from "lucide-react";
import { Badge } from "./../ui/badge";
import { Card, CardContent } from "./../ui/card";
import { IMAGES } from "../../assets/index";

type PropertyHorizontalProps = {
  id: string | number;
  image: string;
  type: string;
  status: string;
  location: string;
  title: string;
  beds: number;
  baths: number;
  area: string;
  postedDate: string;
  price: string | number;
  featured: number | boolean;
  forRent: number | boolean;
};

const PropertyHorizontal: React.FC<PropertyHorizontalProps> = ({
  id,
  title,
  location,
  price,
  beds,
  baths,
  area,
  image,
  featured,
  forRent,
  postedDate,
}) => {
  return (
    <Card
      key={id}
      className="overflow-hidden hover:shadow-lg shadow-sm mb-5 mt-1 mx-1"
    >
      <div className="flex">
        <div className="relative w-48 h-37">
          <img
            src={image || "/placeholder.svg"}
            alt={title}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-3 left-3 flex gap-2">
            {featured && (
              <Badge className="bg-[#f3d034] text-foreground hover:bg-[#f3d034] rounded-[99px] px-2 py-0 h-5 md:h-5">
                <span className="[font-family:'Manrope',Helvetica] font-medium text-xs px-1">
                  Featured
                </span>
              </Badge>
            )}
            {forRent && (
              <Badge className="bg-white text-destructive-foreground hover:bg-white rounded-[99px] px-2 py-0 h-5 md:h-5">
                <span className="[font-family:'Manrope',Helvetica] font-medium text-xs px-1">
                  For Sale
                </span>
              </Badge>
            )}
          </div>
        </div>
        <CardContent className="flex-1 pl-2 pr-2 pt-2">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-semibold text-gray-900 text-lg">
              {title.length > 25 ? `${title.slice(0, 25)}...` : title}
            </h3>
          </div>
          <div className="flex flex-wrap items-start sm:gap-2 md:gap-4">
            <div className="flex items-center gap-1">
              {/* <BedIcon className="w-4 h-4" /> */}
              <img src={IMAGES.beds} alt="" className="w-[15px]"/>
              <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                Beds:
              </span>
              <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                {beds}
              </span>
            </div>

            <div className="flex items-center gap-1">
              {/* <BathIcon className="w-4 h-4" /> */}
              <img src={IMAGES.baths} alt="" className="w-[15px]"/>
              <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                Baths:
              </span>
              <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                {baths}
              </span>
            </div>

            <div className="flex items-center gap-1">
              {/* <SquareIcon className="w-4 h-4" /> */}
              <img src={IMAGES.sqft} alt="" className="w-[15px]"/>
              <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                Sqft:
              </span>
              <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                {area}
              </span>
            </div>
          </div>
          <div className="flex items-center text-gray-600 mb-3 mt-2">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="text-sm">
              {location.length > 35 ? `${location.slice(0, 35)}...` : location}
            </span>
          </div>
          <hr />
          <div className="flex justify-between items-center mb-2">
            <div className="text-sm text-gray-500">Posted On: {postedDate}</div>
            <span className="text-2xl font-bold text-blue-600">{price}</span>
          </div>
        </CardContent>
      </div>
    </Card>
  );
};

export default PropertyHorizontal;
