import React from "react";
import {
  BookmarkIcon,
  MapPinIcon,
} from "lucide-react";
// import { Badge } from "./ui/badge";
import { Badge } from "./../ui/badge";
import { Button } from "./../ui/button";
import { Card, CardContent } from "./../ui/card";
import { Separator } from "./../ui/separator";
import { IMAGES } from "../../assets/index";

type PropertyProps = {
  id: string | number;
  image: string;
  type: string;
  status: string;
  location: string;
  title: string;
  beds: number;
  baths: number;
  sqft: string | number;
  postedDate: string;
  price: string | number;
};

const Property: React.FC<PropertyProps> = ({
  id,
  image,
  type,
  status,
  location,
  title,
  beds,
  baths,
  sqft,
  postedDate,
  price,
}) => {
  return (
    <Card key={id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-card-border">
      <div className="relative">
        <div
          className="w-full h-[270px] bg-cover bg-center relative"
          style={{ backgroundImage: `url(${image})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent">
            <div className="absolute top-2.5 left-2.5 flex items-center gap-2">
              <Badge className="bg-[#f3d034] text-foreground hover:bg-[#f3d034] rounded-[99px] px-2 py-0 h-5 md:h-5">
                <span className="[font-family:'Manrope',Helvetica] font-medium text-sm px-1 py-1">
                  {type}
                </span>
              </Badge>
              <Badge className="bg-white text-[#08914f] hover:bg-white rounded-[99px] px-2 py-0 h-5 md:h-5">
                <span className="[font-family:'Manrope',Helvetica] font-medium text-sm px-1 py-1">
                  {status}
                </span>
              </Badge>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="absolute top-[237px] right-[9px] w-6 h-6 p-0 hover:bg-transparent"
            >
              <BookmarkIcon className="w-6 h-6 text-white" />
            </Button>

            <div className="absolute bottom-5 left-5 flex items-center gap-1">
              <MapPinIcon className="w-4 h-4 text-white" />
              <span className="[font-family:'Manrope',Helvetica] font-normal text-white text-sm tracking-[0] leading-[19.6px]">
                {location}
              </span>
            </div>
          </div>
        </div>
      </div>

      <CardContent className="p-5">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2.5">
            <h3 className="[font-family:'Manrope',Helvetica] font-semibold text-foreground text-xl tracking-[0] leading-7">
              {title.length > 20 ? `${title.slice(0, 20)}...` : title}
            </h3>

            <div className="flex flex-wrap items-start sm:gap-2 md:gap-4">
              <div className="flex items-center gap-1">
                {/* <BedIcon className="w-4 h-4" /> */}
                <img src={IMAGES.beds} alt="" />
                <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                  Beds:
                </span>
                <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                  {beds}
                </span>
              </div>

              <div className="flex items-center gap-1">
                {/* <BathIcon className="w-4 h-4" /> */}
                <img src={IMAGES.baths} alt="" />
                <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                  Baths:
                </span>
                <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                  {baths}
                </span>
              </div>

              <div className="flex items-center gap-1">
                {/* <SquareIcon className="w-4 h-4" /> */}
                <img src={IMAGES.sqft} alt="" />
                <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                  Sqft:
                </span>
                <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                  {sqft}
                </span>
              </div>
            </div>
          </div>

          <Separator className="bg-out-line" />

          <div className="flex sm:flex-col md:flex-row sm:items-start md:items-center justify-between gap-2">
            <div className="flex items-center gap-2 flex-1">
              <span className="[font-family:'Manrope',Helvetica] font-normal text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                <span className="font-medium">Posted On: </span>
                <span className="font-bold">{postedDate}</span>
              </span>
            </div>
            <div className="[font-family:'Manrope',Helvetica] font-bold text-primary sm:text-lg md:text-xl tracking-[0] leading-7">
              {price}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Property;
