import React from "react";
import {
  Calendar,
  Heart,
  MapPin,
} from "lucide-react";
import { Button } from "./../ui/button";
import { Card, CardContent } from "./../ui/card";

type User = {
  name: string;
  image: string;
  // Add other user properties here if needed
};

type TenantProps = {
  id: string | number;
  user: User;
  type: string;
  location: string;
  title: string;
  beds: number;
  baths: number;
  sqft: String;
  postedDate: string;
  price: string | number;
  isUrgent: boolean;
};

const Tenant: React.FC<TenantProps> = ({
  id,
  user,
  type,
  location,
  title,
  beds,
  baths,
  sqft,
  postedDate,
  price,
  isUrgent
}) => {
  return (
    <Card key={id} className="hover:shadow-lg transition-shadow border border-card-border">
      <CardContent className="pt-6 pb-1 pr-6 pl-6">
        {/* User Info */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img
              src={user.image}
              alt=""
              className="w-20 h-20"
              style={{ borderRadius: "50%" }}
            />
            <div>
              <h3 className="font-semibold text-gray-900">
                {user.name}
              </h3>
              {user.name !== "Anonymous" && (
                <span className="text-sm text-gray-500">Male</span>
              )}
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="rounded-[99px] h-10 w-40"
            style={{ borderColor: "#3352A4", color: "#3352A4" }}
          >
            View Details
          </Button>
        </div>

        {/* Title */}
        <h4 className="text-lg font-medium text-gray-900 mb-3 [font-family:'Manrope',Helvetica]">
          {/* {title} */}
          {title.length > 60
            ? `${title.slice(0, 60)}...`
            : title}
        </h4>

        {/* Location and Date */}
        <div className="flex sm:flex-col lg:flex-row sm:items-center lg:items-start gap-4 mb-4 text-sm text-gray-600">
          <div
            className="flex items-center [font-family:'Manrope',Helvetica]"
            style={{ color: "#3352A4" }}
          >
            <MapPin className="h-4 w-4 mr-1" style={{ color: "#000" }} />
            {location}
          </div>
          <div className="flex items-center [font-family:'Manrope',Helvetica]">
            <Calendar className="h-4 w-4 mr-1" />
            {postedDate}
          </div>
          {isUrgent && (
            <div
              className="rounded-[99px] h-6 pl-2 pr-2 bg-[#C10664] text-white ml-5 [font-family:'Manrope',Helvetica]"
              style={{ border: "1px solid #C10664" }}
            >
              Urgent
            </div>
          )}
        </div>
        <hr />
        {/* Property Details */}
        <div className="grid sm:grid-cols-1 md:grid-cols-2 2xl:grid-cols-3 sm:gap-4 lg:gap-6 mt-4">
          <div>
            <div className="flex items-center text-sm text-gray-600 mb-1 [font-family:'Manrope',Helvetica]">
              Price:{" "}
              <span className="font-medium ml-1" style={{ color: "#3352A4" }}>
                {price}
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-600 mb-1 [font-family:'Manrope',Helvetica]">
              Property Type:{" "}
              <span className="font-medium ml-1" style={{ color: "#3352A4" }}>
                {type}
              </span>
            </div>
            <div className="text-sm text-gray-600 [font-family:'Manrope',Helvetica]">
              Size:{" "}
              <span className="font-medium" style={{ color: "#3352A4" }}>
                {sqft}
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center text-sm text-gray-600 mb-1 [font-family:'Manrope',Helvetica]">
              No Of Bed Rooms:{" "}
              <span className="font-medium ml-1" style={{ color: "#3352A4" }}>
                {beds}
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-600 [font-family:'Manrope',Helvetica]">
              No Of Bathroom:{" "}
              <span className="font-medium ml-1" style={{ color: "#3352A4" }}>
                {baths}
              </span>
            </div>
          </div>
        </div>

        {/* Heart Icon */}
        <div className="flex justify-end">
          <Button variant="ghost" size="sm" className="p-2">
            <Heart className="h-5 w-5 text-gray-400 hover:text-red-500 transition-colors" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default Tenant;
