import React from "react";
import {
  BookmarkIcon,
  MapPinIcon,
} from "lucide-react";
import { Badge } from "./../../ui/badge";
import { Button } from "./../../ui/button";
import { Card, CardContent } from "./../../ui/card";
import { Separator } from "./../../ui/separator";
import { IMAGES } from "../../../assets/index";

type PropertyProps = {
  id: string | number;
  image: string;
  type: string;
  status: string;
  location: string;
  title: string;
  beds: number;
  baths: number;
  sqft: string | number;
  postedDate: string;
  price: string | number;
  isSelected: boolean;
  onCardClick: (id: number) => void;
};

const Property: React.FC<PropertyProps> = ({
  id,
  image,
  type,
  status,
  location,
  title,
  beds,
  baths,
  sqft,
  postedDate,
  price,
  isSelected,
  onCardClick,
}) => {
  return (
    <Card key={id} className={`bg-white overflow-hidden hover:shadow-lg shadow-sm ${isSelected ? 'selected' : ''}`} onClick={() => onCardClick(Number(id))} style={{ borderRadius: "10px" }}>
      <div className="relative">
        <div
          className="h-[140px] bg-cover bg-center relative"
          style={{ backgroundImage: `url(${image})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent">
            <div className="absolute top-2.5 left-2.5 flex items-center gap-2">
              <Badge className="bg-[#f3d034] text-foreground hover:bg-[#f3d034] rounded-[99px] px-1 py-0 h-5 md:h-5">
                <span className="[font-family:'Manrope',Helvetica] font-medium text-xs px-1">
                  {type}
                </span>
              </Badge>
              <Badge className="bg-white text-[#08914f] hover:bg-white rounded-[99px] px-1 py-0 h-5 md:h-5">
                <span className="[font-family:'Manrope',Helvetica] font-medium text-xs px-1">
                  {status}
                </span>
              </Badge>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="absolute top-[237px] right-[9px] w-6 h-6 p-0 hover:bg-transparent"
            >
              <BookmarkIcon className="w-6 h-6 text-white" />
            </Button>

            <div className="absolute bottom-2 left-2 flex items-center gap-1">
              <MapPinIcon className="w-4 h-4 text-white" />
              <span className="[font-family:'Manrope',Helvetica] font-normal text-white text-sm tracking-[0] leading-[19.6px]">
                {location.length > 15 ? `${location.slice(0, 15)}...` : location}
              </span>
            </div>
          </div>
        </div>
      </div>

      <CardContent className="p-2">
        <div className="flex flex-col">
          <div className="flex flex-col">
            <h4 className="[font-family:'Manrope',Helvetica] font-semibold text-foreground text-md tracking-[0] leading-7">
              {title.length > 12 ? `${title.slice(0, 12)}...` : title}
            </h4>

            <div className="flex flex-wrap items-start md:gap-1">
              <div className="flex items-center gap-1">
                {/* <BedIcon className="w-4 h-4" /> */}
                <img src={IMAGES.beds} alt="" className="w-3 h-3"/>
                <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                  Beds:
                </span>
                <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                  {beds}
                </span>
              </div>

              <div className="flex items-center gap-1">
                {/* <BathIcon className="w-4 h-4" /> */}
                <img src={IMAGES.baths} alt="" className="w-3 h-3"/>
                <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                  Baths:
                </span>
                <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                  {baths}
                </span>
              </div>

              <div className="flex items-center gap-1">
                {/* <SquareIcon className="w-4 h-4" /> */}
                <img src={IMAGES.sqft} alt="" className="w-3 h-3"/>
                <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                  Sqft:
                </span>
                <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                  {sqft}
                </span>
              </div>
            </div>
          </div>

          <hr style={{ color:"#E4E4E4" }}/>

          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
            <div className="flex items-center gap-2 flex-1">
              <span className="[font-family:'Manrope',Helvetica] font-normal text-[#333333] tracking-[0] leading-[19.6px]" style={{ fontSize: "12px" }}>
                <span className="font-medium">Posted On: </span>
                <span className="font-bold">{postedDate}</span>
              </span>
            </div>
            <div className="[font-family:'Manrope',Helvetica] font-bold text-primary tracking-[0] leading-7" style={{ fontSize: "15px" }}>
              {price}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Property;
