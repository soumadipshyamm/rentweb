import React from "react";
import { useModal } from "../../context/modalProvider";
import { Dialog, DialogContent } from "../ui/dialog"
import DeleteConfirmation from "./deleteConfirmation";


const CommonDialog = () => {
    const {modalType, closeModal, parameter} = useModal();
    const isOpen = modalType !== null;

    return (
        <Dialog open={isOpen} onOpenChange={open => !open && closeModal()}>
            <DialogContent  className={'z-[999] backdrop-blur-[2px] max-h-[calc(100vh-10px)] bg-input ' + (modalType === 'yinLoader' ? '[&>button]:hidden' : '')}>
                {modalType === 'remove' && <DeleteConfirmation parameters={parameter} /> }
            </DialogContent>
        </Dialog>
    )
}

export default CommonDialog;