import React from "react";
import { useModal } from "../../context/modalProvider";
import { Button } from "../ui/button";

const DeleteConfirmation = ({parameters} : {parameters : {header : string, description: string, fn: () => void}}) => {
    const { closeModal } = useModal();

    return <div className="flex flex-col gap-8 max-w-[400px] mx-auto">
        <div>
            <h1 className="text-xl text-center font-bold text-muted">{parameters?.header}</h1>
            <p className="text-center text-sm font-medium mt-4">{parameters?.description}</p>
        </div>
        <div className="flex items-center justify-end gap-4">
            <Button variant="secondary" onClick={closeModal}>Cancel</Button>
            <Button variant="destructive" onClick={() => {parameters?.fn(); closeModal();}}>Delete</Button>
        </div>
    </div>
}

export default DeleteConfirmation;