const PlanLoader = () => {
    return <div className="flex gap-5">
        <div className="w-100 h-60"></div>
        <div className="w-100 h-60"></div>
        <div className="w-100 h-60"></div>
    </div>
}