import React, { useState } from "react";
import Footer from "./Layout/Footer";
import { Header } from "./Layout/Header";
import { Sidebar } from "./Layout/Sidebar";
import { mockUser } from "./data/mockData";
import { Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Layout = () => {
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const { user } = useAuth();
    const toggleSidebar = () => {
        setSidebarOpen(!sidebarOpen);
    };
    return (
        <div className="min-h-screen font-sans flex bg-accent overflow-hidden">
            {/* ===== Sidebar ===== */}
            <aside
                className={`w-[240px] bg-white border-r border-gray-200 transition-all duration-300 h-screen overflow-hidden`}
            >
                <Sidebar isOpen={sidebarOpen} onToggle={toggleSidebar} />
            </aside>

            {/* ===== Main Section ===== */}
            <div
                className={`h-screen overflow-hidden flex flex-col transition-all duration-300 relative w-[calc(100%-200px)]`}
            >
                {/* ===== Header ===== */}
                <header className="bg-white border-b border-gray-200 w-[calc(100%-233px)] fixed top-0 right-0 z-10 transition-all duration-300">
                    <div className="px-6 py-4">
                        <Header user={mockUser} customUser={user} onMenuToggle={toggleSidebar} />
                    </div>
                </header>

                {/* ===== Main Content ===== */}
                <main className="flex-1 w-full px-6 pt-2 mt-[80px] overflow-y-auto h-screen w-full">
                    <Outlet />
                </main>

                {/* ===== Footer ===== */}
                {/* <footer className="border-t border-gray-200 bg-white py-4 px-6"> */}
                    <Footer />
                {/* </footer> */}
            </div>
        </div>
    );
};

export default Layout;

// <div className="min-h-screen bg-gray-50 w-100vw overflow-hidden grid-cols-12 gap-0">
//             {/* <!-- Sidebar --> */}
//             <div className="col-span-3 min-h-screen w-full ">
//                 <Sidebar isOpen={sidebarOpen} onToggle={toggleSidebar} />
//             </div>
//             {/* <!-- Main Content --> */}
//             <div className="col-span-9 relative">
//                 {/* <!-- Header --> */}
//                 <Header user={mockUser} onMenuToggle={toggleSidebar} />

//                 {/* <!-- Main Dashboard Content --> */}
//                 <main className="p-4 lg:p-6 space-y-6" style={{ paddingTop: "80px" }}>
//                     <Outlet />
//                     {/* <!-- Footer --> */}
//                 </main>
//                 <Footer />
//             </div>
//         </div>