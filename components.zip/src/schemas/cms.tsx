import { z } from "zod";

export const createPropertyTypeSchema = z.object({
    name: z.string()
        .min(3, "Please provide valid name" )
        .max(100, "Please provide valid name" ),
  
    description: z.string()
        .min(3, "Please provide valid description" )
        .max(100, "Please provide valid description" ),
})

