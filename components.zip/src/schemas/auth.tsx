import { z } from "zod";

export const signinSchema = z.object({
    user_id: z
        .email({ message: "Invalid email address" }),
  
    password: z.string()
        .min(8, "Password must be at least 8 characters"),
        // .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/, 
        // "Password must contain uppercase, lowercase, number, and special character"),
    role: z.enum(["TENANT", "LANDLORD", "PROPERTY MANAGER", "SUPER ADMIN", "ADMIN"])
})

export type SigninSchemaType = z.infer<typeof signinSchema>;


export const registrationValidateSchema = z.object({
    email: z.string()
        .email({ message: "Please provide valid email address" }),
    gender: z.enum(["MALE", "FEMALE", "OTHERS"], "Please select gender"),
    phone_number: z.string().regex(/^\+?[1-9]\d{8,14}$/, "Please provide valid phone number."),
    first_name: z.string().min(3, "Please provide name with more than 3"),
    last_name: z.string().min(3, "Please provide name with more than 3"),
    user_name: z.string()
        .min(3, "Please enter a valid user name")
        .regex(/^[a-zA-Z0-9]+$/, "Username can only contain letters and numbers")
        .regex(/^[^\s]+$/, "Username should not contain spaces"),
  
    password: z.string()
        .min(8, "Password must be at least 8 characters"),
    confirm_password: z.string()
        .min(8, "Password must be at least 8 characters"),
    
}).refine((data) => data.password === data.confirm_password, {
    path: ["confirm_password"], // attach error to confirmPassword
    message: "Password and confirm password do not match",
});

export const forgotEmailSchema = z.object({
    email: z.string()
        .email({ message: "Please provide valid email address" }),
    role: z.enum(["TENANT", "LANDLORD", "PROPERTY MANAGER", "SUPER ADMIN", "ADMIN"])

});

export type ForgotEmailSchemaType = z.infer<typeof forgotEmailSchema>;

export const forgotOtpSchema = z.object({
    otp: z.string()
        .min(4, "Please enter 4 digit of OTP"),
    email: z.string()
        .email({ message: "Please provide valid email address" }),
    role: z.enum(["TENANT", "LANDLORD", "PROPERTY MANAGER", "SUPER ADMIN", "ADMIN"])
})

export const changePasswordSchema = z.object({
    email: z.string()
        .email({ message: "Please provide valid email address" }),
    role: z.enum(["TENANT", "LANDLORD", "PROPERTY MANAGER", "SUPER ADMIN", "ADMIN"]),
    password: z.string()
        .min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string()
        .min(8, "Password must be at least 8 characters")
}).refine((data) => data.password === data.confirmPassword, {
    path: ["confirmPassword"], // attach error to confirmPassword
    message: "Password and confirm password do not match",
});