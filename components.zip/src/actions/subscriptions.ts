import api from ".";
import { subscriptionform } from "../types/admin";
import { PROPERTY_TYPE_URL, SUBSCRIPTION_PLAN_ADD_URL, SUBSCRIPTION_PLAN_EDIT_URL, SUBSCRIPTION_PLAN_GET_URL, SUBSCRIPTION_PLAN_STATUS_CHANGE_URL, SUBSCRIPTION_PLAN_URL } from "./constant";

export const getSubscriptionPlanList = async (params: {search?: string} = {} ) => {    
  const res = await api.get(SUBSCRIPTION_PLAN_GET_URL, {params : params}); 
  console.log("res ::: ", res);
  
  return res.data;
};

export const addSubscriptionPlan = async ( payload : {name : string, description : string} ) => {
  const res = await api.post(SUBSCRIPTION_PLAN_ADD_URL, payload);
  return res.data;
};


export const editSubscriptionPlan = async ( id : string ) => {
  const res = await api.get(SUBSCRIPTION_PLAN_EDIT_URL + "/" + id);
  return res.data;
};

export const updateSubscriptionPlanApi = async ( payload : subscriptionform, id : string) => {
  const res = await api.put(SUBSCRIPTION_PLAN_URL + "/" + id, payload);
  return res.data;
};

export const deleteSubscriptionPlanApi = async ( id : string ) => {
  const res = await api.delete(SUBSCRIPTION_PLAN_URL + id );
  return res.data;
};

export const updateSubscriptionPlanStatusChangeApi = async (id : string) => {
  const res = await api.patch(SUBSCRIPTION_PLAN_STATUS_CHANGE_URL + id);
  return res.data;
};