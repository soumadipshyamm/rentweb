import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function transmissionLowerCase (value : string) {
  return value?.charAt(0) + value?.slice(1, value.length)?.toLocaleLowerCase();
}

export function transmissionUpperCase (value : string) {
  return value?.charAt(0)?.toLocaleUpperCase() + value?.slice(1, value.length);
}