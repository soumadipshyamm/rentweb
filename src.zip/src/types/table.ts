import { IconName } from "../components/icons/icon";

export type actionType = 'View' | 'Edit' | 'Active' | 'Disable' | 'Remove';

export type dropDownItemType = {
    name : actionType,
    icon : IconName,
    class ?: string
}