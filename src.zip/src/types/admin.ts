export type roleTypesForSubscription = "PROPERTY OWNER" | "PROPERTY MANAGER";
export type cyclesForSubscription = "WEEKLY" | "FORTNIGHTLY" | "MONTHLY" | "QUARTERLY" | "HALF YEARLY" | "YEARLY";
export interface subscriptionform {
    name: string;
    description: string;
    price: number | string;
    features: {title : string}[];
    plan_type: string;
    role_type: roleTypesForSubscription;
    cycles_for_subscription: cyclesForSubscription;
    is_active?: boolean;
}