import React, { useState } from "react";
import {
  GoogleMap,
  LoadScript,
  Marker,
  InfoWindow,
} from "@react-google-maps/api";
import { IMAGES } from "../../assets/index";
import { MapPin } from "lucide-react";

const containerStyle = {
  width: "100%",
  height: "100%",
};

type Property = {
  id: number;
  position: [number, number];
  title: string;
  description: string;
  price: string;
  bedrooms: number;
  bathrooms: number;
  area: string;
  imageUrl: string;
  location: string;
  beds: number;
  baths: number;
  featured: number | boolean;
  forRent: number | boolean;
  postedDate: string;
};

const properties: Property[] = [
  {
    id: 1,
    position: [22.578638, 88.485119], // Example position
    title: "Luxury Manhattan Apartment",
    description:
      "Modern 2BR apartment in the heart of Manhattan with stunning city views",
    price: "$4,500/month",
    bedrooms: 2,
    bathrooms: 2,
    area: "1,200 sq ft",
    imageUrl: IMAGES.villa_image,
    location: "New York, NY",
    beds: 4,
    baths: 3,
    featured: false,
    forRent: true,
    postedDate: "16 Aug 2025",
  },
  {
    id: 2,
    position: [22.591338, 88.473575], // Example position
    title: "Victorian House in London",
    description: "Beautiful Victorian house in Central London with garden",
    price: "£3,200/month",
    bedrooms: 3,
    bathrooms: 2,
    area: "1,500 sq ft",
    imageUrl: IMAGES.villa_image,
    location: "Machala",
    beds: 4,
    baths: 3,
    featured: false,
    forRent: true,
    postedDate: "16 Aug 2025",
  },
];

const GoogleMapComponent = () => {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(
    null
  );

  const handleMarkerClick = (property: Property) => {
    setSelectedProperty(property);
  };

  const handleCloseClick = () => {
    setSelectedProperty(null);
  };

  const onLoad = (mapInstance: google.maps.Map) => {
    const bounds = new window.google.maps.LatLngBounds();

    properties.forEach((property) => {
      bounds.extend({ lat: property.position[0], lng: property.position[1] });
    });

    mapInstance.fitBounds(bounds); // Fit the map to the bounds of the markers
  };

  return (
    // <LoadScript googleMapsApiKey="YOUR_GOOGLE_MAPS_API_KEY">
    <LoadScript googleMapsApiKey="">
      <GoogleMap mapContainerStyle={containerStyle} onLoad={onLoad}>
        {properties.map((property) => (
          <Marker
            key={property.id}
            position={{ lat: property.position[0], lng: property.position[1] }}
            onClick={() => handleMarkerClick(property)}
          />
        ))}

        {selectedProperty && (
          <InfoWindow
            position={{
              lat: selectedProperty.position[0],
              lng: selectedProperty.position[1],
            }}
            onCloseClick={handleCloseClick}
          >
            <div className="flex gap-2">
              <div className="relative w-48 h-37">
                <img
                  src={selectedProperty.imageUrl}
                  alt={selectedProperty.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="font-semibold text-gray-900 text-lg">
                  <h3 className="font-semibold text-gray-900 text-lg">
                    {selectedProperty.title.length > 25
                      ? `${selectedProperty.title.slice(0, 25)}...`
                      : selectedProperty.title}
                  </h3>
                </div>
                <div className="flex flex-wrap items-start sm:gap-2 md:gap-4">
                  <div className="flex items-center gap-1">
                    <img src={IMAGES.beds} alt="" />
                    <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                      Beds:
                    </span>
                    <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                      {selectedProperty.beds}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <img src={IMAGES.baths} alt="" />
                    <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                      Baths:
                    </span>
                    <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                      {selectedProperty.baths}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <img src={IMAGES.sqft} alt="" />
                    <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                      Sqft:
                    </span>
                    <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                      {selectedProperty.area}
                    </span>
                  </div>
                </div>
                <div className="flex items-center text-gray-600 mb-3 mt-2">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span className="text-sm">
                    {selectedProperty.location.length > 35
                      ? `${selectedProperty.location.slice(0, 35)}...`
                      : selectedProperty.location}
                  </span>
                </div>
                <hr />
                <div className="flex justify-between items-center mb-2">
                  <div className="text-sm text-gray-500">
                    Posted On: {selectedProperty.postedDate}
                  </div>
                  <span className="text-2l font-bold text-blue-600">
                    {selectedProperty.price}
                  </span>
                </div>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </LoadScript>
  );
};

export default GoogleMapComponent;
