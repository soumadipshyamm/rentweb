import React from "react";
import { Calendar, EllipsisVertical, MapPin } from "lucide-react";
import { Button } from "../../ui/button";
import { Card, CardContent } from "../../ui/card";
import { IMAGES } from "../../../assets/index";
import ToggleButton from "../ToggleButton";
import { useNavigate } from "react-router-dom";

type PostProps = {
  id: string | number;
  title: string;
  description: string;
  type: string;
  location: string;
  sqft: string;
  beds: number;
  baths: number;
  image: string;
  postedDate: string;
  price: string | number;
  featured: boolean;
  forRent: boolean;
  isUrgent: boolean;
  responseQty: number;
};

const Post: React.FC<PostProps> = ({
  id,
  title,
  description,
  location,
  price,
  beds,
  baths,
  sqft,
  image,
  featured,
  forRent,
  postedDate,
  type,
  isUrgent,
  responseQty,
}) => {
  const navigate = useNavigate();
  return (
    <Card
      key={id}
      className={`overflow-hidden hover:shadow-lg bg-white transition-shadow mb-5 p-2 border border-card-border`}
    >
      <div className="flex justify-between">
        <CardContent className="flex-1 p-2">
          <div className="flex items-center gap-3">
            <h3 className="font-semibold text-gray-900 text-lg">
              {title.length > 50 ? `${title.slice(0, 50)}...` : title}
            </h3>
            {isUrgent && (
              <p
                className="[font-family:'Manrope',Helvetica] font-medium border-[1px] border-[#C10664] px-[10px] text-xs rounded-xl bg-[#C10664] text-white">
                Urgent
              </p>
            )}
          </div>
          <p className="[font-family:'Manrope',Helvetica] text-xs">
            {description.length > 150
              ? `${description.slice(0, 150)}...`
              : description}
          </p>

          <div className="flex items-center mb-3 mt-2 gap-10">
            <div className="flex items-center text-gray-600">
              <MapPin className="h-3 w-3 mr-1" />
              <span className="text-xs">
                {location.length > 35
                  ? `${location.slice(0, 35)}...`
                  : location}
              </span>
            </div>
            <div className="flex items-center text-gray-600">
              <Calendar className="h-4 w-4 mr-1" />
              <span className="text-xs">
                {postedDate}
              </span>
            </div>
          </div>
          <div className="flex flex-wrap items-start sm:gap-10 md:gap-10">
            <div className="flex items-center gap-1">
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px] text-xs">
                Price:
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px] text-xs">
                {price}
              </span>
            </div>

            <div
              className="flex items-center gap-1 border-l-[1px] border-l-[#8a72af] pl-7">
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px] text-xs">
                Property Type:
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px] text-xs">
                {type}
              </span>
            </div>

            <div
              className="flex items-center gap-1 border-l-[1px] border-l-[#8a72af] pl-7">
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px] text-xs">
                Size:
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px] text-xs">
                {sqft}
              </span>
            </div>

            <div
              className="flex items-center gap-1 border-l-[1px] border-l-[#8a72af] pl-7">
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px] text-xs">
                No Of Bed Rooms -
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px] text-xs">
                {beds}
              </span>
            </div>

            <div
              className="flex items-center gap-1 border-l-[1px] border-l-[#8a72af] pl-7">
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px] text-xs">
                No Of Bathroom -
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px] text-xs">
                {baths}
              </span>
            </div>
          </div>
        </CardContent>
        <div
          className="pl-4 border-l-[1px] border-l-[#0000001A] flex flex-col justify-between py-2">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <div className="[font-family:'Manrope',Helvetica] text-foreground sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                Status
              </div>
              <ToggleButton defaultToggled={isUrgent}/>
            </div>
            <a href="">
              <EllipsisVertical className="text-[#00000054]"/>
            </a>
          </div>
          <div className="flex items-center gap-2">
            <img src={IMAGES.chat} alt="" />
            <div className="[font-family:'Manrope',Helvetica] text-primary sm:text-md md:text-md tracking-[0] leading-[25.2px]">
              {responseQty} Responses
            </div>
          </div>
          <div className="">
            <Button
              onClick={() => navigate("/post-details")}
              variant="outline"
              className="px-4 hover:bg-primary rounded-[99px] text-[#3352a4] hover:text-white shadow-none border-[1px] border-[#3352a4] px-5 py-2"
            >
              View Details
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default Post;
