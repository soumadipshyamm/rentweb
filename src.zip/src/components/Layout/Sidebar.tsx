import React, { useEffect, useState } from 'react';
import { 
  Home, 
  Building, 
  List, 
  MessageCircle, 
  Star, 
  Calendar, 
  HelpCircle, 
  FileQuestion, 
  ClipboardCheck, 
  History, 
  Shield,
  Settings,
  Menu,
  X
} from 'lucide-react';
import { NavigationItem } from '../types';
import { useAuth } from '../../context/AuthContext';
import { adminSidebar, landLordSidebar } from '../../commonJSONs/sidebar';
import { IMAGES } from "../../assets/index"
import Icon from '../icons/icon';
import { Link } from 'react-router-dom';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

const navigationItems: NavigationItem[] = [
  { id: 'dashboard', url: "/dashboard", label: 'Dashboard', icon: 'Home', active: true },
  { id: 'explore-properties', url: "/explore-properties", label: 'Explore Properties', icon: 'Building' },
  { id: 'list', url: "/my-post", label: 'My Post', icon: 'List' },
  { id: 'chat', url: "", label: 'Chat', icon: 'MessageCircle' },
  { id: 'reviews', url: "", label: 'Reviews', icon: 'Star' },
  { id: 'schedule', url: "", label: 'Schedule Visit', icon: 'Calendar', hasNotification: true },
  { id: 'help', url: "", label: 'Help Center', icon: 'HelpCircle' },
  { id: 'faq', url: "", label: 'FAQ', icon: 'FileQuestion' },
  { id: 'guidelines', url: "", label: 'Property Guidelines', icon: 'ClipboardCheck' },
  { id: 'booking', url: "", label: 'Booking History', icon: 'History' },
  { id: 'privacy', url: "", label: 'Privacy Policy', icon: 'Shield' },
];

const iconMap = {
  Home,
  Building,
  List,
  MessageCircle,
  Star,
  Calendar,
  HelpCircle,
  FileQuestion,
  ClipboardCheck,
  History,
  Shield,
  Settings,
};

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  const { user } = useAuth();
  const [SidebarContents, setSidebarContents] = useState<any[]>([]);

  useEffect(() => {
    console.log("user role ::: ", user, user?.role)
    switch(user?.role) {
      case "LANDLORD" : setSidebarContents(landLordSidebar ?? []);
      break;
      case "SUPER ADMIN" : setSidebarContents(adminSidebar ?? []);
      break;
      default: setSidebarContents([])
    }
  }, [user])

  const openChildren = () => {

  }

  return (
    <>      
      <div className=' flex flex-col gap-2 '>
        <div className='py-2 mx-[20px] border-b border-border'>
          <img src={IMAGES?.logo} />
        </div>
        <div className='py-2 px-[20px] h-[calc(100dvh-73px)] overflow-y-auto'>
          <div className='flex flex-col gap-1'>
            {
              SidebarContents?.map((section : any[]) => 
                <div className={`py-6 first:pt-0 first:border-b border-border flex flex-col gap-6 last:mb-3`}>
                  {section?.map((item) => 
                    <li className='list-none ' onClick={openChildren}>
                      <Link to={item.to} className='decoration-none flex gap-3 items-center' >
                      <div>
                        <Icon name={item?.icon} fill="none" className='w-4 h-4 text-primary' />
                      </div>
                    <div className='font-medium tracking-tight text-base text-muted-foreground flex items-center justify-between'>
                      <span>{item?.title}</span>
                      {item?.Children && <Icon name="ChevronDown" /> }
                    </div>
                  </Link>
                  {!!item?.Children && 
                  <ul>
                    {item?.Children?.map((childItem : any) => 
                    <li className='py-3 border-b border-border'>
                      <Link to={childItem?.to} className='flex gap-3 items-center'>
                        <Icon name={childItem?.icon} fill="none" className='w-4 h-4 text-primary' />
                        <span>{childItem?.title}</span>
                      </Link>
                    </li>
                    )}
                  </ul>
                  }
                  </li>)}
                </div>
              )
            }
          </div>
        </div>
      </div>
    </>
  );
};

{/* Sidebar */}
      // <div className={`
      //   h-full w-full bg-white shadow-lg transform          
      //   lg:translate-x-0 lg:static lg:shadow-none
      // `}>
      //   {/* Header */}
      //   <div className="flex items-center justify-between p-4 border-b">
      //     <div className="flex items-center space-x-2">
      //       <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
      //         <Home className="w-5 h-5 text-white" />
      //       </div>
      //       <span className="text-xl font-bold text-gray-800">RentMatch</span>
      //     </div>
      //     <button
      //       onClick={onToggle}
      //       className="lg:hidden p-1 rounded-md hover:bg-gray-100"
      //     >
      //       <X className="w-5 h-5" />
      //     </button>
      //   </div>

      //   {/* Navigation */}
      //   <nav className="pt-4 pl-4 pb-4 space-y-1">
      //     {navigationItems.map((item) => {
      //       const IconComponent = iconMap[item.icon as keyof typeof iconMap];
      //       return (
      //         <a
      //           key={item.id}
      //           href={item.url}
      //           className={`
      //             flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors
      //             ${item.active 
      //               ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700' 
      //               : 'text-gray-600 hover:bg-accent hover:text-gray-900'
      //             }
      //           `}
      //         >
      //           <IconComponent className="w-5 h-5" />
      //           <span className="flex-1">{item.label}</span>
      //           {item.hasNotification && (
      //             <div className="w-2 h-2 bg-green-500 rounded-full"></div>
      //           )}
      //         </a>
      //       );
      //     })}
      //   </nav>

      //   {/* Settings */}
      //   <div className="absolute bottom-4 left-4 right-4">
      //     <a
      //       href="#"
      //       className="flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-accent hover:text-gray-900 transition-colors"
      //     >
      //       <Settings className="w-5 h-5" />
      //       <span>Settings</span>
      //     </a>
      //   </div>
      // </div>