import React from "react";
import { Button } from "../../../../../ui/button";
import { Card, CardContent } from "../../../../../ui/card";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from 'react-intersection-observer';

const RentalPlansSection = () => {
  const [ref, inView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const pricingPlans = [
    {
      price: "$49",
      period: "/month",
      title: "Basic",
      description: "Better for growing businesses that want more customers.",
      features: [
        "Can list upto 2 properties",
        "Advanced dashboard",
        "All components included",
        "Advanced insight",
      ],
      buttonStyle: "filled",
      icons: [IMAGES.right, IMAGES.right, IMAGES.right, IMAGES.right],
    },
    {
      price: "$99",
      period: "/month",
      title: "Standard",
      description: "Better for growing businesses that want more customers.",
      features: [
        "Can list upto 2 properties",
        "Advanced dashboard",
        "All components included",
        "Advanced insight",
      ],
      buttonStyle: "outline",
      icons: [IMAGES.right, IMAGES.right, IMAGES.right, IMAGES.right],
    },
    {
      price: "$199",
      period: "/month",
      title: "Pro",
      description: "Better for growing businesses that want more customers.",
      features: [
        "Can list upto 2 properties",
        "Advanced dashboard",
        "All components included",
        "Advanced insight",
      ],
      buttonStyle: "outline",
      icons: [IMAGES.right, IMAGES.right, IMAGES.right, IMAGES.right],
    },
  ];
  return (
    <section className="w-full bg-[#f3f7fd] sm:py-8 md:py-[52px] sm:px-4 md:px-8 lg:px-[102px]">
      <div className="max-w-[1715px] mx-auto">
        <header className="mb-8">
          <div className="flex flex-col gap-1">
            <div className="[font-family:'Manrope',Helvetica] font-semibold text-primary text-lg tracking-[1.44px] leading-6">
              PLANS FOR LANDROD & PROPERTY MANAGER
            </div>
            <h2 className="[font-family:'Manrope',Helvetica] font-extrabold text-foreground text-2xl md:text-4xl tracking-[0] leading-tight md:leading-[44px]">
              Choose Your Right Plan
            </h2>
          </div>
        </header>

        <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 sm:gap-6 md:gap-[35px]">
          {pricingPlans.map((plan, index) => (
            <Card
              key={index} ref={ref}
              className={`bg-white rounded-[15.93px] border-0 shadow-sm hover:shadow-lg transition-shadow overflow-hidden border border-card-border ${inView ? 'animate__animated animate__slideInUp' : ''}`}
            style={{ animationDelay: `${index * 0.3}s` }}>
              <CardContent className="sm:p-4 md:p-[27.88px_26.56px]">
                <div className="flex flex-col sm:gap-4 md:gap-[19.92px]">
                  <div className="flex items-center sm:gap-2 md:gap-[13.28px]">
                    <div className="[font-family:'Manrope',Helvetica] font-bold text-primary sm:text-3xl md:text-[63.7px] tracking-[1.06px] leading-normal">
                      {plan.price}
                    </div>
                    <div className="[font-family:'Manrope',Helvetica] font-semibold text-[#63626a] sm:text-lg md:text-[31.9px] tracking-[0.23px] sm:leading-tight md:leading-[31.9px]">
                      {plan.period}
                    </div>
                  </div>

                  <div className="[font-family:'Manrope',Helvetica] font-bold text-[#3b3a40] sm:text-xl md:text-[23.9px] tracking-[0.45px] leading-normal">
                    {plan.title}
                  </div>

                  <div className="[font-family:'Manrope',Helvetica] font-normal text-[#63626a] sm:text-sm md:text-[18.6px] tracking-[0.23px] sm:leading-relaxed md:leading-[31.9px] sm:min-h-[50px] md:h-[63.73px]">
                    {plan.description}
                  </div>

                  <div className="w-full h-[1.33px] bg-black opacity-[0.08]" />

                  <div className="flex flex-col sm:gap-4 md:gap-[25.23px]">
                    {plan.features.map((feature, featureIndex) => (
                      <div
                        key={featureIndex}
                        className="flex items-start sm:gap-2 md:gap-[10px]"
                      >
                        <img
                          className="sm:w-6 sm:h-6 md:w-8 md:h-8 mt-[3px] flex-shrink-0"
                          alt="Feature icon"
                          src={plan.icons[featureIndex]}
                        />
                        <div className="[font-family:'Manrope',Helvetica] font-normal text-[#63626a] sm:text-sm md:text-[21.2px] tracking-[0.27px] sm:leading-relaxed md:leading-[34.5px]">
                          {feature}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-auto">
                    {plan.buttonStyle === "filled" ? (
                      <Button className="w-full sm:h-12 md:h-[82.82px] bg-primary hover:bg-[#2a4287] rounded-full [font-family:'Manrope',Helvetica] font-semibold text-white sm:text-base md:text-[21.2px] tracking-[0.27px]">
                        Buy This Plan
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        className="w-full sm:h-12 md:h-[82.82px] bg-white border-2 border-primary hover:bg-[#f8f9ff] rounded-full [font-family:'Manrope',Helvetica] font-semibold text-primary sm:text-base md:text-[21.2px] tracking-[0.27px]"
                      >
                        Buy This Plan
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
export default RentalPlansSection;
