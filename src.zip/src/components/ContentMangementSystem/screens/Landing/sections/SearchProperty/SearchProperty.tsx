import React, { useState } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../../ui/select";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Button } from "../../../../../ui/button";
import {
  MapPin,
  Search,
  Grid,
  List,
  Filter,
} from "lucide-react";
import { Input } from "../../../../../ui/input";
import { IMAGES } from "../../../../../../assets/index";
import GoogleMapComponent from "../../../../../ChildComponent/GoogleMapComponent";
import PropertyHorizontal from "../../../../../ChildComponent/PropertyHorizontal";
// import Property from "../../../../../ChildComponent/Property";
import { useInView } from 'react-intersection-observer';
import Slider from 'react-slick';
import Property from '../../../../../ChildComponent/Common/Property';

const SearchProperty = () => {
  const [searchRef, inSearchView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const [leftRef, inLeftView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const [rightRef, inRightView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const properties = [
    {
      id: 1,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "100 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 2,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 4,
      baths: 3,
      sqft: "120 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: false,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 3,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 2,
      baths: 1,
      sqft: "80 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: false,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 4,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "110 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: false,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 5,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$751.00",
      beds: 3,
      baths: 2,
      sqft: "110 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 6,
      title: "Casa Lomas De Machail Machala Casa Lomas De Machail Machala",
      location:
        "Premises no.03-319 Block, DH-6/11, Action Area 1D, Newtown, Kolkata, Chakpachuria, West Bengal 700160",
      price: "$752.00",
      beds: 3,
      baths: 2,
      sqft: "110 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
  ];
  const settingsHorizontal = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Duration for each slide (in milliseconds)
    vertical: true, // Enable vertical sliding
    verticalSwiping: true, // Enable vertical swiping
  };
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 1,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Duration for each slide (in milliseconds)
    vertical: false, // Enable vertical sliding
    verticalSwiping: true, // Enable vertical swiping
  };
  const [view, setView] = useState("horizontal");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const handleCardClick = (id: number) => {
    setSelectedId(selectedId === id ? null : id); // Toggle selection
  };
  return (
    <div className="bg-[#f3f7fd] py-8">
      <div className={`w-full mx-auto px-4 sm:px-6 lg:px-8 ${inSearchView ? 'animate__animated animate__slideInLeft' : ''}`} ref={searchRef}>
        {/* Search Filters */}
        <div className="rounded-lg mb-8">
          <div className="grid sm:grid-cols-1 md:grid-cols-4 gap-4 items-end">
            <div>
              {/* <label className="block text-sm font-medium text-foreground mb-2">Location</label> */}
              <div className="relative">
                <Input
                  placeholder="Location"
                  className="pr-10 rounded-[99px] bg-white h-10"
                />
                <MapPin className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              </div>
            </div>
            <div>
              {/* <label className="block text-sm font-medium text-foreground mb-2">Type</label> */}
              <Select>
                <SelectTrigger className="w-full rounded-[99px] bg-white h-10">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="house">House</SelectItem>
                  <SelectItem value="apartment">Apartment</SelectItem>
                  <SelectItem value="villa">Villa</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              {/* <label className="block text-sm font-medium text-foreground mb-2">Price</label> */}
              <Select>
                <SelectTrigger className="w-full rounded-[99px] bg-white h-10">
                  <SelectValue placeholder="Price" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-500">$0 - $500</SelectItem>
                  <SelectItem value="500-1000">$500 - $1000</SelectItem>
                  <SelectItem value="1000+">$1000+</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button className="bg-white hover:bg-blue-700 text-dark flex-1 rounded-[99px] h-10">
                Search advanced
                <Filter className="h-4 w-4 mr-2" />
              </Button>
              <Button
                variant="outline"
                className="px-4 bg-white hover:bg-blue-700 rounded-[99px] h-10"
              >
                Search
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 sm:bg-white md:py-8">
        <div className="flex sm:flex-col lg:flex-row gap-8">
          {/* Property Listings */}
          <div className={`lg:w-2/5 ${inLeftView ? 'animate__animated animate__slideInLeft' : ''}`} ref={leftRef}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                254 properties
              </h2>
              <div className="flex items-center gap-4">
                <Select defaultValue="default">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Sort by Default</SelectItem>
                    <SelectItem value="price-low">
                      Price: Low to High
                    </SelectItem>
                    <SelectItem value="price-high">
                      Price: High to Low
                    </SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex border rounded-lg">
                  <Button variant="ghost" size="sm" id="vertical_view" onClick={() => setView("vertical")}
          className={`px-3 ${view === "vertical" ? "bg-blue-500" : ""}`}>
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" id="horizontal_view" onClick={() => setView("horizontal")}
          className={`px-3 ${view === "horizontal" ? "bg-blue-500" : ""}`}>
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div id="horizontal_slider" style={{ display: view === "horizontal" ? "block" : "none",height: "500px",
                        overflowY: "auto", }}>
                {/* <Slider {...settingsHorizontal}> */}
                {properties.map((property) => (
                  <PropertyHorizontal
                    id={property.id}
                    title={property.title}
                    location={property.location}
                    price={property.price}
                    beds={property.beds}
                    baths={property.baths}
                    area={property.sqft}
                    image={property.image}
                    featured={property.featured}
                    forRent={property.forRent}
                    postedDate={property.postedDate}
                    type={property.type}
                    status={property.status}
                  />
                ))}
              {/* </Slider> */}
              </div>
              <div id="vertical_slider" style={{ display: view === "vertical" ? "block" : "none", height: "500px",
                        overflowY: "auto", }}>
                {/* <Slider {...settings}> */}
                <div className="grid grid-cols-2">
                  {properties.map((property) => (
                    <div key={property.id} className="px-2 col-span-1 mb-5">
                      <Property
                        id={property.id}
                        image={property.image}
                        type={property.type}
                        status={property.status}
                        location={property.location}
                        title={property.title}
                        beds={property.beds}
                        baths={property.baths}
                        sqft={property.sqft}
                        postedDate={property.postedDate}
                        price={property.price}
                        isSelected={false}
                        onCardClick={handleCardClick}
                      />
                    </div>
                  ))}
                </div>
                {/* </Slider> */}
              </div>
            </div>
          </div>

          {/* Map */}
          <div className={`lg:w-3/5 ${inRightView ? 'animate__animated animate__slideInRight' : ''}`} ref={rightRef}>
            <GoogleMapComponent />
          </div>
        </div>
      </div>
    </div>
  );
}
export default SearchProperty;