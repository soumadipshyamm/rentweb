import {
  ArrowRightIcon,
} from "lucide-react";
import React from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Button } from "../../../../../ui/button";
import Property from "../../../../../ChildComponent/Property";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from 'react-intersection-observer';
import Slider from "react-slick";


const FeaturedListingsSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true, // Trigger animation only once
    threshold: 0.3, // Trigger when 10% of the image is visible
  });
  const propertyListings = [
    {
      id: 1,
      image: IMAGES.villa_image,
      type: "House",
      status: "For Rent",
      location: "Califonia, New York",
      title: "Casa Lomas de Machalí Machas",
      beds: 4,
      baths: 2,
      sqft: 1150,
      postedDate: "16 Aug 2025",
      price: "$7250,00",
    },
    {
      id: 2,
      image: IMAGES.villa_image,
      type: "Office",
      status: "For Rent",
      location: "Califonia, New York",
      title: "Casa Lomas de Machalí Machas",
      beds: 4,
      baths: 2,
      sqft: 1150,
      postedDate: "16 Aug 2025",
      price: "$7250,00",
    },
    {
      id: 3,
      image: IMAGES.villa_image,
      type: "Villa",
      status: "For Rent",
      location: "Califonia, New York",
      title: "Casa Lomas de Machalí Machas",
      beds: 4,
      baths: 2,
      sqft: 1150,
      postedDate: "16 Aug 2025",
      price: "$7250,00",
    },
    {
      id: 4,
      image: IMAGES.villa_image,
      type: "Appartment",
      status: "For Rent",
      location: "Califonia, New York",
      title: "Casa Lomas de Machalí Machas",
      beds: 4,
      baths: 2,
      sqft: 1150,
      postedDate: "16 Aug 2025",
      price: "$7250,00",
    },
    {
      id: 4,
      image: IMAGES.villa_image,
      type: "Appartment",
      status: "For Rent",
      location: "Califonia, New York",
      title: "Casa Lomas de Machalí Machas",
      beds: 4,
      baths: 2,
      sqft: 1150,
      postedDate: "16 Aug 2025",
      price: "$7250,00",
    },
  ];
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Duration for each slide (in milliseconds)
    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1000,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <section className="w-full bg-[#f3f7fd] sm:py-8 md:py-[52px] relative">
      <div className="max-w-[1733px] mx-auto px-4">
        <div className="flex sm:flex-col md:flex-row justify-between items-start gap-4 sm:mb-8 md:mb-[62px]">
          <div className="flex flex-col gap-1">
            <div className="[font-family:'Manrope',Helvetica] font-semibold text-primary text-lg tracking-[1.44px] leading-6">
              FEATURED PROPERTIES
            </div>
            <h2 className="[font-family:'Manrope',Helvetica] font-extrabold text-foreground sm:text-2xl md:text-4xl tracking-[0] sm:leading-tight md:leading-[44px] max-w-[1341px]">
              Discover some of our most popular rental listings
            </h2>
          </div>
          <Button className="bg-primary hover:bg-muted text-white rounded-[99px] sm:px-6 md:px-10 py-[11px] h-[52px] gap-2 sm:w-full md:w-auto">
            <span className="[font-family:'Manrope',Helvetica] font-semibold text-base">
              View All
            </span>
            <ArrowRightIcon className="w-6 h-6" />
          </Button>
        </div>
        <div ref={ref} className={`grid grid-cols-1 sm:gap-4 md:gap-6 sm:mb-8 md:mb-[52px] ${inView ? 'animate__animated animate__slideInUp' : ''}`}>
          <Slider {...settings}>
            {propertyListings.map((property) => (
              <div key={property.id} className="px-2">
                <Property id={property.id} image={property.image} type={property.type} status={property.status} location={property.location} title={property.title} beds={property.beds} baths={property.baths} sqft={property.sqft} postedDate={property.postedDate} price={property.price}/>
              </div>
            ))}
          </Slider>
        </div>
      </div>
    </section>
  );
};
export default FeaturedListingsSection;
