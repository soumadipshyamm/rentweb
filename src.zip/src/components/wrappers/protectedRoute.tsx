import { useAuth } from '../../context/AuthContext';
import { ProtectedRouteProps } from '../../types/memberTypes';
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { User } from '../types';

export default function ProtectedRoute({ allowedRoles }: { allowedRoles?: ProtectedRouteProps[] }) {
  
  const { user, token, loading } = useAuth();
  
  if (loading) return <div>Loading...</div>;

  // Not logged in - redirect to login
  if (!token || !user) return <Navigate to="/login" replace />;

  // Role-restricted route
  if (allowedRoles && !allowedRoles.includes(user.role as any)) {
    // console.log("Why its coming here?", allowedRoles);
    
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />;
}