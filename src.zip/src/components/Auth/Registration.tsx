import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation
import { Card, CardContent } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Eye, EyeOff } from "lucide-react";
import { registrationSchema } from "@/src/types/authTypes";
import { toast } from "../../custom-hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { registrationMember } from "../../actions/auth";
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@radix-ui/react-select";
import { genders } from "../../constants/userType";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { registrationValidateSchema } from "../../schemas/auth";
import { FormError } from "../errors";

const defaultError = {
  "role": "TENANT",
  "first_name": "",
  "last_name": "",
  "user_name": "",
  "password": "",
  "confirm_password": "",
  "email": "",
  "gender": "",
  "phone_number": "",
}

const Registration = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate(); // Initialize navigate for redirection
  const [registrationPayload, setRegistrationPayload] = useState<registrationSchema>({
    "role": "TENANT",
    "first_name": "",
    "middle_name": "",
    "last_name": "",
    "user_name": "",
    "password": "",
    "confirm_password": "",
    "email": "",
    "gender": "",
    // "address_line_1": "kolkata",
    // "address_line_2": "kolkata",
    // "city": "kolkata",
    // "state": "WB",
    // "country": "I",
    // "zip": "700001",
    // "date_of_birth": "2022-09-11",
    // "contact_label": "HOME",
    "phone_number": "",
    // "phone_extension": "91"
  });
  const [errors, setErrors] = useState({ ...defaultError });

  const { mutate: registration, isPending } = useMutation({
    mutationFn: registrationMember,
    onSuccess: (data) => {
      localStorage?.removeItem("userInfo")
      // console.log("data :: ", data);
      // localStorage?.setItem('auth_token', data?.result?.token || null)
      // localStorage?.setItem('user_info', JSON.stringify(data?.result?.loginInstance || {}))
      toast({
        title: "Success",
        description: data?.message || 'Successfully logged in',
        variant: "success",
      })
      navigate("/login")
    },
    onError: (error: any) => {
      // setServerError(error.response?.err?.detail || 'Login failed');
      // console.log("error ::: ", error?.response?.data?.err?.details[0]?.message);

      toast({
        title: "Error",
        description: error?.response?.data?.message || 'Registration failed',
        variant: "error",
      });
    },
  });

  const handleVerifyOtp = () => {
    const validation = registrationValidateSchema.safeParse(registrationPayload)
    if (!validation?.success) {
      const fieldErrors: any = {};
      validation?.error?.issues?.forEach(err => {
        const field = err.path[0];
        fieldErrors[field as string] = err.message;
        setErrors(prev => ({
          ...prev,
          email: fieldErrors.email ?? "",
          role: fieldErrors.role ?? "",
          first_name: fieldErrors.first_name ?? "",
          last_name: fieldErrors.last_name ?? "",
          user_name: fieldErrors.user_name ?? "",
          password: fieldErrors.password ?? "",
          confirm_password: fieldErrors.confirm_password ?? "",
          gender: fieldErrors.gender ?? "",
          phone_number: fieldErrors.phone_number ?? "",
        }))
      })
      return;
    }
    setErrors(defaultError)
    // Logic to verify the OTP can be added here
    // const name = registrationPayload?.name
    const payload = { ...registrationPayload }
    delete payload?.confirm_password;
    // delete registrationPayload?.name
    registration(payload)
    // navigate("/login"); // Redirect to /dashboard
  };

  useEffect(() => {
    const userStorageInfo = localStorage?.getItem("userInfo")
    if (userStorageInfo) {
      const userInfo = JSON.parse(userStorageInfo);
      console.log("userInfo : ", userInfo);
      setRegistrationPayload(prev => ({ ...prev, email: userInfo?.email, role: userInfo?.role }))
    }
  }, [])

  const handleChange = (e: any) => {
    setErrors(prev => ({...prev, [e?.target?.name] : ""}))
    setRegistrationPayload(prev => {
      return { ...prev, [e?.target?.name]: e?.target?.value }
    })
  }

  // useEffect(() => {
  //   console.log("registration Payload ::: ", registrationPayload);
  // }, [registrationPayload])

  return (
    <main className="flex-1 flex items-center justify-center px-4 py-5">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-4">
          <p className="text-sm text-primary uppercase tracking-wide mb-2">
            WELCOME
          </p>
          <h1 className="text-3xl font-bold text-gray-900">
            Create an account as {registrationPayload?.role?.toLocaleLowerCase()}
          </h1>
          <p className="mx-auto">{registrationPayload?.email}</p>
        </div>

        <Card className="overflow-hidden shadow-lg bg-background">
          <CardContent className="p-0">
            <div className="flex flex-col justify-center p-7">
              <div className="w-full mx-auto space-y-6">
                <div className="flex gap-5">
                  <div className="w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="first_name"
                        className="text-sm font-medium text-foreground"
                      >
                        Your Name <span className="text-destructive">*</span>
                      </label>
                      <Input
                        id="first_name"
                        type="text"
                        name="first_name"
                        value={registrationPayload?.first_name}
                        className="h-10 text-base"
                        placeholder="Enter your name"
                        onChange={handleChange}
                      />
                    </div>
                    {errors?.first_name && <FormError message={errors?.first_name} />}
                  </div>
                  <div className="w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="middle_name"
                        className="text-sm font-medium text-foreground"
                      >
                        Your Middle Name
                      </label>
                      <Input
                        id="middle_name"
                        type="name"
                        name="middle_name"
                        value={registrationPayload?.middle_name}
                        className="h-10 text-base"
                        placeholder="Enter your middle name"
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
                <div className="flex gap-5">
                  <div className="w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="last_name"
                        className="text-sm font-medium text-foreground"
                      >
                        Your Last Name <span className="text-destructive">*</span>
                      </label>
                      <Input
                        id="last_name"
                        type="text"
                        name="last_name"
                        value={registrationPayload?.last_name}
                        className="h-10 text-base"
                        placeholder="Enter your name"
                        onChange={handleChange}
                      />
                    </div>
                    {errors?.last_name && <FormError message={errors?.last_name} />}
                  </div>
                  <div className="w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="user_name"
                        className="text-sm font-medium text-foreground"
                      >
                        Your User Name <span className="text-destructive">*</span>
                      </label>
                      <Input
                        id="user_name"
                        type="user_name"
                        name="user_name"
                        value={registrationPayload?.user_name}
                        className="h-10 text-base"
                        placeholder="Enter your user name"
                        onChange={handleChange}
                      />
                    </div>
                    {errors?.user_name && <FormError message={errors?.user_name} />}
                  </div>
                </div>
                <div className="flex gap-5">
                  <div className=" w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="gender"
                        className="text-sm font-medium text-foreground"
                      >
                        Your Gender <span className="text-destructive">*</span>
                      </label>
                      <Select value={registrationPayload.gender || undefined}
                        onValueChange={(value) =>
                          setRegistrationPayload((prev) => ({ ...prev, gender: value }))
                        }>
                        <SelectTrigger className="w-full h-12 py-0 rounded-md bg-white border border-border-input bg-background shadow-none ">
                          <SelectValue placeholder="Select Your Gender" />
                        </SelectTrigger>
                        <SelectContent>
                          {
                            genders?.map(gender =>
                              <SelectItem key={gender?.id} value={gender?.value}>{gender?.title}</SelectItem>
                            )
                          }
                        </SelectContent>
                      </Select>
                    </div>
                    {errors?.gender && <FormError message={errors?.gender} />}
                  </div>
                  <div className="w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="phone_number"
                        className="text-sm font-medium text-foreground"
                      >
                        Mobile Number <span className="text-destructive">*</span>
                      </label>
                      <Input
                        id="name"
                        type="number"
                        name="phone_number"
                        onChange={handleChange}
                        className="h-10 text-base"
                        placeholder="Enter mobile number"
                        value={registrationPayload?.phone_number}
                      />
                    </div>
                    {errors?.phone_number && <FormError message={errors?.phone_number} />}
                  </div>
                </div>
                <div className="flex gap-5">
                  <div className="flex flex-col space-y-1 w-full">
                    <label
                      htmlFor="password"
                      className="text-sm font-medium text-foreground"
                    >
                      Password <span className="text-destructive">*</span>
                    </label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        name="password"
                        value={registrationPayload?.password}
                        onChange={handleChange}
                        className="h-12 text-base pr-12"
                        placeholder="Enter your password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"

                        className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                        onClick={() => setShowPassword(prev => !prev)}
                      >
                        {showPassword ? (
                          <Eye className="h-4 w-4 text-gray-400" />
                        ) : (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                    {errors?.password && <FormError message={errors?.password} />}
                  </div>
                  <div className="w-full">
                    <div className="flex flex-col space-y-1 w-full">
                      <label
                        htmlFor="confirmpassword"
                        className="text-sm font-medium text-foreground"
                      >
                        Confirm Password <span className="text-destructive">*</span>
                      </label>
                      <div className="relative">
                        <Input
                          id="confirmpassword"
                          type={showConfirmPassword ? "text" : "password"}
                          name="confirm_password"
                          value={registrationPayload?.confirm_password}
                          onChange={handleChange}
                          className="h-12 text-base pr-12"
                          placeholder="Enter your password"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                          onClick={() => setShowConfirmPassword(prev => !prev)}
                        >
                          {showConfirmPassword ? (
                            <Eye className="h-4 w-4 text-gray-400" />
                          ) : (
                            <EyeOff className="h-4 w-4 text-gray-400" />
                          )}
                        </Button>
                      </div>
                    </div>
                    {errors?.confirm_password && <FormError message={errors?.confirm_password} />}
                  </div>
                </div>
                <div className="flex justify-center mb-2">
                  <Button
                    onClick={handleVerifyOtp}
                    className="cursor-pointer flex items-center justify-center gap-2 w-[154px] h-[54px] px-5 py-[11px] bg-primary rounded-full border border-solid hover:bg-muted h-auto"
                  >
                    <span className="[font-family:'Manrope',Helvetica] font-semibold text-background text-base tracking-[0] leading-[normal]">
                      Create Account
                    </span>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
};

export default Registration;
