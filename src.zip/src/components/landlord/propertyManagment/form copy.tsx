import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import Icon from "../../icons/icon";

const PropertyListingForm = () => {
    const navigate = useNavigate();
    const [currentStep, setCurrentStep] = useState(0);
    const [formData, setFormData] = useState({
        // Property Basics
        propertyName: "",
        propertyType: "",
        availableForRent: "",
        suburb: "",
        state: "",
        postcode: "",
        region: "",
        fullAddress: "",

        // Rent Details
        weeklyRent: "",
        bondDeposit: "",
        availableFrom: "",
        leaseTerms: "",

        // Property Features
        bedrooms: "",
        bathrooms: "",
        parking: "",
        landSize: "",
        floorArea: "",

        // Interior Features
        heatingCooling: {
            airConditioning: false,
            fans: false,
            ductedHeating: false
        },
        kitchenAppliances: {
            dishwasher: false,
            oven: false,
            stove: false,
            pantry: false
        },
        laundryFacilities: {
            inUnit: false,
            shared: false,
            dryer: false,
            washer: false
        },

        // Outdoor Features
        outdoorFeatures: {
            balcony: false,
            deck: false,
            courtyard: false,
            garden: false,
            yard: false
        },
        outdoorEntertaining: {
            shed: false,
            storage: false
        },

        // Additional Information
        pets: "",
        description: "",
        energyRating: "",

        // Images & Documents
        images: [],
        videos: [],
        floorPlans: []
    });

    const steps = [
        "Property Basics",
        "Rent Details",
        "Property Features",
        "Interior Features",
        "Outdoor Features",
        "Additional Information",
        "Property Images & Documents"
    ];

    const propertyTypes = [
        "House", "Apartment", "Unit", "Townhouse", "Villa", "Studio", "Duplex", "Granny Flat"
    ];

    const states = ["NSW", "VIC", "QLD", "WA", "SA", "TAS", "ACT", "NT"];
    const leaseTerms = ["6 months", "12 months", "24 months", "Month-to-month"];

    const handleInputChange = (field, value) => {
        setFormData(prev => ({
            ...prev,
            [field]: value
        }));
    };

    const handleNestedChange = (parent, field, value) => {
        setFormData(prev => ({
            ...prev,
            [parent]: {
                ...prev[parent],
                [field]: value
            }
        }));
    };

    const nextStep = () => {
        if (currentStep < steps.length - 1) {
            setCurrentStep(currentStep + 1);
        }
    };

    const prevStep = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    const handleSubmit = () => {
        console.log("Form submitted:", formData);
        // Handle form submission logic here
        navigate("/properties");
    };

    const renderStepContent = () => {
        switch (currentStep) {
            case 0: // Property Basics
                return (
                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Property Name *
                            </label>
                            <Input
                                value={formData.propertyName}
                                onChange={(e) => handleInputChange("propertyName", e.target.value)}
                                placeholder="Enter property name"
                                className="w-full"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Property Type *
                            </label>
                            <select
                                value={formData.propertyType}
                                onChange={(e) => handleInputChange("propertyType", e.target.value)}
                                className="w-full p-2 border border-gray-300 rounded-lg"
                            >
                                <option value="">Select property type</option>
                                {propertyTypes.map(type => (
                                    <option key={type} value={type}>{type}</option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Available for Rent? *
                            </label>
                            <select
                                value={formData.availableForRent}
                                onChange={(e) => handleInputChange("availableForRent", e.target.value)}
                                className="w-full p-2 border border-gray-300 rounded-lg"
                            >
                                <option value="">Select availability</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                                <option value="soon">Available Soon</option>
                            </select>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Suburb *
                                </label>
                                <Input
                                    value={formData.suburb}
                                    onChange={(e) => handleInputChange("suburb", e.target.value)}
                                    placeholder="Enter suburb"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    State *
                                </label>
                                <select
                                    value={formData.state}
                                    onChange={(e) => handleInputChange("state", e.target.value)}
                                    className="w-full p-2 border border-gray-300 rounded-lg"
                                >
                                    <option value="">Select state</option>
                                    {states.map(state => (
                                        <option key={state} value={state}>{state}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Postcode *
                                </label>
                                <Input
                                    value={formData.postcode}
                                    onChange={(e) => handleInputChange("postcode", e.target.value)}
                                    placeholder="Enter postcode"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Region / Area
                            </label>
                            <Input
                                value={formData.region}
                                onChange={(e) => handleInputChange("region", e.target.value)}
                                placeholder="Enter region or area"
                                className="w-full"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Full Address *
                            </label>
                            <Input
                                value={formData.fullAddress}
                                onChange={(e) => handleInputChange("fullAddress", e.target.value)}
                                placeholder="Enter full address"
                                className="w-full"
                            />
                        </div>
                    </div>
                );

            case 1: // Rent Details
                return (
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Weekly Rent Price *
                                </label>
                                <div className="relative">
                                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                                    <Input
                                        type="number"
                                        value={formData.weeklyRent}
                                        onChange={(e) => handleInputChange("weeklyRent", e.target.value)}
                                        placeholder="0.00"
                                        className="w-full pl-8"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Bond / Security Deposit *
                                </label>
                                <div className="relative">
                                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                                    <Input
                                        type="number"
                                        value={formData.bondDeposit}
                                        onChange={(e) => handleInputChange("bondDeposit", e.target.value)}
                                        placeholder="0.00"
                                        className="w-full pl-8"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Available From *
                                </label>
                                <Input
                                    type="date"
                                    value={formData.availableFrom}
                                    onChange={(e) => handleInputChange("availableFrom", e.target.value)}
                                    className="w-full"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Lease Terms *
                                </label>
                                <select
                                    value={formData.leaseTerms}
                                    onChange={(e) => handleInputChange("leaseTerms", e.target.value)}
                                    className="w-full p-2 border border-gray-300 rounded-lg"
                                >
                                    <option value="">Select lease term</option>
                                    {leaseTerms.map(term => (
                                        <option key={term} value={term}>{term}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>
                );

            case 2: // Property Features
                return (
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        No Of Bedrooms *
                                    </label>
                                    <Input
                                        type="number"
                                        value={formData.bedrooms}
                                        onChange={(e) => handleInputChange("bedrooms", e.target.value)}
                                        placeholder="0"
                                        className="w-full"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        No Of Bathrooms *
                                    </label>
                                    <Input
                                        type="number"
                                        value={formData.bathrooms}
                                        onChange={(e) => handleInputChange("bathrooms", e.target.value)}
                                        placeholder="0"
                                        className="w-full"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Parking *
                                    </label>
                                    <Input
                                        value={formData.parking}
                                        onChange={(e) => handleInputChange("parking", e.target.value)}
                                        placeholder="Car spaces / Parking"
                                        className="w-full"
                                    />
                                </div>
                            </div>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Land Size
                                    </label>
                                    <div className="flex gap-2">
                                        <Input
                                            type="number"
                                            value={formData.landSize}
                                            onChange={(e) => handleInputChange("landSize", e.target.value)}
                                            placeholder="0"
                                            className="flex-1"
                                        />
                                        <span className="flex items-center px-3 bg-gray-100 border border-gray-300 rounded-lg">
                                            m²
                                        </span>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Floor Area
                                    </label>
                                    <div className="flex gap-2">
                                        <Input
                                            type="number"
                                            value={formData.floorArea}
                                            onChange={(e) => handleInputChange("floorArea", e.target.value)}
                                            placeholder="0"
                                            className="flex-1"
                                        />
                                        <span className="flex items-center px-3 bg-gray-100 border border-gray-300 rounded-lg">
                                            m²
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                );

            case 3: // Interior Features
                return (
                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Heating / Cooling *
                            </label>
                            <div className="space-y-2">
                                {[
                                    { key: "airConditioning", label: "Air conditioning" },
                                    { key: "fans", label: "Fans" },
                                    { key: "ductedHeating", label: "Ducted Heating" }
                                ].map(item => (
                                    <label key={item.key} className="flex items-center space-x-3">
                                        <input
                                            type="checkbox"
                                            checked={formData.heatingCooling[item.key]}
                                            onChange={(e) => handleNestedChange("heatingCooling", item.key, e.target.checked)}
                                            className="w-4 h-4 text-blue-600 rounded"
                                        />
                                        <span className="text-sm text-gray-700">{item.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Kitchen Appliances *
                            </label>
                            <div className="space-y-2">
                                {[
                                    { key: "dishwasher", label: "Dishwasher" },
                                    { key: "oven", label: "Oven" },
                                    { key: "stove", label: "Stove" },
                                    { key: "pantry", label: "Pantry" }
                                ].map(item => (
                                    <label key={item.key} className="flex items-center space-x-3">
                                        <input
                                            type="checkbox"
                                            checked={formData.kitchenAppliances[item.key]}
                                            onChange={(e) => handleNestedChange("kitchenAppliances", item.key, e.target.checked)}
                                            className="w-4 h-4 text-blue-600 rounded"
                                        />
                                        <span className="text-sm text-gray-700">{item.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Laundry Facilities *
                            </label>
                            <div className="space-y-2">
                                {[
                                    { key: "inUnit", label: "In-unit" },
                                    { key: "shared", label: "Shared" },
                                    { key: "dryer", label: "Dryer" },
                                    { key: "washer", label: "Washer" }
                                ].map(item => (
                                    <label key={item.key} className="flex items-center space-x-3">
                                        <input
                                            type="checkbox"
                                            checked={formData.laundryFacilities[item.key]}
                                            onChange={(e) => handleNestedChange("laundryFacilities", item.key, e.target.checked)}
                                            className="w-4 h-4 text-blue-600 rounded"
                                        />
                                        <span className="text-sm text-gray-700">{item.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>
                );

            case 4: // Outdoor Features
                return (
                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Outdoor Features
                            </label>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                {[
                                    { key: "balcony", label: "Balcony" },
                                    { key: "deck", label: "Deck" },
                                    { key: "courtyard", label: "Courtyard" },
                                    { key: "garden", label: "Garden" },
                                    { key: "yard", label: "Yard" }
                                ].map(item => (
                                    <label key={item.key} className="flex items-center space-x-3">
                                        <input
                                            type="checkbox"
                                            checked={formData.outdoorFeatures[item.key]}
                                            onChange={(e) => handleNestedChange("outdoorFeatures", item.key, e.target.checked)}
                                            className="w-4 h-4 text-blue-600 rounded"
                                        />
                                        <span className="text-sm text-gray-700">{item.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Outdoor Entertaining Area *
                            </label>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                {[
                                    { key: "shed", label: "Shed" },
                                    { key: "storage", label: "Storage" }
                                ].map(item => (
                                    <label key={item.key} className="flex items-center space-x-3">
                                        <input
                                            type="checkbox"
                                            checked={formData.outdoorEntertaining[item.key]}
                                            onChange={(e) => handleNestedChange("outdoorEntertaining", item.key, e.target.checked)}
                                            className="w-4 h-4 text-blue-600 rounded"
                                        />
                                        <span className="text-sm text-gray-700">{item.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>
                );

            case 5: // Additional Information
                return (
                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-3">
                                Pets *
                            </label>
                            <div className="flex gap-4">
                                {["Allowed", "Not Allowed", "Case-by-case"].map(option => (
                                    <label key={option} className="flex items-center space-x-2">
                                        <input
                                            type="radio"
                                            name="pets"
                                            value={option.toLowerCase()}
                                            checked={formData.pets === option.toLowerCase()}
                                            onChange={(e) => handleInputChange("pets", e.target.value)}
                                            className="w-4 h-4 text-blue-600"
                                        />
                                        <span className="text-sm text-gray-700">{option}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Description *
                            </label>
                            <textarea
                                value={formData.description}
                                onChange={(e) => handleInputChange("description", e.target.value)}
                                placeholder="Enter property description"
                                rows={6}
                                className="w-full p-3 border border-gray-300 rounded-lg resize-none"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Energy Rating
                            </label>
                            <Input
                                value={formData.energyRating}
                                onChange={(e) => handleInputChange("energyRating", e.target.value)}
                                placeholder="Enter energy rating"
                                className="w-full"
                            />
                        </div>
                    </div>
                );

            case 6: // Property Images & Documents
                return (
                    <div className="space-y-8">
                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                            <Icon name="UploadIcon" className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">Property Images</h3>
                            <p className="text-gray-500 mb-4">Drag or upload your property images</p>
                            <Button variant="outline" className="border-blue-600 text-blue-600">
                                Upload Images
                            </Button>
                        </div>

                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                            <Icon name="VideoIcon" className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">Property Videos</h3>
                            <p className="text-gray-500 mb-4">Drag or upload your property videos</p>
                            <Button variant="outline" className="border-blue-600 text-blue-600">
                                Upload Videos
                            </Button>
                        </div>

                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                            <Icon name="FloorPlanIcon" className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">Floor Plans</h3>
                            <p className="text-gray-500 mb-4">Upload floor plans and documents</p>
                            <Button variant="outline" className="border-blue-600 text-blue-600">
                                Upload Floor Plans
                            </Button>
                        </div>
                    </div>
                );

            default:
                return null;
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 py-8">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Header */}
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">List Your Property</h1>
                    <p className="text-gray-600 mt-2">Fill in the details to list your property for rent</p>
                </div>

                {/* Progress Steps */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
                    <div className="flex justify-between items-center mb-8">
                        {steps.map((step, index) => (
                            <div key={step} className="flex flex-col items-center">
                                <div
                                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium ${
                                        index === currentStep
                                            ? "bg-blue-600 text-white"
                                            : index < currentStep
                                            ? "bg-green-500 text-white"
                                            : "bg-gray-200 text-gray-500"
                                    }`}
                                >
                                    {index + 1}
                                </div>
                                <span
                                    className={`text-xs mt-2 ${
                                        index === currentStep
                                            ? "text-blue-600 font-medium"
                                            : "text-gray-500"
                                    }`}
                                >
                                    {step}
                                </span>
                            </div>
                        ))}
                    </div>

                    {/* Step Content */}
                    <div className="bg-gray-50 rounded-lg p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-6">
                            {steps[currentStep]}
                        </h2>
                        {renderStepContent()}
                    </div>

                    {/* Navigation Buttons */}
                    <div className="flex justify-between mt-8">
                        <Button
                            variant="outline"
                            onClick={prevStep}
                            disabled={currentStep === 0}
                            className="px-6"
                        >
                            Previous
                        </Button>
                        
                        {currentStep === steps.length - 1 ? (
                            <Button
                                onClick={handleSubmit}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-8"
                            >
                                Submit Property
                            </Button>
                        ) : (
                            <Button
                                onClick={nextStep}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-8"
                            >
                                Next
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PropertyListingForm;