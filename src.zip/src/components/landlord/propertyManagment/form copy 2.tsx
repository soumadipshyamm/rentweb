import React, { useState } from "react";
import { Label } from "../../ui/label";
import { Input } from "../../ui/input";
import { Button } from "../../ui/button";
import { toast } from "../../../custom-hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";

const PropertyListingForm = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const queryClient = useQueryClient();

    const editData = location.state || {};

    const [payload, setPayload] = useState({
        propertyName: editData.propertyName || "",
        propertyType: editData.propertyType || "",
        available: editData.available || false,
        suburb: editData.suburb || "",
        state: editData.state || "",
        postcode: editData.postcode || "",
        region: editData.region || "",
        fullAddress: editData.fullAddress || "",
    });

    const [errors, setErrors] = useState({});

    // ---- API Mutation ----
    const { mutate, isPending } = useMutation({
        mutationFn: (payload) => createPropertyBasicsApi(payload),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["propertyBasics"] });
            toast({
                title: `Property Basics Saved`,
                description: `Your property information has been saved successfully.`,
                variant: "success",
            });
            navigate("/property/rent-details");
        },
        onError: () => {
            toast({
                title: `Failed`,
                description: `Unable to save property basics. Please try again.`,
                variant: "error",
            });
        },
    });

    // ---- Form Validation + Submit ----
    const handleSubmit = () => {
        const validation = createPropertyBasicsSchema.safeParse(payload);

        if (!validation.success) {
            const formErrors = {};
            validation.error.issues.forEach((er) => {
                formErrors[er.path[0]] = er.message;
            });
            setErrors(formErrors);
            return;
        }

        mutate(payload);
    };

    // ---- Input Change Handler ----
    const handleChange = (e) => {
        const { name, value } = e.target;
        setErrors((prev) => ({ ...prev, [name]: "" }));
        setPayload((prev) => ({ ...prev, [name]: value }));
    };

    // ---- Toggle ----
    const handleToggle = () => {
        setPayload((prev) => ({ ...prev, available: !prev.available }));
    };

    return (
        <div className="bg-white p-8 rounded-lg shadow-sm max-w-[95%] mx-auto">

            {/* ---------- Tabs ---------- */}
            <div className="border-b mb-8 flex gap-8 text-sm">
                <button className="pb-3 border-b-2 border-blue-600 text-blue-600 font-medium">
                    Property Basics
                </button>
                <button className="pb-3 text-gray-500">Rent Details</button>
                <button className="pb-3 text-gray-500">Property Features</button>
                <button className="pb-3 text-gray-500">Interior Features</button>
                <button className="pb-3 text-gray-500">Outdoor Features</button>
                <button className="pb-3 text-gray-500">Additional Info</button>
                <button className="pb-3 text-gray-500">Images & Docs</button>
            </div>

            {/* ---------- Form Fields ---------- */}
            <div className="flex flex-col gap-8">

                {/* Property Name */}
                <div className="flex flex-col gap-2">
                    <Label className="font-medium">
                        Property Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                        name="propertyName"
                        placeholder="Add"
                        value={payload.propertyName}
                        onChange={handleChange}
                        className="p-3"
                    />
                </div>

                {/* Property Type + Toggle */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
                    <div className="lg:col-span-2 flex flex-col gap-2">
                        <Label className="font-medium">
                            Property Type <span className="text-red-500">*</span>
                        </Label>
                        <Input
                            name="propertyType"
                            placeholder="House / Apartment / Unit / Villa ..."
                            value={payload.propertyType}
                            onChange={handleChange}
                            className="p-3"
                        />
                    </div>

                    {/* Toggle */}
                    <div className="flex items-center gap-3 mt-6">
                        <span className="text-sm font-medium">
                            Available for Rent? <span className="text-red-500">*</span>
                        </span>

                        <label className="relative inline-flex cursor-pointer">
                            <input
                                type="checkbox"
                                className="sr-only peer"
                                checked={payload.available}
                                onChange={handleToggle}
                            />
                            <div className="w-11 h-6 bg-gray-300 peer-checked:bg-blue-600 rounded-full transition"></div>
                            <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full peer-checked:translate-x-5 transition"></div>
                        </label>
                    </div>
                </div>

                {/* Suburb / State / Postcode / Region */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

                    <div className="flex flex-col gap-2">
                        <Label>
                            Suburb <span className="text-red-500">*</span>
                        </Label>
                        <Input
                            name="suburb"
                            placeholder="Select"
                            value={payload.suburb}
                            onChange={handleChange}
                        />
                    </div>

                    <div className="flex flex-col gap-2">
                        <Label>
                            State <span className="text-red-500">*</span>
                        </Label>
                        <Input
                            name="state"
                            placeholder="Select"
                            value={payload.state}
                            onChange={handleChange}
                        />
                    </div>

                    <div className="flex flex-col gap-2">
                        <Label>
                            Postcode <span className="text-red-500">*</span>
                        </Label>
                        <Input
                            name="postcode"
                            placeholder="Add"
                            value={payload.postcode}
                            onChange={handleChange}
                        />
                    </div>

                    <div className="flex flex-col gap-2">
                        <Label>Region / Area</Label>
                        <Input
                            name="region"
                            placeholder="Add"
                            value={payload.region}
                            onChange={handleChange}
                        />
                    </div>
                </div>

                {/* Full Address */}
                <div className="flex flex-col gap-2">
                    <Label>
                        Full Address <span className="text-red-500">*</span>
                    </Label>
                    <Input
                        name="fullAddress"
                        placeholder="Add"
                        value={payload.fullAddress}
                        onChange={handleChange}
                        className="p-3"
                    />
                </div>
            </div>

            {/* ---------- Continue Button ---------- */}
            <div className="flex justify-end mt-12">
                <Button
                    onClick={handleSubmit}
                    disabled={isPending}
                    className="bg-[#2D4BA3] text-white rounded-full px-10 py-3 shadow-md"
                >
                    {isPending ? "Saving..." : "Continue"}
                </Button>
            </div>
        </div>
    );
};

export default PropertyListingForm;
