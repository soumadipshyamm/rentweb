import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getPropertyTypeList } from "../../../actions/propertyMaster";
import useDebounce from "../../../custom-hooks/debounce";
import Icon from "../../icons/icon";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";

// Property images - using direct URLs to avoid TypeScript issues
const PROPERTY_IMAGES = {
  property1: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=600&h=400&fit=crop",
  property2: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&h=400&fit=crop",
  property3: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&h=400&fit=crop",
  property4: "https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=600&h=400&fit=crop",
};

const PropertyManagementSystem = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("properties"); // "properties" or "add-property"
  const [globalFilter, setGlobalFilter] = useState("");
  const [params, setParams] = useState<{ search?: string }>({});
  
  // Property Listing State
  const [properties, setProperties] = useState<any[]>([]);
  const [selectedProperties, setSelectedProperties] = useState<any[]>([]);

  // Property Form State
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    // Property Basics
    propertyName: "",
    propertyType: "",
    availableForRent: "",
    suburb: "",
    state: "",
    postcode: "",
    region: "",
    fullAddress: "",

    // Rent Details
    weeklyRent: "",
    bondDeposit: "",
    availableFrom: "",
    leaseTerms: "",

    // Property Features
    bedrooms: "",
    bathrooms: "",
    parking: "",
    landSize: "",
    floorArea: "",

    // Interior Features
    heatingCooling: {
      airConditioning: false,
      fans: false,
      ductedHeating: false
    },
    kitchenAppliances: {
      dishwasher: false,
      oven: false,
      stove: false,
      pantry: false
    },
    laundryFacilities: {
      inUnit: false,
      shared: false,
      dryer: false,
      washer: false
    },

    // Outdoor Features
    outdoorFeatures: {
      balcony: false,
      deck: false,
      courtyard: false,
      garden: false,
      yard: false
    },
    outdoorEntertaining: {
      shed: false,
      storage: false
    },

    // Additional Information
    pets: "",
    description: "",
    energyRating: "",

    // Images & Documents
    images: [],
    videos: [],
    floorPlans: []
  });

  // Fetch properties
  const { data, isLoading } = useQuery({
    queryKey: ['propertyType', params],
    queryFn: () => getPropertyTypeList(params),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    setProperties(data?.result || []);
  }, [data]);

  const debounceSearch = useDebounce(globalFilter, 300);

  useEffect(() => {
    if (debounceSearch === '') {
      setParams(prev => {
        const { search, ...rest } = prev;
        return rest;
      })
      return
    }
    setParams(prev => ({ ...prev, search: debounceSearch }))
  }, [debounceSearch]);

  // Mock properties data
  const mockProperties = [
    {
      id: 1,
      name: "Casa Lomas De Machali Machas",
      beds: 4,
      baths: 2,
      area: 1150,
      location: "Downtown San Francisco",
      price: "$1250.00/month",
      status: "Available for Rent",
      image: PROPERTY_IMAGES.property1,
      rating: 4.8,
      reviews: 124,
      amenities: ["Parking", "Pet Friendly", "Gym"],
      isFavorite: false
    },
    {
      id: 2,
      name: "Modern Downtown Apartment",
      beds: 3,
      baths: 2,
      area: 950,
      location: "Midtown Manhattan",
      price: "$2200.00/month",
      status: "Available for Rent",
      image: PROPERTY_IMAGES.property2,
      rating: 4.6,
      reviews: 89,
      amenities: ["Pool", "Security", "Balcony"],
      isFavorite: true
    },
    {
      id: 3,
      name: "Luxury Beach Villa",
      beds: 5,
      baths: 4,
      area: 2200,
      location: "Miami Beach",
      price: "$4500.00/month",
      status: "Available for Rent",
      image: PROPERTY_IMAGES.property3,
      rating: 4.9,
      reviews: 156,
      amenities: ["Beach Access", "Pool", "Garden"],
      isFavorite: false
    },
    {
      id: 4,
      name: "Urban Studio Loft",
      beds: 1,
      baths: 1,
      area: 650,
      location: "Chicago Downtown",
      price: "$950.00/month",
      status: "Available for Rent",
      image: PROPERTY_IMAGES.property4,
      rating: 4.4,
      reviews: 78,
      amenities: ["Furnished", "Utilities Included", "Rooftop"],
      isFavorite: false
    }
  ];

  const displayProperties = properties.length > 0 ? properties : mockProperties;

  // Form Steps Configuration
  const steps = [
    "Property Basics",
    "Rent Details",
    "Property Features",
    "Interior Features",
    "Outdoor Features",
    "Additional Information",
    "Property Images & Documents"
  ];

  const propertyTypes = [
    "House", "Apartment", "Unit", "Townhouse", "Villa", "Studio", "Duplex", "Granny Flat"
  ];

  const states = ["NSW", "VIC", "QLD", "WA", "SA", "TAS", "ACT", "NT"];
  const leaseTerms = ["6 months", "12 months", "24 months", "Month-to-month"];

  // Form Handlers
  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNestedChange = (parent, field, value) => {
    setFormData(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [field]: value
      }
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    console.log("Form submitted:", formData);
    // Handle form submission logic here
    setActiveTab("properties");
    // Reset form
    setFormData({
      propertyName: "", propertyType: "", availableForRent: "", suburb: "", state: "", 
      postcode: "", region: "", fullAddress: "", weeklyRent: "", bondDeposit: "", 
      availableFrom: "", leaseTerms: "", bedrooms: "", bathrooms: "", parking: "", 
      landSize: "", floorArea: "", heatingCooling: { airConditioning: false, fans: false, ductedHeating: false },
      kitchenAppliances: { dishwasher: false, oven: false, stove: false, pantry: false },
      laundryFacilities: { inUnit: false, shared: false, dryer: false, washer: false },
      outdoorFeatures: { balcony: false, deck: false, courtyard: false, garden: false, yard: false },
      outdoorEntertaining: { shed: false, storage: false }, pets: "", description: "", energyRating: "",
      images: [], videos: [], floorPlans: []
    });
    setCurrentStep(0);
  };

  const handleViewDetails = (propertyId) => {
    navigate(`/property/${propertyId}`);
  };

  const toggleFavorite = (propertyId) => {
    setProperties(prev => prev.map(property => 
      property.id === propertyId 
        ? { ...property, isFavorite: !property.isFavorite }
        : property
    ));
  };

  // Render Property Form Steps
  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Property Basics
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Property Name *</label>
                <Input value={formData.propertyName} onChange={(e) => handleInputChange("propertyName", e.target.value)} placeholder="Add property name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Property Type *</label>
                <select value={formData.propertyType} onChange={(e) => handleInputChange("propertyType", e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg">
                  <option value="">Select property type</option>
                  {propertyTypes.map(type => <option key={type} value={type}>{type}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Available for Rent? *</label>
              <select value={formData.availableForRent} onChange={(e) => handleInputChange("availableForRent", e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg">
                <option value="">Select availability</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
                <option value="soon">Available Soon</option>
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Suburb *</label>
                <Input value={formData.suburb} onChange={(e) => handleInputChange("suburb", e.target.value)} placeholder="Select suburb" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">State *</label>
                <select value={formData.state} onChange={(e) => handleInputChange("state", e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg">
                  <option value="">Select state</option>
                  {states.map(state => <option key={state} value={state}>{state}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Postcode *</label>
                <Input value={formData.postcode} onChange={(e) => handleInputChange("postcode", e.target.value)} placeholder="Add postcode" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Region / Area</label>
              <Input value={formData.region} onChange={(e) => handleInputChange("region", e.target.value)} placeholder="Add region/area" />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Full Address *</label>
              <Input value={formData.fullAddress} onChange={(e) => handleInputChange("fullAddress", e.target.value)} placeholder="Add full address" />
            </div>
          </div>
        );

      case 1: // Rent Details
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Weekly Rent Price *</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input type="number" value={formData.weeklyRent} onChange={(e) => handleInputChange("weeklyRent", e.target.value)} placeholder="Add amount" className="pl-8" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Bond / Security Deposit *</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input type="number" value={formData.bondDeposit} onChange={(e) => handleInputChange("bondDeposit", e.target.value)} placeholder="Add amount" className="pl-8" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Available From *</label>
                <Input type="date" value={formData.availableFrom} onChange={(e) => handleInputChange("availableFrom", e.target.value)} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Lease Terms *</label>
                <select value={formData.leaseTerms} onChange={(e) => handleInputChange("leaseTerms", e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg">
                  <option value="">Select lease term</option>
                  {leaseTerms.map(term => <option key={term} value={term}>{term}</option>)}
                </select>
              </div>
            </div>
          </div>
        );

      case 2: // Property Features
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">No Of Bedrooms *</label>
                  <Input type="number" value={formData.bedrooms} onChange={(e) => handleInputChange("bedrooms", e.target.value)} placeholder="Add bedrooms" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">No Of Bathrooms *</label>
                  <Input type="number" value={formData.bathrooms} onChange={(e) => handleInputChange("bathrooms", e.target.value)} placeholder="Add bathrooms" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Parking *</label>
                  <Input value={formData.parking} onChange={(e) => handleInputChange("parking", e.target.value)} placeholder="Car Spaces / Parking" />
                </div>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Land Size</label>
                  <div className="flex gap-2">
                    <Input type="number" value={formData.landSize} onChange={(e) => handleInputChange("landSize", e.target.value)} placeholder="Add land size" />
                    <span className="flex items-center px-4 bg-gray-100 border border-gray-300 rounded-lg text-gray-600">m²</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Floor Area</label>
                  <div className="flex gap-2">
                    <Input type="number" value={formData.floorArea} onChange={(e) => handleInputChange("floorArea", e.target.value)} placeholder="Add floor area" />
                    <span className="flex items-center px-4 bg-gray-100 border border-gray-300 rounded-lg text-gray-600">m²</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 3: // Interior Features
        return (
          <div className="space-y-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Heating / Cooling *</label>
              <div className="space-y-3">
                {["airConditioning", "fans", "ductedHeating"].map((item) => (
                  <label key={item} className="flex items-center space-x-3">
                    <input type="checkbox" checked={formData.heatingCooling[item]} onChange={(e) => handleNestedChange("heatingCooling", item, e.target.checked)} className="w-5 h-5 text-blue-600 rounded" />
                    <span className="text-gray-700 capitalize">{item.replace(/([A-Z])/g, ' $1').trim()}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Kitchen Appliances *</label>
              <div className="space-y-3">
                {["dishwasher", "oven", "stove", "pantry"].map((item) => (
                  <label key={item} className="flex items-center space-x-3">
                    <input type="checkbox" checked={formData.kitchenAppliances[item]} onChange={(e) => handleNestedChange("kitchenAppliances", item, e.target.checked)} className="w-5 h-5 text-blue-600 rounded" />
                    <span className="text-gray-700 capitalize">{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Laundry Facilities *</label>
              <div className="space-y-3">
                {["inUnit", "shared", "dryer", "washer"].map((item) => (
                  <label key={item} className="flex items-center space-x-3">
                    <input type="checkbox" checked={formData.laundryFacilities[item]} onChange={(e) => handleNestedChange("laundryFacilities", item, e.target.checked)} className="w-5 h-5 text-blue-600 rounded" />
                    <span className="text-gray-700 capitalize">{item.replace(/([A-Z])/g, ' $1').trim()}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 4: // Outdoor Features
        return (
          <div className="space-y-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Outdoor Features</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {["balcony", "deck", "courtyard", "garden", "yard"].map((item) => (
                  <label key={item} className="flex items-center space-x-3">
                    <input type="checkbox" checked={formData.outdoorFeatures[item]} onChange={(e) => handleNestedChange("outdoorFeatures", item, e.target.checked)} className="w-5 h-5 text-blue-600 rounded" />
                    <span className="text-gray-700 capitalize">{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Outdoor Entertaining Area *</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {["shed", "storage"].map((item) => (
                  <label key={item} className="flex items-center space-x-3">
                    <input type="checkbox" checked={formData.outdoorEntertaining[item]} onChange={(e) => handleNestedChange("outdoorEntertaining", item, e.target.checked)} className="w-5 h-5 text-blue-600 rounded" />
                    <span className="text-gray-700 capitalize">{item}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 5: // Additional Information
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Pets *</label>
              <div className="flex gap-6">
                {["Allowed", "Not Allowed", "Case-by-case"].map((option) => (
                  <label key={option} className="flex items-center space-x-2">
                    <input type="radio" name="pets" value={option.toLowerCase()} checked={formData.pets === option.toLowerCase()} onChange={(e) => handleInputChange("pets", e.target.value)} className="w-4 h-4 text-blue-600" />
                    <span className="text-gray-700">{option}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description *</label>
              <textarea value={formData.description} onChange={(e) => handleInputChange("description", e.target.value)} placeholder="Add description" rows={6} className="w-full p-3 border border-gray-300 rounded-lg resize-none" />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Energy Rating</label>
              <Input value={formData.energyRating} onChange={(e) => handleInputChange("energyRating", e.target.value)} placeholder="Add energy rating" />
            </div>
          </div>
        );

      case 6: // Property Images & Documents
        return (
          <div className="space-y-8">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <Icon name="ImageIcon" className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Property Images</h3>
              <p className="text-gray-500 mb-4">Drag Or Upload Your Property Images</p>
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">Upload Images</Button>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <Icon name="VideoIcon" className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Property Videos</h3>
              <p className="text-gray-500 mb-4">Drag Or Upload Your Property Videos</p>
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">Upload Videos</Button>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <Icon name="FloorPlanIcon" className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Floor Plans</h3>
              <p className="text-gray-500 mb-4">Upload Floor Plans & Documents</p>
              <div className="flex gap-3 justify-center">
                <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">Make This Feature</Button>
                <Button variant="outline" className="border-red-600 text-red-600 hover:bg-red-50">Delete</Button>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  // Render Properties List View
  const renderPropertiesView = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{displayProperties.length} properties</h1>
          <p className="text-gray-600 mt-1">Manage your rental properties</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          <div className="relative flex items-center">
            <Input
              placeholder="Search properties..."
              value={globalFilter ?? ""}
              onChange={(e) => setGlobalFilter(e.target.value)}
              className="w-full sm:w-64"
            />
            <Icon className="absolute top-1/2 right-3 -translate-y-1/2 w-4 h-4 text-gray-400" name="SearchIcon" />
          </div>
          <Button 
            onClick={() => setActiveTab("add-property")}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Add New Property
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 p-4 bg-gray-50 rounded-lg">
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-sm">
          <option>All Property Types</option>
          {propertyTypes.map(type => <option key={type}>{type}</option>)}
        </select>
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-sm">
          <option>Any Price</option>
          <option>Under $1000</option>
          <option>$1000 - $2000</option>
          <option>$2000+</option>
        </select>
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-sm">
          <option>Any Beds</option>
          <option>1 Bed</option>
          <option>2 Beds</option>
          <option>3+ Beds</option>
        </select>
      </div>

      {/* Properties Grid */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : displayProperties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {displayProperties.map((property) => (
            <div key={property.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-300">
              {/* Property Image */}
              <div className="relative h-48 bg-gray-200 overflow-hidden">
                <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
                <button 
                  onClick={() => toggleFavorite(property.id)}
                  className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-gray-50"
                >
                  <Icon name="HeartIcon" className={`w-4 h-4 ${property.isFavorite ? 'text-red-500 fill-current' : 'text-gray-400'}`} />
                </button>
                <div className="absolute bottom-3 left-3">
                  <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {property.status}
                  </span>
                </div>
              </div>
              
              {/* Property Details */}
              <div className="p-4">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-2xl font-bold text-gray-900">{property.price}</span>
                  <div className="flex items-center gap-1">
                    <Icon name="StarIcon" className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium text-gray-700">{property.rating}</span>
                    <span className="text-sm text-gray-500">({property.reviews})</span>
                  </div>
                </div>

                <h3 className="font-semibold text-lg text-gray-900 mb-2 line-clamp-1">{property.name}</h3>
                
                <div className="flex items-center gap-1 text-gray-600 mb-3">
                  <Icon name="LocationIcon" className="w-4 h-4" />
                  <span className="text-sm">{property.location}</span>
                </div>

                <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center gap-1">
                    <Icon name="BedIcon" className="w-4 h-4" />
                    <span>{property.beds} Beds</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Icon name="BathIcon" className="w-4 h-4" />
                    <span>{property.baths} Baths</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Icon name="AreaIcon" className="w-4 h-4" />
                    <span>{property.area} sq ft</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {property.amenities.slice(0, 3).map((amenity, index) => (
                    <span key={index} className="px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-xs">
                      {amenity}
                    </span>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={() => handleViewDetails(property.id)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium"
                  >
                    View Details
                  </Button>
                  <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 px-4">
                    <Icon name="PhoneIcon" className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="HomeIcon" className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No properties found</h3>
          <p className="text-gray-600 mb-6">Get started by adding your first property.</p>
          <Button onClick={() => setActiveTab("add-property")} className="bg-blue-600 hover:bg-blue-700 text-white">
            Add New Property
          </Button>
        </div>
      )}
    </div>
  );

  // Render Add Property View
  const renderAddPropertyView = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">List New Property</h1>
          <p className="text-gray-600 mt-1">Fill in the property details step by step</p>
        </div>
        <Button variant="outline" onClick={() => setActiveTab("properties")}>
          Back to Properties
        </Button>
      </div>

      {/* Progress Steps */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-center mb-8 overflow-x-auto">
          {steps.map((step, index) => (
            <div key={step} className="flex flex-col items-center min-w-24">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium ${
                index === currentStep ? "bg-blue-600 text-white border-2 border-blue-600" :
                index < currentStep ? "bg-green-500 text-white border-2 border-green-500" :
                "bg-white text-gray-500 border-2 border-gray-300"
              }`}>
                {index + 1}
              </div>
              <span className={`text-xs mt-2 text-center ${
                index === currentStep ? "text-blue-600 font-medium" :
                index < currentStep ? "text-green-600 font-medium" :
                "text-gray-500"
              }`}>
                {step}
              </span>
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">{steps[currentStep]}</h2>
          {renderStepContent()}
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="px-6"
          >
            Previous
          </Button>
          
          {currentStep === steps.length - 1 ? (
            <Button onClick={handleSubmit} className="bg-blue-600 hover:bg-blue-700 text-white px-8">
              Submit Property
            </Button>
          ) : (
            <Button onClick={nextStep} className="bg-blue-600 hover:bg-blue-700 text-white px-8">
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {activeTab === "properties" ? renderPropertiesView() : renderAddPropertyView()}
      </div>
    </div>
  );
};

export default PropertyManagementSystem;