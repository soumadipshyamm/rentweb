import React from "react";
import { Button } from "../../ui/button";
import { Label } from "../../ui/label";

// PropertyComponents.jsx
// Added two components:
//  - PropertyForm (existing)
//  - PropertyList (new): renders a vertical list of property cards similar to the screenshot
// Local image path included so your platform converts it to a URL when rendering.

const sampleCardImage ="https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=600&h=400&fit=crop";

// property1: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=600&h=400&fit=crop",
//   property2: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&h=400&fit=crop",
//   property3: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&h=400&fit=crop",
//   property4: "https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=600&h=400&fit=crop",

export function PropertyCard({ property = {}, onToggleAvailable }) {
  const {
    title = "Casa Lomas De Machalí Machas",
    beds = 4,
    baths = 2,
    sqft = 1150,
    location = "Downtown San Francisco",
    rent = "1250,00",
    available = false,
    responses = 0,
  } = property;

  return (
    <div className="flex gap-6 items-center bg-white p-6 rounded-lg shadow-sm">
      <img
        src={property.image || sampleCardImage}
        alt={title}
        className="w-40 h-28 object-cover rounded-lg"
      />

      <div className="flex-1">
        <div className="text-2xl font-semibold">{title}</div>
        <div className="mt-3 flex items-center gap-6 text-gray-600">
          <div className="flex items-center gap-2">
            <span>🛏</span>
            <span>
              Beds: <strong>{beds}</strong>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span>🛁</span>
            <span>
              Baths: <strong>{baths}</strong>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span>📏</span>
            <span>
              Sqft: <strong>{sqft}</strong>
            </span>
          </div>
        </div>
        <div className="mt-2 text-sm text-blue-600">📍 {location}</div>
      </div>

      <div className="text-right w-56">
        <div className="text-lg text-gray-600">
          Rent :{" "}
          <span className="text-blue-600 font-semibold">${rent}/month</span>
        </div>
        <div className="mt-4 flex flex-col items-end gap-3">
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={available}
              onChange={onToggleAvailable}
            />
            <span className="text-sm text-gray-600">Available for Rent?</span>
          </label>
          <div className="text-sm text-blue-600">{responses} Responses</div>
          <Button className="mt-2">View Details</Button>
        </div>
      </div>
    </div>
  );
}

export default function PropertyManagmentIndexPage({ properties = [] }) {
  // sample fallback list if none provided
  const list = properties.length
    ? properties
    : [
        {
          id: 1,
          image: sampleCardImage,
          title: "Casa Lomas De Machalí Machas",
          beds: 4,
          baths: 2,
          sqft: 1150,
          location: "Downtown San Francisco",
          rent: "1250,00",
          available: false,
          responses: 0,
        },
        {
          id: 2,
          image: sampleCardImage,
          title: "Modern Duplex at Sunset Blvd",
          beds: 3,
          baths: 2,
          sqft: 980,
          location: "Los Angeles, CA",
          rent: "1890,00",
          available: true,
          responses: 5,
        },
        {
          id: 3,
          image: sampleCardImage,
          title: "Palm Springs Family Home",
          beds: 5,
          baths: 3,
          sqft: 2100,
          location: "Palm Springs, CA",
          rent: "2500,00",
          available: true,
          responses: 12,
        },
        {
          id: 4,
          image: sampleCardImage,
          title: "Cozy Beachfront Studio",
          beds: 1,
          baths: 1,
          sqft: 450,
          location: "Miami Beach, FL",
          rent: "900,00",
          available: true,
          responses: 3,
        },
        {
          id: 5,
          image: sampleCardImage,
          title: "Luxury Penthouse Suite",
          beds: 4,
          baths: 4,
          sqft: 3200,
          location: "New York City, NY",
          rent: "5200,00",
          available: false,
          responses: 8,
        },
        { id: 1, image: sampleCardImage, available: false, responses: 0 },
        { id: 2, image: sampleCardImage, available: true, responses: 2 },
        {
          id: 6,
          image: sampleCardImage,
          title: "Suburban Family House",
          beds: 3,
          baths: 2,
          sqft: 1350,
          location: "Austin, TX",
          rent: "1600,00",
          available: true,
          responses: 1,
        },
        {
          id: 7,
          image: sampleCardImage,
          title: "Downtown Modern Apartment",
          beds: 2,
          baths: 1,
          sqft: 760,
          location: "Seattle, WA",
          rent: "2100,00",
          available: false,
          responses: 0,
        },
      ];

  return (
    <div className="space-y-6 p-6 bg-gray-50 min-h-screen">
      {list.map((p) => (
        <div key={p.id} className="rounded-lg border border-gray-100 p-4">
          <PropertyCard
            property={{
              ...p,
              title: p.title,
              beds: p.beds,
              baths: p.baths,
              sqft: p.sqft,
              location: p.location,
              rent: p.rent,
            }}
            onToggleAvailable={() => console.log("toggle", p.id)}
          />
        </div>
      ))}
    </div>
  );
}
