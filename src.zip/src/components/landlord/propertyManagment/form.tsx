import React, { useState } from "react";
import { Label } from "../../ui/label";
import { Input } from "../../ui/input";
import { Textarea } from "../../ui/textarea";
import { Button } from "../../ui/button";

// PropertyForm.jsx
// Recreated from provided screenshots. Uses your UI primitives (Label, Input, Textarea, Button).
// Sample images are included from the uploaded paths so your platform can convert them to URLs.

export default function PropertyForm() {
  const tabs = [
    "Property Basics",
    "Rent Details",
    "Property Features",
    "Interior Features",
    "Outdoor Features",
    "Additional Information",
    "Property Images & Documents",
  ];

  const images = [
    "/mnt/data/Screenshot 2025-11-25 025531.png",
    "/mnt/data/Screenshot 2025-11-25 025546.png",
    "/mnt/data/Screenshot 2025-11-25 025602.png",
    "/mnt/data/Screenshot 2025-11-25 025618.png",
    "/mnt/data/Screenshot 2025-11-25 025636.png",
    "/mnt/data/Screenshot 2025-11-25 025707.png",
    "/mnt/data/Screenshot 2025-11-25 025813.png",
  ];

  const [activeTab, setActiveTab] = useState(0);
  const [form, setForm] = useState({
    propertyName: "",
    propertyType: "",
    suburb: "",
    state: "",
    postcode: "",
    region: "",
    address: "",
    weeklyRent: "",
    bond: "",
    availableFrom: "",
    leaseTerms: "6 months / 12 months",
    bedrooms: "",
    bathrooms: "",
    parking: "",
    landSize: "",
    floorArea: "",
    heating: {},
    kitchen: {},
    laundry: {},
    outdoor: {},
    pets: "allowed",
    description: "",
    energyRating: 4,
    images,
    videos: [images[0]],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const toggleNested = (group, key) => {
    setForm((prev) => ({
      ...prev,
      [group]: {
        ...(prev[group] || {}),
        [key]: !((prev[group] || {})[key]),
      },
    }));
  };

  const renderTabs = () => (
    <div className="flex gap-6 border-b">
      {tabs.map((t, i) => (
        <button
          key={t}
          onClick={() => setActiveTab(i)}
          className={`pb-3 text-sm font-medium ${activeTab === i ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-600"}`}
        >
          {t}
        </button>
      ))}
    </div>
  );

  const PropertyBasics = () => (
    <div className="space-y-6">
      <div>
        <Label htmlFor="propertyName">Property Name *</Label>
        <Input id="propertyName" name="propertyName" value={form.propertyName} onChange={handleChange} className="mt-2" placeholder="Add" />
      </div>

      <div className="flex items-center justify-between gap-6">
        <div className="flex-1">
          <Label htmlFor="propertyType">Property Type *</Label>
          <select name="propertyType" value={form.propertyType} onChange={handleChange} className="mt-2 w-full p-3 border rounded-lg">
            <option value="">House / Apartment / Unit / Townhouse / Villa / Studio / Duplex / Granny Flat</option>
            <option value="house">House</option>
            <option value="apartment">Apartment</option>
          </select>
        </div>

        <div>
          <Label>Available for Rent? *</Label>
          <label className="inline-flex items-center ml-3">
            <input type="checkbox" />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6">
        <div>
          <Label>Suburb *</Label>
          <select className="mt-2 w-full p-3 border rounded-lg">
            <option>Select</option>
          </select>
        </div>
        <div>
          <Label>State *</Label>
          <select className="mt-2 w-full p-3 border rounded-lg">
            <option>Select</option>
          </select>
        </div>
        <div>
          <Label>Postcode *</Label>
          <Input name="postcode" value={form.postcode} onChange={handleChange} className="mt-2" placeholder="Add" />
        </div>
        <div>
          <Label>Region / Area</Label>
          <Input name="region" value={form.region} onChange={handleChange} className="mt-2" placeholder="Add" />
        </div>
      </div>

      <div>
        <Label>Full Address *</Label>
        <Textarea name="address" value={form.address} onChange={handleChange} className="mt-2" rows={3} placeholder="Add" />
      </div>
    </div>
  );

  const RentDetails = () => (
    <div className="grid grid-cols-4 gap-6">
      <div>
        <Label>Weekly Rent Price *</Label>
        <div className="mt-2 p-3 border rounded-lg flex items-center gap-3">$
          <Input name="weeklyRent" value={form.weeklyRent} onChange={handleChange} className="outline-none border-none p-0" placeholder="Add" />
        </div>
      </div>

      <div>
        <Label>Bond / Security Deposit *</Label>
        <div className="mt-2 p-3 border rounded-lg flex items-center gap-3">$
          <Input name="bond" value={form.bond} onChange={handleChange} className="outline-none border-none p-0" placeholder="Add" />
        </div>
      </div>

      <div>
        <Label>Available From *</Label>
        <Input type="date" name="availableFrom" value={form.availableFrom} onChange={handleChange} className="mt-2" />
      </div>

      <div>
        <Label>Lease Terms *</Label>
        <select name="leaseTerms" value={form.leaseTerms} onChange={handleChange} className="mt-2 w-full p-3 border rounded-lg">
          <option>6 months / 12 months</option>
          <option>12 months</option>
        </select>
      </div>
    </div>
  );

  const PropertyFeatures = () => (
    <div>
      <div className="grid grid-cols-4 gap-6">
        <div>
          <Label>No Of Bedrooms *</Label>
          <Input name="bedrooms" value={form.bedrooms} onChange={handleChange} className="mt-2" placeholder="Add" />
        </div>
        <div>
          <Label>No Of Bathrooms *</Label>
          <Input name="bathrooms" value={form.bathrooms} onChange={handleChange} className="mt-2" placeholder="Add" />
        </div>
        <div>
          <Label>Parking *</Label>
          <select name="parking" value={form.parking} onChange={handleChange} className="mt-2 w-full p-3 border rounded-lg">
            <option>Car Spaces / Parking</option>
          </select>
        </div>
        <div>
          <Label>Lease Terms *</Label>
          <select className="mt-2 w-full p-3 border rounded-lg">
            <option>6 months / 12 months</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mt-6">
        <div>
          <Label>Land Size</Label>
          <div className="mt-2 p-3 border rounded-lg flex items-center justify-between">
            <Input name="landSize" value={form.landSize} onChange={handleChange} className="outline-none" placeholder="Add" />
            <span className="pl-2">m²</span>
          </div>
        </div>
        <div>
          <Label>Floor Area</Label>
          <div className="mt-2 p-3 border rounded-lg flex items-center justify-between">
            <Input name="floorArea" value={form.floorArea} onChange={handleChange} className="outline-none" placeholder="Add" />
            <span className="pl-2">m²</span>
          </div>
        </div>
      </div>
    </div>
  );

  const InteriorFeatures = () => (
    <div className="space-y-6">
      <div>
        <Label>Heating / Cooling *</Label>
        <div className="mt-3 flex gap-6">
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.heating.airConditioning} onChange={() => toggleNested('heating','airConditioning')} />
            <span>Air conditioning</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.heating.fans} onChange={() => toggleNested('heating','fans')} />
            <span>Fans</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.heating.ducted} onChange={() => toggleNested('heating','ducted')} />
            <span>Ducted Heating</span>
          </label>
        </div>
      </div>

      <div>
        <Label>Kitchen Appliances *</Label>
        <div className="mt-3 flex gap-6">
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.kitchen.dishwasher} onChange={() => toggleNested('kitchen','dishwasher')} />
            <span>Dishwasher</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.kitchen.oven} onChange={() => toggleNested('kitchen','oven')} />
            <span>Oven</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.kitchen.stove} onChange={() => toggleNested('kitchen','stove')} />
            <span>Stove</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.kitchen.pantry} onChange={() => toggleNested('kitchen','pantry')} />
            <span>Pantry</span>
          </label>
        </div>
      </div>

      <div>
        <Label>Laundry Facilities *</Label>
        <div className="mt-3 flex gap-6">
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.laundry.inUnit} onChange={() => toggleNested('laundry','inUnit')} />
            <span>In-unit</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.laundry.shared} onChange={() => toggleNested('laundry','shared')} />
            <span>Shared</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.laundry.dryer} onChange={() => toggleNested('laundry','dryer')} />
            <span>Dryer</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={!!form.laundry.washer} onChange={() => toggleNested('laundry','washer')} />
            <span>Washer</span>
          </label>
        </div>
      </div>
    </div>
  );

  const OutdoorFeatures = () => (
    <div>
      <div className="flex gap-6">
        <label className="inline-flex items-center gap-2"><input type="checkbox" checked={!!form.outdoor.balcony} onChange={() => toggleNested('outdoor','balcony')} /> <span>Balcony</span></label>
        <label className="inline-flex items-center gap-2"><input type="checkbox" checked={!!form.outdoor.deck} onChange={() => toggleNested('outdoor','deck')} /> <span>Deck</span></label>
        <label className="inline-flex items-center gap-2"><input type="checkbox" checked={!!form.outdoor.courtyard} onChange={() => toggleNested('outdoor','courtyard')} /> <span>Courtyard</span></label>
        <label className="inline-flex items-center gap-2"><input type="checkbox" checked={!!form.outdoor.garden} onChange={() => toggleNested('outdoor','garden')} /> <span>Garden</span></label>
      </div>

      <div className="mt-6">
        <Label>Outdoor Entertaining Area *</Label>
        <div className="mt-3 flex gap-6">
          <label className="inline-flex items-center gap-2"><input type="checkbox" checked /> <span>Shed</span></label>
          <label className="inline-flex items-center gap-2"><input type="checkbox" checked /> <span>Storage</span></label>
        </div>
      </div>
    </div>
  );

  const AdditionalInformation = () => (
    <div className="space-y-6">
      <div>
        <Label>Pets *</Label>
        <div className="mt-3 flex gap-6">
          <label className={`inline-flex items-center gap-2 ${form.pets === 'allowed' ? 'text-blue-600' : 'text-gray-700'}`}><input type="radio" name="pets" checked={form.pets === 'allowed'} onChange={() => setForm(prev => ({...prev, pets: 'allowed'}))} /> <span>Allowed</span></label>
          <label className={`inline-flex items-center gap-2 ${form.pets === 'not' ? 'text-blue-600' : 'text-gray-700'}`}><input type="radio" name="pets" checked={form.pets === 'not'} onChange={() => setForm(prev => ({...prev, pets: 'not'}))} /> <span>Not Allowed</span></label>
          <label className={`inline-flex items-center gap-2 ${form.pets === 'case' ? 'text-blue-600' : 'text-gray-700'}`}><input type="radio" name="pets" checked={form.pets === 'case'} onChange={() => setForm(prev => ({...prev, pets: 'case'}))} /> <span>Case-by-case</span></label>
        </div>
      </div>

      <div>
        <Label>Description *</Label>
        <Textarea name="description" value={form.description} onChange={handleChange} className="mt-2" rows={6} placeholder="Add" />
      </div>

      <div>
        <Label>Energy Rating</Label>
        <div className="mt-2 flex items-center gap-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <svg key={i} className={`w-8 h-8 ${i < form.energyRating ? 'text-yellow-400' : 'text-gray-300'}`} viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.966a1 1 0 00.95.69h4.18c.969 0 1.371 1.24.588 1.81l-3.38 2.455a1 1 0 00-.364 1.118l1.286 3.966c.3.921-.755 1.688-1.54 1.118L10 13.347l-3.38 2.455c-.784.57-1.838-.197-1.539-1.118l1.286-3.966a1 1 0 00-.364-1.118L2.623 9.393c-.783-.57-.38-1.81.588-1.81h4.18a1 1 0 00.95-.69l1.286-3.966z" /></svg>
          ))}
        </div>
      </div>
    </div>
  );

  const ImagesAndDocs = () => (
    <div className="space-y-6">
      <div>
        <Label>Images *</Label>
        <div className="mt-3 grid grid-cols-6 gap-4 items-start">
          <div className="col-span-1">
            <div className="w-40 h-40 border-dashed border-2 border-gray-200 rounded-lg flex items-center justify-center text-sm text-gray-400">Drag Or Upload Your Property Images</div>
          </div>

          {form.images.map((src, idx) => (
            <div key={idx} className="col-span-1 relative">
              <img src={src} alt={`img-${idx}`} className="w-40 h-40 object-cover rounded-lg shadow-sm" />
              <input type="checkbox" className="absolute top-2 right-2" />
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label>Video</Label>
        <div className="mt-3 grid grid-cols-6 gap-4">
          <div className="col-span-1">
            <div className="w-40 h-40 border-dashed border-2 border-gray-200 rounded-lg flex items-center justify-center text-sm text-gray-400">Drag Or Upload Your Property Videos</div>
          </div>

          {form.videos.map((src, idx) => (
            <div key={idx} className="col-span-1 relative">
              <img src={src} alt={`vid-${idx}`} className="w-40 h-40 object-cover rounded-lg shadow-sm" />
              <input type="checkbox" className="absolute top-2 right-2" />
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label>Floor Plan</Label>
        <div className="mt-3 grid grid-cols-6 gap-4">
          <div className="col-span-1">
            <div className="w-40 h-40 border-dashed border-2 border-gray-200 rounded-lg flex items-center justify-center text-sm text-gray-400">Drag Or Upload Floor Plan</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderActive = () => {
    switch (activeTab) {
      case 0:
        return <PropertyBasics />;
      case 1:
        return <RentDetails />;
      case 2:
        return <PropertyFeatures />;
      case 3:
        return <InteriorFeatures />;
      case 4:
        return <OutdoorFeatures />;
      case 5:
        return <AdditionalInformation />;
      case 6:
        return <ImagesAndDocs />;
      default:
        return null;
    }
  };

  return (
    <div className="p-8 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto">
        {renderTabs()}

        <div className="mt-8 bg-white p-6 rounded-lg shadow-sm">
          {renderActive()}

          <div className="mt-8 flex justify-between">
            <div>
              <Button onClick={() => setActiveTab(Math.max(0, activeTab - 1))} className="mr-2">Previous</Button>
              <Button onClick={() => setActiveTab(Math.min(tabs.length - 1, activeTab + 1))}>Next</Button>
            </div>

            <div>
              <Button className="mr-3">Cancel</Button>
              <Button className="bg-green-600 text-white">Save</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
