export const MEMBER_LOGIN_URL : string = '/auth/login'
export const MEMBER_REGISTRATION_URL : string = '/auth/registration/member'
export const ADMIN_REGISTRATION_URL : string = '/auth/registration/admin'
export const VERIFICATION_URL : string = '/auth/email-verification-with-password-change'

export const PROPERTY_TYPE_GET_URL : string = '/group-owner/property-type/list'
export const PROPERTY_TYPE_UPDATE_URL : string = '/group-owner/property-type/edit'
export const PROPERTY_TYPE_ADD_URL : string = '/group-owner/property-type/add'
export const PROPERTY_TYPE_URL : string = '/group-owner/property-type'

export const SUBSCRIPTION_PLAN_GET_URL : string = 'group-owner/subscription/list'
export const SUBSCRIPTION_PLAN_ADD_URL : string = 'group-owner/subscription/add'
export const SUBSCRIPTION_PLAN_EDIT_URL : string = 'group-owner/subscription/edit'
export const SUBSCRIPTION_PLAN_URL : string = 'group-owner/subscription/'
export const SUBSCRIPTION_PLAN_STATUS_CHANGE_URL : string = "group-owner/subscription-status/"