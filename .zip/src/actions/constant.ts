export const MEMBER_LOGIN_URL : string = '/auth/login'
export const MEMBER_REGISTRATION_URL = '/auth/registration/member'
export const ADMIN_REGISTRATION_URL = '/auth/registration/admin'
export const VERIFICATION_URL : string = '/auth/email-verification-with-password-change'
