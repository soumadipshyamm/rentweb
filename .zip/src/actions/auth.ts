import api from ".";
import { MEMBER_LOGIN_URL, VERIFICATION_URL } from "./constant";

type memberLoginSchema = {
    email: string,
    password: string,
    role: "TENANT",
    otp?: string

};

type getOtpSchema = {
    email: string,
    role: "TENANT" | "LANDLORD" | "PROPERTY MANAGER",
    type: string,
    otp?: string
}

export const loginMember = async (payload: memberLoginSchema) => {
    const res = await api.post(MEMBER_LOGIN_URL, payload);
    return res.data;
};

export const verifyMember = async (payload: getOtpSchema) => {
    const res = await api.post(VERIFICATION_URL, payload);
    return res.data;
};