import React from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Card, CardContent } from "../../../../../ui/card";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from 'react-intersection-observer';
import Slider from "react-slick";

const TestimonialsSection = () => {
  const [ref, inView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Duration for each slide (in milliseconds)
    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1000,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
    ],
  };
  const testimonials = [
    {
      avatar:
        "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100",
      name: "Annette Black",
      title: "CEO Themesflat",
    },
    {
      avatar:
        "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100",
      name: "John Smith",
      title: "Property Manager",
    },
    {
      avatar:
        "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100",
      name: "Sarah Johnson",
      title: "Real Estate Agent",
    },
    {
      avatar:
        "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100",
      name: "Michael Brown",
      title: "Investment Advisor",
    },
    {
      avatar:
        "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100",
      name: "Michael Brown",
      title: "Investment Advisor",
    },
  ];

  return (
    <section className="h-full relative py-12 px-4">
      <div className="flex flex-col gap-12 max-w-7xl mx-auto">
        <header className="flex flex-col gap-1">
          <div className="[font-family:'Manrope',Helvetica] font-semibold text-primary text-lg tracking-[1.44px] leading-6">
            CLIENTS FEEDBACK
          </div>
          <h2 className="[font-family:'Manrope',Helvetica] font-extrabold text-[#1e1e1e] sm:text-2xl md:text-4xl tracking-[0] sm:leading-tight md:leading-[44px]">
            What&apos;s People Says
          </h2>
        </header>

        {/* <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-[22px]"> */}
        <div ref={ref} className={`grid grid-cols-1 sm:gap-4 md:gap-[22px] ${inView ? 'animate__animated animate__slideInLeft' : ''}`}>
          <Slider {...settings}>
            {testimonials.map((testimonial, index) => (
              <div key={index} className="px-2 m-3">
                <Card
                  key={index}
                  // className="bg-white border-0"
                  className="bg-white rounded-[20px] shadow-[0px_0px_34px_#00000014] border-0"
                >
                  <CardContent className="flex flex-col gap-3 sm:p-4 md:p-[30px]">
                    <img
                      className="sm:w-10 sm:h-10 md:w-[60px] md:h-[60px]"
                      alt="Quote icon"
                      src={IMAGES.quote}
                    />

                    <div className="flex flex-col gap-6">
                      <p className="[font-family:'Manrope',Helvetica] font-normal text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[21.6px]">
                        "My experience with property management services has
                        exceeded expectations. They efficiently manage
                        properties with a professional and attentive approach in
                        every situation. I feel reassured that any issue will be
                        resolved promptly and effectively."
                      </p>

                      <div className="flex items-start gap-3">
                        <img
                          className="sm:w-12 sm:h-12 md:w-[70px] md:h-[70px] object-cover rounded-full"
                          alt="User avatar"
                          src={testimonial.avatar}
                        />

                        <div className="flex flex-col justify-center gap-[9px]">
                          <div className="flex flex-col gap-0.5">
                            <h3 className="[font-family:'Manrope',Helvetica] font-bold text-[#1e1e1e] sm:text-sm md:text-lg tracking-[0] leading-[25.2px]">
                              {testimonial.name}
                            </h3>
                            <p className="font-caption-caption-02 font-[number:var(--caption-caption-02-font-weight)] text-[#666666] text-xs tracking-[var(--caption-caption-02-letter-spacing)] leading-[var(--caption-caption-02-line-height)] [font-style:var(--caption-caption-02-font-style)]">
                              {testimonial.title}
                            </p>
                          </div>
                          <div className="flex items-center gap-1">
                            <img
                              className="flex-shrink-0"
                              alt="Rating stars"
                              src={IMAGES.star}
                            />
                            <img
                              className="flex-shrink-0"
                              alt="Rating stars"
                              src={IMAGES.star}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </Slider>
        </div>

        {/* <div className="flex justify-center">
          <div className="flex gap-1">
            <div className="w-[23px] h-[3px] bg-primary rounded-[40px]" />
            <div className="w-[23px] h-[3px] bg-[#1563df33] rounded-[40px]" />
          </div>
        </div> */}
      </div>
    </section>
  );
};
export default TestimonialsSection;