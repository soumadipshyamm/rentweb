import React, { useEffect, useState } from "react";
import { Card, CardContent } from "../../../../../ui/card";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from 'react-intersection-observer';

const PropertyTypeSection = () => {
  const [ref, inView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  
  const propertyTypes = [
    {
      icon: IMAGES.apartment,
      title: "Apartment",
      count: "234 Property",
    },
    {
      icon: IMAGES.house,
      title: "House",
      count: "234 Property",
    },
    {
      icon: IMAGES.granny_flat,
      title: "Granny Flat",
      count: "234 Property",
    },
    {
      icon: IMAGES.duplex,
      title: "Duplex",
      count: "234 Property",
    },
    {
      icon: IMAGES.villa,
      title: "Villa",
      count: "234 Property",
    },
    {
      icon: IMAGES.office,
      title: "Office",
      count: "234 Property",
    },
  ];
  return (
    <section className="w-full flex sm:flex-col lg:flex-row items-center justify-center sm:gap-6 lg:gap-10 py-8 px-4">
      <div className="flex flex-col sm:items-center lg:items-start gap-1 sm:text-center lg:text-left">
        <div className="[font-family:'Manrope',Helvetica] font-semibold text-primary text-base tracking-[1.44px] leading-6 whitespace-nowrap">
          PROPERTY TYPE
        </div>

        <h2 className="font-heading-heading-03 font-[number:var(--heading-heading-03-font-weight)] text-[#1e1e1e] text-[length:var(--heading-heading-03-font-size)] tracking-[var(--heading-heading-03-letter-spacing)] leading-[var(--heading-heading-03-line-height)] [font-style:var(--heading-heading-03-font-style)]">
          Available
          <br />
          Properties
        </h2>
      </div>

      <div ref={ref} className={`flex-1 flex items-center w-full ${inView ? 'animate__animated animate__slideInRight' : ''}`}>
        <div  className={`w-full grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 sm:gap-4 lg:gap-6 `}>
          {propertyTypes.map((property, index) => (
            <Card
              key={index}
              className="w-full aspect-square bg-white rounded-2xl border border-[#e4e4e4] hover:shadow-lg transition-shadow cursor-pointer"
            >
              <CardContent className="flex flex-col items-center justify-center sm:gap-2 md:gap-3 sm:p-4 md:pt-[30px] md:pb-6 md:px-6 h-full">
                <img
                  className={`${
                    property.title === "House"
                      ? "sm:w-12 sm:h-12 md:w-[74px] md:h-[74px]"
                      : "sm:w-12 sm:h-12 md:w-20 md:h-20"
                  }`}
                  alt={`${property.title} icon`}
                  src={property.icon}
                />

                <div className="flex flex-col items-center justify-center gap-1">
                  <div className="[font-family:'Manrope',Helvetica] font-bold text-[#1e1e1e] sm:text-sm md:text-lg text-center tracking-[0] leading-[25.2px]">
                    {property.title}
                  </div>

                  <div className="[font-family:'Manrope',Helvetica] font-medium text-[#333333] sm:text-xs md:text-sm text-center tracking-[0] leading-[19.6px]">
                    {property.count}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
export default PropertyTypeSection;
