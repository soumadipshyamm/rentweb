import React from "react";
import { Button } from "../../../../../ui/button";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from "react-intersection-observer";

const ServicesSection = () => {
  const [rightRef, inRightView] = useInView({
    triggerOnce: true, // Trigger animation only once
    threshold: 0.3, // Trigger when 10% of the image is visible
  });
  const [leftRef, inLeftView] = useInView({
    triggerOnce: true, // Trigger animation only once
    threshold: 0.3, // Trigger when 10% of the image is visible
  });
  const processSteps = [
    {
      text: "Find Property for Rent",
      className: "sm:w-[200px] md:w-[248px] sm:h-[50px] md:h-[63px] top-0 left-px",
    },
    {
      text: "Post Your Requirement",
      className:
        "sm:w-[200px] md:w-[250px] sm:h-[50px] md:h-[63px] top-[11px] sm:left-[300px] md:left-[489px]",
    },
    {
      text: "Connect With Landlord",
      className:
        "sm:w-[200px] md:w-[258px] sm:h-[50px] md:h-[63px] sm:top-[200px] md:top-[306px] left-0",
    },
    {
      text: "Start conversation",
      className:
        "sm:w-[180px] md:w-[221px] sm:h-[50px] md:h-[63px] sm:top-[170px] md:top-[262px] sm:left-[320px] md:left-[507px]",
    },
  ];

  return (
    <div className="w-full flex px-4 sm:py-8 md:py-16" id="discover">
      <section ref={rightRef} className={`w-full relative ${inRightView ? 'animate__animated animate__slideInRight' : ''}`}>
        <div className="flex flex-col sm:w-full lg:w-[630px] items-start gap-1">
          <div className="[font-family:'Manrope',Helvetica] font-semibold text-primary text-lg tracking-[1.44px] leading-6 whitespace-nowrap">
            WHAT WE DO
          </div>

          <h2 className="font-heading-heading-03 font-[number:var(--heading-heading-03-font-weight)] text-[#1e1e1e] sm:text-2xl md:text-[length:var(--heading-heading-03-font-size)] tracking-[var(--heading-heading-03-letter-spacing)] leading-tight md:leading-[var(--heading-heading-03-line-height)] [font-style:var(--heading-heading-03-font-style)]">
            Discover What Sets Our
          </h2>
        </div>
        <br />
        <br />
        <div className="sm:w-full lg:w-[840px] [font-family:'Manrope',Helvetica] font-normal text-[#333333] sm:text-sm md:text-base tracking-[0] sm:leading-relaxed md:leading-[27.2px]">
          We&apos;re your partners in finding the perfect space to call home,
          grow your business, or invest in your future. Whether you&#39;re
          buying, selling, renting, or exploring investment opportunities, we
          bring clarity to every step of the process.
          <br />
          <br />
          To redefine the real estate experience in India by blending
          technology, trust, and human connection. We aim to be the most
          reliable bridge between dreams and reality—one property at a time.
          <br />
          <br />
          Our team of seasoned professionals, tech innovators, and local agents
          work together to deliver a seamless experience tailored to your needs.
        </div>
        <br />
        <br />
        <Button className="h-[52px] sm:px-6 md:px-10 py-[11px] bg-primary rounded-[99px] [font-family:'Manrope',Helvetica] font-semibold text-background text-base hover:bg-muted">
          Read More
        </Button>
      </section>
      <section ref={leftRef} className={`w-full max-w-[659px] h-auto relative ${inLeftView ? 'animate__animated animate__slideInLeft' : ''}`}>
        <div className="relative flex flex-col items-center justify-center min-h-[450px]">
          <div className="relative w-full max-w-[602px] flex flex-col items-center">
            <div className="relative w-full max-w-[576px] -mt-4">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-[484px] h-[529px]">
                  <img
                    className="absolute inset-0 w-full h-full object-contain"
                    alt=""
                    src={IMAGES.discover_sets}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
export default ServicesSection;
