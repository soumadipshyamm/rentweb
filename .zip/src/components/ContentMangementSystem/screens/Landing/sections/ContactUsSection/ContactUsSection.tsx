import React from "react";
import { Button } from "../../../../../ui/button";
import { Input } from "../../../../../ui/input";
import { Label } from "../../../../../ui/label";
import { Textarea } from "../../../../../ui/textarea";
import { IMAGES } from "../../../../../../assets/index";
import { useInView } from 'react-intersection-observer';

const ContactUsSection = () => {
  const [leftRef, inLeftView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const [rightRef, inRightView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.3, // Trigger when 10% of the image is visible
	});
  const formFields = [
    {
      id: "name",
      label: "Your name",
      placeholder: "Your name",
      type: "input",
    },
    {
      id: "email",
      label: "Email address",
      placeholder: "Email address",
      type: "input",
    },
    {
      id: "phone",
      label: "Phone Numbers",
      placeholder: "Phone Numbers:",
      type: "input",
    },
    {
      id: "subject",
      label: "Subject",
      placeholder: "Enter Keyword",
      type: "input",
    },
  ];

  return (
    <section className="w-full relative" id="contact">
      <div className="flex sm:flex-col lg:flex-row items-center justify-center gap-8 px-4 py-8 max-w-7xl mx-auto">
        <div className={`sm:w-full lg:w-[637px] sm:h-[300px] md:h-[562px] relative sm:order-2 lg:order-1 overflow-hidden ${inLeftView ? 'animate__animated animate__slideInLeft' : ''}`} ref={leftRef}>
          <div className="relative h-full sm:scale-50 md:scale-75 lg:scale-100 origin-center">
            
            <img
              className="absolute w-full h-full left-[21px]"
              alt="Group"
              src={IMAGES.drop_us}
            />
          </div>
        </div>

        <div className={`flex flex-col sm:w-full lg:w-[840px] items-center justify-center gap-5 rounded-[20px] sm:order-1 lg:order-2 ${inRightView ? 'animate__animated animate__slideInRight' : ''}`} ref={rightRef}>
          <header className="flex flex-col items-start gap-3 w-full">
            <h2 className="w-fit [font-family:'Manrope',Helvetica] font-extrabold text-[#1e1e1e] sm:text-2xl md:text-3xl tracking-[0] sm:leading-tight md:leading-[42px]">
              Drop Us A Line
            </h2>

            <p className="w-full font-body-body-02 font-[number:var(--body-body-02-font-weight)] text-[#666666] sm:text-sm md:text-[length:var(--body-body-02-font-size)] tracking-[var(--body-body-02-letter-spacing)] sm:leading-relaxed md:leading-[var(--body-body-02-line-height)] [font-style:var(--body-body-02-font-style)]">
              Feel free to connect with us through our online channels for
              updates, news, and more.
            </p>
          </header>

          <form className="gap-5 w-full flex flex-col items-start">
            <div className="flex items-center sm:gap-4 md:gap-[30px] w-full flex-col sm:flex-row">
              {formFields.slice(0, 2).map((field) => (
                <div
                  key={field.id}
                  className="flex flex-col items-start gap-2 flex-1 w-full"
                >
                  <Label
                    htmlFor={field.id}
                    className="w-fit [font-family:'Manrope',Helvetica] font-semibold text-[#1e1e1e] text-sm tracking-[0] leading-[19.6px]"
                  >
                    {field.label}
                  </Label>

                  <Input
                    id={field.id}
                    placeholder={field.placeholder}
                    className="sm:h-12 md:h-[60px] rounded-xl sm:px-4 md:px-[18px] sm:py-3 md:py-4 w-full bg-background border border-solid border-[#e4e4e4] font-caption-caption-01 font-[number:var(--caption-caption-01-font-weight)] text-[#666666] sm:text-sm md:text-[length:var(--caption-caption-01-font-size)] tracking-[var(--caption-caption-01-letter-spacing)] leading-[var(--caption-caption-01-line-height)] [font-style:var(--caption-caption-01-font-style)]"
                  />
                </div>
              ))}
            </div>

            <div className="flex items-center sm:gap-4 md:gap-[30px] w-full flex-col sm:flex-row">
              {formFields.slice(2, 4).map((field) => (
                <div
                  key={field.id}
                  className="flex flex-col items-start gap-2 flex-1 w-full"
                >
                  <Label
                    htmlFor={field.id}
                    className="w-fit [font-family:'Manrope',Helvetica] font-semibold text-[#1e1e1e] text-sm tracking-[0] leading-[19.6px]"
                  >
                    {field.label}
                  </Label>

                  <Input
                    id={field.id}
                    placeholder={field.placeholder}
                    className="sm:h-12 md:h-[60px] rounded-xl sm:px-4 md:px-[18px] sm:py-3 md:py-4 w-full bg-background border border-solid border-[#e4e4e4] font-caption-caption-01 font-[number:var(--caption-caption-01-font-weight)] text-[#666666] sm:text-sm md:text-[length:var(--caption-caption-01-font-size)] tracking-[var(--caption-caption-01-letter-spacing)] leading-[var(--caption-caption-01-line-height)] [font-style:var(--caption-caption-01-font-style)]"
                  />
                </div>
              ))}
            </div>

            <div className="flex flex-col items-start gap-2 w-full">
              <Label
                htmlFor="message"
                className="w-fit [font-family:'Manrope',Helvetica] font-semibold text-[#1e1e1e] text-sm tracking-[0] leading-[19.6px]"
              >
                Your Message
              </Label>

              <Textarea
                id="message"
                placeholder="Your Message"
                className="sm:h-24 md:h-[130px] rounded-2xl sm:px-4 md:px-[18px] sm:py-3 md:py-4 w-full bg-background border border-solid border-[#e4e4e4] font-caption-caption-01 font-[number:var(--caption-caption-01-font-weight)] text-[#666666] sm:text-sm md:text-[length:var(--caption-caption-01-font-size)] tracking-[var(--caption-caption-01-letter-spacing)] leading-[var(--caption-caption-01-line-height)] [font-style:var(--caption-caption-01-font-style)] resize-none"
              />
            </div>
          </form>

          <Button className="sm:w-full md:w-[305px] sm:h-12 md:h-[62px] px-5 py-[11px] bg-primary rounded-full hover:bg-muted">
            <span className="[font-family:'Manrope',Helvetica] font-semibold text-background text-base text-center tracking-[0] leading-[normal]">
              Send Message
            </span>
          </Button>
        </div>
      </div>
    </section>
  );
};
export default ContactUsSection;
