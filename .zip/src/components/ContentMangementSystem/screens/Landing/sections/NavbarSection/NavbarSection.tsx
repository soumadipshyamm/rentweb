import React, { useEffect, useState } from "react";
import { Button } from "../../../../../ui/button";
import { Link, useLocation } from 'react-router-dom';
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../../../../ui/navigation-menu";
import { IMAGES } from "../../../../../../assets/index";

const NavbarSection = () => {
  const location = useLocation();
  const currentPath = location.pathname;
  const navigationItems = [
    { label: "Home", href: "/", isActive: currentPath === '/' ? true : false },
    { label: "How It Works", href: "/#discover", isActive: currentPath === '/#discover' ? true : false},
    { label: "Find Your Property", href: "/find-property", isActive: currentPath === '/find-property' ? true : false },
    { label: "Find Your Tenant", href: "/find-tenant", isActive: currentPath === '/find-tenant' ? true : false },
    { label: "FAQ's", href: "/#faq", isActive: currentPath === '/#faq' ? true : false },
    { label: "Contacts", href: "/#contact", isActive: currentPath === '/#contact' ? true : false },
  ];
  const [isFixed, setIsFixed] = useState(false);

  const handleScroll = () => {
    if (window.scrollY > 0) {
      setIsFixed(true);
    } else {
      setIsFixed(false);
    }
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header
      className={`w-full min-h-[81px] bg-background shadow-[0px_-11px_54px_#00000014] ${
        isFixed ? "fixed top-0 left-0 right-0 z-50" : "relative"
      }`}
    >
      <div className="flex items-center justify-between w-full max-w-[1548px] h-auto min-h-[62px] mx-auto sm:px-4 md:px-8 lg:px-[100px] sm:py-2 md:pt-[9px]">
        <a href="/">
          <img
            className="sm:w-[150px] sm:h-[45px] md:w-[211px] md:h-[62px]"
            alt="Rentmatch logo"
            src={IMAGES.logo}
          />
        </a>

        <NavigationMenu className="sm:hidden lg:flex flex-1 max-w-none">
          <NavigationMenuList className="flex items-center justify-center gap-8 w-full">
            {navigationItems.map((item, index) => (
              <NavigationMenuItem key={index}>
                <NavigationMenuLink
                  href={item.href}
                  className={`inline-flex items-center gap-1 relative [font-family:'Manrope',Helvetica] font-medium text-base tracking-[0] leading-[normal] ${
                    item.isActive ? "text-primary" : "text-[#1e1e1e]"
                  }`}
                >
                  {item.label}
                </NavigationMenuLink>
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu>

        <a href="/login" className="flex items-center justify-center gap-2 w-[154px] h-[54px] px-5 py-[11px] bg-primary rounded-full border border-solid hover:bg-muted h-auto">
          <img className="w-5 h-5" alt="Icon" src={IMAGES.user} />
          <span className="sm:hidden sm:inline [font-family:'Manrope',Helvetica] font-semibold text-background text-base tracking-[0] leading-[normal]">
            Login
          </span>
        </a>
      </div>
    </header>
  );
};
export default NavbarSection;