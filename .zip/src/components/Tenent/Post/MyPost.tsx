import React, { useState } from "react";
import { Sidebar } from "../../Layout/Sidebar";
import { Header } from "../../Layout/Header";
import { mockUser } from "../../data/mockData";
import Footer from "../../Layout/Footer";
import { IMAGES } from "../../../assets";
import { Button } from "../../ui/button";
import { Card, CardContent } from "../../ui/card";
import { Badge, Calendar, EllipsisVertical, MapPin } from "lucide-react";
import ToggleButton from "../../ChildComponent/ToggleButton";
import Post from "../../ChildComponent/Common/Post";
const MyPost = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  const posts = [
    {
      id: 1,
      title: "Casa Lomas De Machail Machala",
      description:
        "Young professional seeking a modern 2-bedroom apartment in downtown area. Prefer high-rise buildings with city views and modern amenities. Young professional seeking a modern 2-bedroom apartment in downtown area. Prefer high-rise buildings with city views and modern amenities.",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "100 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: true,
      isUrgent: true,
      responseQty: 2,
    },
    {
      id: 2,
      title: "Casa Lomas De Machail Machala",
      description:
        "Young professional seeking a modern 2-bedroom apartment in downtown area. Prefer high-rise buildings with city views and modern amenities.",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "100 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: true,
      isUrgent: false,
      responseQty: 2,
    },
    {
      id: 3,
      title:
        "Casa Lomas De Machail Machala Casa Lomas De Machail Machala Casa Lomas De Machail Machala Casa Lomas De Machail Machala",
      description:
        "Young professional seeking a modern 2-bedroom apartment in downtown area. Prefer high-rise buildings with city views and modern amenities.",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "100 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: true,
      isUrgent: true,
      responseQty: 2,
    },
    {
      id: 4,
      title: "Casa Lomas De Machail Machala",
      description:
        "Young professional seeking a modern 2-bedroom apartment in downtown area. Prefer high-rise buildings with city views and modern amenities.",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "100 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: true,
      isUrgent: false,
      responseQty: 2,
    },
  ];
  return (
    <div className="common-container">
      <div className="w-full mx-auto flex flex-col gap-5">
        <div className="flex justify-between">
          <div className="flex items-center justify-between mb-6 rounded-lg">
            <h2 className="text-md font-bold text-gray-900">Posts</h2>
            <span
              className="ml-3"
              style={{
                backgroundColor: "#3352a4",
                color: "#fff",
                borderRadius: "50%",
                fontSize: "12px",
                padding: "0px 5px 0px 5px",
              }}
            >
              2
            </span>
          </div>
          <div className="flex border rounded-lg">
            <a
              href="/create-post"
              className="bg-blue-500 pl-3 pr-3 flex items-center gap-2"
              style={{
                borderRadius: "25px",
                paddingLeft: "30px",
                paddingRight: "30px",
                color: "white",
                backgroundColor: "#3352a4",
              }}
            >
              <img src={IMAGES.add} alt="" />
              Post
            </a>
          </div>
        </div>
        <div className="space-y-6 max-h-[50vh] xl:max-h-[55vh] 2xl:max-h-[70vh] overflow-y-auto scrollbar-hidden" >
          <div className="grid grid-cols-1">
            {posts.map((post) => (
              <Post
                id={post.id}
                title={post.title}
                description={post.description}
                location={post.location}
                price={post.price}
                beds={post.beds}
                baths={post.baths}
                sqft={post.sqft}
                image={post.image}
                featured={post.featured}
                forRent={post.featured}
                postedDate={post.postedDate}
                type={post.type}
                isUrgent={post.isUrgent}
                responseQty={post.responseQty}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default MyPost;
