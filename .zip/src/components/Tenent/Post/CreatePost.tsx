import React, { useState } from "react";
// import { Sidebar } from "../../Layout/Sidebar";
// import { Header } from "../../Layout/Header";
// import { mockUser } from "../../data/mockData";
// import Footer from "../../Layout/Footer";
// import { IMAGES } from "../../../assets";
import { Button } from "../../ui/button";
import { Label } from "../../ui/label";
import { Input } from "../../ui/input";
import { Textarea } from "../../ui/textarea";
import { Checkbox } from "../../ui/checkbox";
const CreatePost = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  return (

    <div className="w-full rounded-lg px-4 py-10 flex flex-col gap-10 bg-destructive ">
      <div>
        <div className="flex flex-col gap-3">
          <Label >Subject <span className="text-destructive">*</span></Label>
          <Input />
        </div>
      </div>

      <div>
        <div className="flex flex-col gap-3">
          <Label >About Post </Label>
          <Textarea className="h-30" />
        </div>
      </div>
      <div className="flex flex-col gap-6 ">
        <div className="flex gap-4 w-full">
          <div className="w-1/4">
            <div className="flex flex-col gap-3 ">
              <Label >Property Type </Label>
              <Input />
            </div>
          </div>
          <div className="w-1/4">
            <div className="flex flex-col gap-3">
              <Label >Move-in Requirement </Label>
              <Input />
            </div>
          </div>
          <div className="w-1/2">
            <div className="flex flex-col gap-3">
              <Label >Location </Label>
              <Input />
            </div>
          </div>

        </div>
        <div className="flex gap-4 w-full">
          <div className="w-1/2">
            <div className="flex flex-col gap-3">
              <Label >Price: $0 - $10.000</Label>
              <Input />
            </div>
          </div>
          <div className="w-1/2">
            <div className="flex flex-col gap-3">
              <Label >Size: 20 SqFt - 2,000 SqFt</Label>
              <Input />
            </div>
          </div>
        </div>

        <div className="flex gap-4 w-full">
          <div className="w-1/4">
            <div className="flex flex-col gap-3 ">
              <Label >Rooms </Label>
              <Input />
            </div>
          </div>
          <div className="w-1/4">
            <div className="flex flex-col gap-3 ">
              <Label >Bathrooms </Label>
              <Input />
            </div>
          </div>
          <div className="w-1/4">
            <div className="flex flex-col gap-3 ">
              <Label >Bedrooms </Label>
              <Input />
            </div>
          </div>
          <div className="w-1/4">
            <div className="flex flex-col gap-3">
              <Label >Balcony</Label>
              <Input />
            </div>
          </div>
        </div>
        <div className="w-full flex flex-col gap-4">
          <h4>Amenities</h4>
          <div className="grid grid-cols-6 gap-4">
            <div className="flex gap-2">
              <Checkbox />
              <Label>Air Condition</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Cable TV</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Ceiling Height</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Ceiling Height</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Swimming Pool</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Car Parking</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Gym</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Garden Area</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Auditorium Hall</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>CCTV Camera</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Lift</Label>
            </div>
            <div className="flex gap-2">
              <Checkbox />
              <Label>Intercom</Label>
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-4 items-center justify-end">
        <Button>Clear All</Button>
        <Button>Post</Button>
      </div>
    </div>
  );
};
export default CreatePost;
// <div className="w-full mx-auto">
//       <div className="flex justify-between">
//         <div className="flex items-center justify-between mb-6 rounded-lg">
//           <h2 className="text-md font-bold text-gray-900">Posts</h2>
//           <span
//             className="ml-3"
//             style={{
//               backgroundColor: "#3352a4",
//               color: "#fff",
//               borderRadius: "50%",
//               fontSize: "12px",
//               padding: "0px 5px 0px 5px",
//             }}
//           >
//             2
//           </span>
//         </div>
//         <div className="flex border rounded-lg">
//           <Button
//             variant="ghost"
//             size="lg"
//             className="px-3 bg-blue-500 pl-3 pr-3"
//             style={{
//               borderRadius: "25px",
//               paddingLeft: "30px",
//               paddingRight: "30px",
//               color: "white",
//               backgroundColor: "#3352a4",
//             }}
//           >
//             <img src={IMAGES.add} alt="" />
//             Post
//           </Button>
//         </div>
//       </div>
//       <div className="space-y-6">
//         <div className="max-w-4xl mx-auto p-4 bg-white shadow-md rounded-lg">
//           {/* Subject */}
//           <h1 className="text-2xl font-bold mb-4">
//             Looking for 2BR apartment in downtown
//           </h1>

//           {/* About Post */}
//           <section className="mb-6">
//             <h2 className="text-lg font-semibold mb-2">About Post</h2>
//             <p className="text-foreground">
//               Young professional seeking a modern 2-bedroom apartment in
//               downtown area. Prefer high-rise buildings with city views
//               and modern amenities.
//             </p>
//           </section>

//           {/* Property Details */}
//           <section className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
//             <div>
//               <h3 className="text-sm font-semibold text-gray-600">
//                 Property Type
//               </h3>
//               <select className="w-full border border-gray-300 rounded-md px-3 py-2 mt-1">
//                 <option>Apartment</option>
//                 <option>House</option>
//                 <option>Studio</option>
//               </select>
//             </div>
//             <div>
//               <h3 className="text-sm font-semibold text-gray-600">
//                 Move-in Requirement
//               </h3>
//               <select className="w-full border border-gray-300 rounded-md px-3 py-2 mt-1">
//                 <option>Less Than 15 Days</option>
//                 <option>1 Month</option>
//                 <option>Flexible</option>
//               </select>
//             </div>
//           </section>

//           {/* Location and Price */}
//           <section className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
//             <div>
//               <h3 className="text-sm font-semibold text-gray-600">
//                 Location
//               </h3>
//               <input
//                 type="text"
//                 placeholder="Newcastle"
//                 className="w-full border border-gray-300 rounded-md px-3 py-2 mt-1"
//               />
//             </div>
//             <div>
//               <h3 className="text-sm font-semibold text-gray-600">
//                 Price
//               </h3>
//               <input
//                 type="text"
//                 placeholder="$0 - $10,000"
//                 className="w-full border border-gray-300 rounded-md px-3 py-2 mt-1"
//               />
//             </div>
//           </section>

//           {/* Additional Details */}
//           <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
//             {[
//               { label: "Rooms", value: 2 },
//               { label: "Bathrooms", value: 2 },
//               { label: "Size", value: "20 SqFt - 2,000 SqFt" },
//               { label: "Bedrooms", value: 2 },
//               { label: "Balcony", value: 2 },
//             ].map((item, index) => (
//               <div key={index}>
//                 <h3 className="text-sm font-semibold text-gray-600">
//                   {item.label}
//                 </h3>
//                 <input
//                   type="text"
//                   value={item.value}
//                   readOnly
//                   className="w-full border border-gray-300 rounded-md px-3 py-2 mt-1"
//                 />
//               </div>
//             ))}
//           </section>

//           {/* Amenities */}
//           <section className="mb-6">
//             <h2 className="text-lg font-semibold mb-2">Amenities</h2>
//             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-2">
//               {[
//                 "Air Condition",
//                 "Cable TV",
//                 "Ceiling Height",
//                 "Swimming Pool",
//                 "Gym",
//                 "Garden Area",
//                 "Auditorium Hall",
//                 "CCTV Camera",
//                 "Lift",
//                 "Car Parking",
//                 "Intercom",
//               ].map((amenity, index) => (
//                 <label
//                   key={index}
//                   className="flex items-center space-x-2"
//                 >
//                   <input
//                     type="checkbox"
//                     className="form-checkbox h-5 w-5 text-blue-500"
//                   />
//                   <span>{amenity}</span>
//                 </label>
//               ))}
//             </div>
//           </section>

//           {/* Clear All & Post Button */}
//           <div className="flex justify-between items-center mt-6">
//             <button className="px-6 py-2 bg-gray-300 text-foreground rounded-md hover:bg-gray-400">
//               Clear All
//             </button>
//             <button className="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
//               Post
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>