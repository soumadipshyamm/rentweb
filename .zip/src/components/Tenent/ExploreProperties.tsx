import React, { useState } from "react";
import { IMAGES } from "../../assets";
import { Filter, Grid, List, MapPin, Search } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Button } from "../ui/button";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import GoogleMapComponent from "../ChildComponent/GoogleMapComponent";
import PropertyHorizontal from "../ChildComponent/Common/PropertyHorizontal";
import Property from "../ChildComponent/Common/Property";
import { Card } from "../ui/card";

const ExploreProperties = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [requestSent, setRequestSent] = useState<{ [key: number]: boolean }>({});

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  const properties = [
    {
      id: 1,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "100 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 2,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$7501.00",
      beds: 4,
      baths: 3,
      sqft: "120 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: false,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 3,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 2,
      baths: 1,
      sqft: "80 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: false,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 4,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$750.00",
      beds: 3,
      baths: 2,
      sqft: "110 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: false,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 5,
      title: "Casa Lomas De Machail Machala",
      location: "Machala",
      price: "$751.00",
      beds: 3,
      baths: 2,
      sqft: "110 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
    {
      id: 6,
      title: "Casa Lomas De Machail Machala Casa Lomas De Machail Machala",
      location:
        "Premises no.03-319 Block, DH-6/11, Action Area 1D, Newtown, Kolkata, Chakpachuria, West Bengal 700160",
      price: "$752.00",
      beds: 3,
      baths: 2,
      sqft: "110 m²",
      image: IMAGES.villa_image, // Updated to use generated image
      featured: true,
      forRent: true,
      postedDate: "16 Aug 2025",
      type: "Appartment",
      status: "For Rent",
    },
  ];
  const propertyListings = [
    {
      id: 1,
      image: IMAGES.villa_image,
    },
    {
      id: 2,
      image: IMAGES.villa_image,
    },
    {
      id: 3,
      image: IMAGES.villa_image,
    },
    {
      id: 4,
      image: IMAGES.villa_image,
    },
    {
      id: 4,
      image: IMAGES.villa_image,
    },
  ];
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Duration for each slide (in milliseconds)
  };
  const [view, setView] = useState("horizontal");

  const [selectedId, setSelectedId] = useState<number | null>(null);

  const handleCardClick = (id: number) => {
    setSelectedId(selectedId === id ? null : id); // Toggle selection
  };
  const handleRequestClick = (id: number) => {
    setRequestSent((prev) => ({ ...prev, [id]: true })); // Mark request as sent for the specific property ID
  };
  return (
    <div className="common-container">
      <div className="w-full mx-auto">
        <div className="flex sm:flex-col lg:flex-row gap-8">
          {/* <!-- Property Listings --> */}
          <div className="lg:w-2/5">
            <div className="flex items-center justify-between mb-6 bg-white p-2 rounded-lg">
              <h2 className="text-md font-bold text-gray-900">
                254 properties
              </h2>
              <div className="flex items-center gap-1">
                <Select defaultValue="default">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    <SelectItem value="default">
                      Sort by Default
                    </SelectItem>
                    <SelectItem value="price-low">
                      Price: Low to High
                    </SelectItem>
                    <SelectItem value="price-high">
                      Price: High to Low
                    </SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex border rounded-lg">
                  <Button
                    variant="ghost"
                    size="sm"
                    id="vertical_view"
                    onClick={() => setView("vertical")}
                    className={`px-3 ${view === "vertical" ? "bg-blue-500" : ""
                      }`}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    id="horizontal_view"
                    onClick={() => setView("horizontal")}
                    className={`px-3 ${view === "horizontal" ? "bg-blue-500" : ""
                      }`}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {/* <!-- Horizontal Slider --> */}
              <div
                id="horizontal_slider"
                style={{
                  display: view === "horizontal" ? "block" : "none",
                  height: "500px",
                  overflowY: "auto",
                }}
              >
                {/* <Slider {...settingsHorizontal}> */}
                {properties.map((property) => (
                  <PropertyHorizontal
                    id={property.id}
                    title={property.title}
                    location={property.location}
                    price={property.price}
                    beds={property.beds}
                    baths={property.baths}
                    area={property.sqft}
                    image={property.image}
                    featured={property.featured}
                    forRent={property.forRent}
                    postedDate={property.postedDate}
                    type={property.type}
                    status={property.status}
                    isSelected={selectedId === property.id}
                    onCardClick={handleCardClick}
                  />
                ))}
                {/* </Slider> */}
              </div>

              {/* <!-- Vertical Slider --> */}
              <div
                id="vertical_slider"
                style={{
                  display: view === "vertical" ? "block" : "none",
                  height: "500px",
                  overflowY: "auto",
                }}
              >
                {/* <Slider {...settings}> */}
                <div className="grid grid-cols-2">
                  {properties.map((property) => (
                    <div
                      key={property.id}
                      className="px-2 col-span-1 mb-5"
                    >
                      <Property
                        id={property.id}
                        image={property.image}
                        type={property.type}
                        status={property.status}
                        location={property.location}
                        title={property.title}
                        beds={property.beds}
                        baths={property.baths}
                        sqft={property.sqft}
                        postedDate={property.postedDate}
                        price={property.price}
                        isSelected={selectedId === property.id}
                        onCardClick={handleCardClick}
                      />
                    </div>
                  ))}
                </div>
                {/* </Slider> */}
              </div>
            </div>
          </div>

          {/* <!-- Map --> */}
          <div
            className={`lg:w-3/5`}
            id={selectedId ? "propertyDetails" : "mapview"}
          >
            <div className="w-full mx-auto">
              {/* <!-- Search Filters --> */}
              <div className="rounded-lg mb-6 bg-white p-2">
                <div className="grid sm:grid-cols-1 md:grid-cols-2 gap-2 items-end">
                  <div>
                    <div className="relative">
                      <input
                        placeholder="Location"
                        className="h-10 w-20"
                      />
                      <MapPin className="absolute right-3 top-3 h-4 text-gray-400" />
                    </div>
                  </div>
                  <div>
                    <Select>
                      <SelectTrigger
                        className="w-full h-10"
                        style={{ boxShadow: "0px 0px" }}
                      >
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="house">House</SelectItem>
                        <SelectItem value="apartment">
                          Apartment
                        </SelectItem>
                        <SelectItem value="villa">Villa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {/* <div className="flex gap-2"> */}
                    <Button
                      variant="outline"
                      style={{
                        boxShadow: "0px 0px",
                        border: "1px solid blue",
                      }}
                      className="px-4 hover:bg-blue-700 rounded-[99px] h-10"
                    >
                      Search
                      <Search className="h-4 w-4" />
                    </Button>
                    <Button
                      className="hover:bg-blue-700 text-dark flex-1 rounded-[99px] h-10"
                      style={{
                        boxShadow: "0px 0px",
                        border: "1px solid blue",
                      }}
                    >
                      Search advanced
                      <Filter className="h-4 w-4 mr-2" />
                    </Button>
                  {/* </div> */}
                </div>
              </div>
            </div>
            {selectedId ? (
              // Find the selected property based on selectedId
              (() => {
                const selectedProperty = properties.find(
                  (property) => property.id === selectedId
                );
                return (
                  <div className="bg-white p-5 rounded-xl">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="[font-family:'Manrope',Helvetica] font-semibold text-[#1e1e1e] text-xl tracking-[0] leading-7">
                        {selectedProperty?.title &&
                          selectedProperty.title.length > 20
                          ? `${selectedProperty.title.slice(0, 20)}...`
                          : selectedProperty?.title}
                      </h3>
                      <div className="flex justify-between items-center gap-2">
                        <img src={IMAGES.fav} alt="" />
                        <img src={IMAGES.share} alt="" />
                      </div>
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex flex-wrap items-start sm:gap-2 md:gap-4">
                        <div className="flex items-center gap-1">
                          {/* <BedIcon className="w-4 h-4" /> */}
                          <img src={IMAGES.beds} alt="" />
                          <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                            Beds:
                          </span>
                          <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                            {selectedProperty?.beds}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          {/* <BathIcon className="w-4 h-4" /> */}
                          <img src={IMAGES.baths} alt="" />
                          <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                            Baths:
                          </span>
                          <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                            {selectedProperty?.baths}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          {/* <SquareIcon className="w-4 h-4" /> */}
                          <img src={IMAGES.sqft} alt="" />
                          <span className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                            Sqft:
                          </span>
                          <span className="[font-family:'Manrope',Helvetica] font-semibold text-[#333333] sm:text-xs md:text-sm tracking-[0] leading-[19.6px]">
                            {selectedProperty?.sqft}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div className="[font-family:'Manrope',Helvetica] font-bold text-primary sm:text-lg md:text-xl tracking-[0] leading-7">
                          {selectedProperty?.price}
                        </div>
                        <p>/month</p>
                      </div>
                    </div>
                    <div>
                      <div
                        className={`grid grid-cols-1 sm:gap-4 md:gap-6 sm:mb-8 md:mb-[52px]`}
                      >
                        <Slider {...settings}>
                          {propertyListings.map((property) => (
                            <div key={property.id} className="px-2">
                              <Card
                                key={property.id}
                                className="bg-white rounded-2xl overflow-hidden shadow-sm"
                              >
                                <div className="relative">
                                  <div
                                    className="w-full h-[180px] bg-cover bg-center relative"
                                    style={{
                                      backgroundImage: `url(${property.image})`,
                                    }}
                                  ></div>
                                </div>
                              </Card>
                            </div>
                          ))}
                        </Slider>
                      </div>
                      <div>
                        <Card
                          className={`overflow-hidden hover:shadow-lg transition-shadow p-5`}
                          style={{ border: "1px solid #1563DF54" }}
                        >
                          <h2
                            style={{
                              fontSize: "20px",
                              fontWeight: "700",
                            }}
                          >
                            Landlord Details
                          </h2>
                          <div className="flex mt-2 justify-between items-center">
                            <div className="relative flex items-center gap-3">
                              <img
                                src={
                                  IMAGES.user_img || "/placeholder.svg"
                                }
                                alt=""
                                className="w-18 h-18 object-cover"
                              />
                              <h2
                                style={{
                                  fontSize: "18px",
                                  fontWeight: "600",
                                }}
                              >
                                Landlord Details
                              </h2>
                            </div>
                            <div className="flex border rounded-lg">
                              <Button
                                variant="ghost"
                                size="lg"
                                className="px-3 bg-blue-500 pl-3 pr-3"
                                style={{
                                  borderRadius: "25px",
                                  paddingLeft: "30px",
                                  paddingRight: "30px",
                                  color: "white",
                                  backgroundColor: "#3352a4",
                                }}
                                onClick={() =>
                                  selectedProperty?.id !== undefined &&
                                  handleRequestClick(selectedProperty.id)
                                }
                                disabled={
                                  selectedProperty?.id !== undefined && requestSent[selectedProperty.id as number]
                                }
                              >
                                {selectedProperty?.id !== undefined && requestSent[selectedProperty.id as number]
                                  ? "Request Sent"
                                  : "Send Request"}
                              </Button>
                            </div>
                          </div>
                        </Card>
                      </div>
                    </div>
                  </div>
                );
              })()
            ) : (
              <GoogleMapComponent />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ExploreProperties;
