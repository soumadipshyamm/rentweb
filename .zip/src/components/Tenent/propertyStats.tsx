import React, { useState } from "react";
import { Card } from "../ui/card";
const PropertyStats = () => {
    return (
        <div className="flex flex-col w-full">
            <div className="border-b border-[#0000001A] py-4 px-2 flex">
                <Card>
                    
                </Card>
                <Card></Card>
                <Card></Card>
            </div>
            <div className="py-4 px-2 flex"></div>
        </div>
    )
}

export default PropertyStats;