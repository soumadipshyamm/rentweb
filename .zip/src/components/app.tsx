import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Landing from './ContentMangementSystem/screens/Landing/Landing';
import FindProperty from './ContentMangementSystem/screens/Landing/FindProperty';
import FindTenant from './ContentMangementSystem/screens/Landing/FindTenant';
import Login from './Auth/Login';
import 'tailwindcss'
import EmailVerification from './Auth/EmailVerification';
import Registration from './Auth/Registration';
import Dashboard from './Tenent/Dashboard';
import ExploreProperties from './Tenent/ExploreProperties';
import MyPost from './Tenent/Post/MyPost';
import CreatePost from './Tenent/Post/CreatePost';
import PostDetails from './Tenent/Post/PostDetails';
import Layout from './Layout';
import CMSLayout from './CMSLayout';
import AuthLayout from './AuthLayout';

const App: React.FC = () => {
  return (
    // <ThemeProvider theme={theme}>
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route element={<CMSLayout />} >
          <Route path="/" element={<Landing />} />
          <Route path="/find-property" element={<FindProperty />} />
          <Route path="/find-tenant" element={<FindTenant />} />
        </Route>

        <Route element={<AuthLayout />} >
          <Route path="/login" element={<Login />} />
          <Route path="/email-verification" element={<EmailVerification />} />
          <Route path="/registration" element={<Registration />} />
        </Route>

        <Route element={<Layout />} >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/explore-properties" element={<ExploreProperties />} />
          <Route path="/my-post" element={<MyPost />} />
          <Route path="/create-post" element={<CreatePost />} />
          <Route path="/post-details" element={<PostDetails />} />
        </Route>
      </Routes>
    </Router>
    // {/* </ThemeProvider> */}
  );
}

export default App;
