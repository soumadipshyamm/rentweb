import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation
import { Card, CardContent } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Eye, EyeOff } from "lucide-react";

type registrationSchema = {
  "role": string,
    "first_name": string,
    "middle_name": string,
    "last_name": string,
    "password": string,
    "email": string,
    "gender": string,
    "phone_number" : string,
    "confirm_password" : string
}

const Registration = () => {
    const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState("steve.smith@gamil.com");
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [confirmpassword, setConfirmPassword] = useState("steve.smith@gamil.com");
  const navigate = useNavigate(); // Initialize navigate for redirection
  const [registrationPayload, setRegistrationPayload] = useState<registrationSchema>({
    "role": "TENANT",
    "first_name": "",
    "middle_name": "",
    "last_name": "",
    // "user_name": "212w3ws3u",
    "password": "",
    "confirm_password" : "",
    "email": "",
    "gender": "",
    // "address_line_1": "kolkata",
    // "address_line_2": "kolkata",
    // "city": "kolkata",
    // "state": "WB",
    // "country": "I",
    // "zip": "700001",
    // "date_of_birth": "2022-09-11",
    // "contact_label": "HOME",
    "phone_number": "",
    // "phone_extension": "91"
})

  const handleVerifyOtp = () => {
    // Logic to verify the OTP can be added here
    navigate("/dashboard"); // Redirect to /dashboard
  };

  useEffect(() => {
    const userInfo = JSON.parse((localStorage?.getItem("userInfo") || ''));
    console.log("userInfo : ", userInfo);
    setRegistrationPayload(prev => ({...prev, email: userInfo?.email, role : userInfo?.role}))
    
  }, [])

  const handleChange = (e : any) => {
    setRegistrationPayload(prev => ({...prev, [e?.target?.name] : e?.target?.value}))
  }

  return (
      <main className="flex-1 flex items-center justify-center px-4 py-5">
        <div className="w-full max-w-2xl">
          <div className="text-center mb-4">
            <p className="text-sm text-primary uppercase tracking-wide mb-2">
              WELCOME
            </p>
            <h1 className="text-3xl font-bold text-gray-900">
              Create an Account
            </h1>
          </div>

          <Card className="overflow-hidden shadow-lg bg-background">
            <CardContent className="p-0">
              <div className="flex flex-col justify-center p-7">
                <div className="w-full mx-auto space-y-6">
                  <div className="space-y-1">
                    <label
                      htmlFor="email"
                      className="text-sm font-medium text-foreground"
                    >
                      Your Name *
                    </label>
                    <Input
                      id="name"
                      type="name"
                      name="name"
                      value={registrationPayload?.first_name + " " + registrationPayload?.last_name}
                      className="h-10 text-base"
                      placeholder="Enter your name"
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex items-center gap-5">
                    <div className="space-y-1 w-full">
                      <label
                        htmlFor="email"
                        className="text-sm font-medium text-foreground"
                      >
                        Your Gender *
                      </label>
                      <Input
                        id="name"
                        type="name"
                        name="gender"
                        value={registrationPayload?.gender}
                        className="h-10 text-base"
                        placeholder="Enter your name"
                      />
                    </div>
                    <div className="space-y-1 w-full">
                      <label
                        htmlFor="email"
                        className="text-sm font-medium text-foreground"
                      >
                        Mobile Number *
                      </label>
                      <Input
                        id="name"
                        type="number"
                        className="h-10 text-base"
                        placeholder="Enter mobile number"
                        value={registrationPayload?.phone_number}
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-5">
                    <div className="space-y-1 w-full">
                      <label
                        htmlFor="email"
                        className="text-sm font-medium text-foreground"
                      >
                        Password *
                      </label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          name="password"
                          value={registrationPayload?.password}
                          onChange={handleChange}
                          className="h-12 text-base pr-12"
                          placeholder="Enter your password"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          
                          className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                          onClick={handleChange}
                        >
                          {showPassword ? (
                            <Eye className="h-4 w-4 text-gray-400" />
                          ) : (
                            <EyeOff className="h-4 w-4 text-gray-400" />
                          )}
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-1 w-full">
                      <label
                        htmlFor="email"
                        className="text-sm font-medium text-foreground"
                      >
                        Confirm Password *
                      </label>
                      <div className="relative">
                        <Input
                          id="confirmpassword"
                          type={showConfirmPassword ? "text" : "password"}
                          name="confirm_password"
                          value={registrationPayload?.confirm_password}
                          onChange={handleChange}
                          className="h-12 text-base pr-12"
                          placeholder="Enter your password"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        >
                          {showConfirmPassword ? (
                            <Eye className="h-4 w-4 text-gray-400" />
                          ) : (
                            <EyeOff className="h-4 w-4 text-gray-400" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-center mb-2">
                    <Button
                      onClick={handleVerifyOtp}
                      className="flex items-center justify-center gap-2 w-[154px] h-[54px] px-5 py-[11px] bg-primary rounded-full border border-solid hover:bg-muted h-auto"
                    >
                      <span className="sm:hidden md:inline [font-family:'Manrope',Helvetica] font-semibold text-background text-base tracking-[0] leading-[normal]">
                        Create Account
                      </span>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
  );
};

export default Registration;
