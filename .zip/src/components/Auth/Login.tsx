import React, { useState } from "react";
import { IMAGES } from "../../assets/index";
import { Card, CardContent } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Eye, EyeOff } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { signinSchema, SigninSchemaType } from "../../schemas/auth";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { loginMember } from "../../actions/auth";
import { toast } from "../../custom-hooks/use-toast";
import Icon from "../icons/icon";
import { useNavigate } from "react-router-dom";

type logInSchema = {
  email: string,
  password: string,
  role: "TENANT"
}

const Login = () => {
  const navigate = useNavigate()
  const [showPassword, setShowPassword] = useState(false);

  const {
    register: loginPayload,
    handleSubmit,
    formState: { errors },
  } = useForm<SigninSchemaType>({
    resolver: zodResolver(signinSchema),
  });

  const { mutate: login, isPending } = useMutation({
    mutationFn: loginMember,
    onSuccess: (data) => {
      navigate("/dashboard")
      // localStorage.setItem('access_token', data?.tokens?.access);
      // localStorage.setItem('refresh_token', data?.tokens.refresh);
      // localStorage.setItem('user', JSON.stringify(data?.userdata));
      // localStorage.setItem('showWelcome', true);
      // navigate('/admin');
    },
    onError: (error: any) => {
      // setServerError(error.response?.err?.detail || 'Login failed');
      console.log("error ::: ", error?.response?.data?.err?.details[0]?.message);

      toast({
        title: "Error",
        description: 'Login failed',
        variant: "error",
      });
    },
  });

  const onSubmit = (data: SigninSchemaType) => {
    console.log("Form Data:", data);
    login({ ...data, role: "TENANT" } as logInSchema);
  };

  return (

    <main className="flex-1 flex items-center justify-center px-4 sm:py-10 md:pb-20 2xl:py-5">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-4">
          <p className="text-sm text-gray-600 uppercase tracking-wide mb-2">
            WELCOME
          </p>
          <h1 className="text-3xl font-bold text-gray-900">
            Login Into Your Account
          </h1>
        </div>

        <Card className="overflow-hidden shadow-lg bg-background">
          <CardContent className="p-0">
            <div className="flex sm:flex-col lg:flex-row">
              <div className="lg:w-2/5 sm:hidden lg:block relative">
                <img
                  src={IMAGES.login_image}
                  alt="Professional working at desk"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="lg:w-3/5 flex flex-col justify-center p-5">
                <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-sm mx-auto flex flex-col space-y-6">
                  <div className="">
                    <div className="flex flex-col gap-3">
                      <label
                        htmlFor="email"
                        className="text-sm font-medium text-foreground"
                      >
                        Email ID <span className="text-sm text-destructive-foreground">*</span>
                      </label>
                      <div className="relative">
                        <Input
                          id="email"
                          type="email"
                          // name="email"
                          {...loginPayload("email")}
                          // value={loginPayload?.email}
                          // onChange={(e) => setEmail(e.target.value)}
                          className="h-12 pl-7 text-md py-0"
                          placeholder="Enter your email"
                        // required
                        />
                        <Icon name="Email" className="w-3 h-3 absolute top-1/2 -translate-y-1/2 left-2" />

                      </div>
                    </div>
                    {errors.email && <p className="mt-2 text-xs text-destructive-foreground font-medium pl-2">{errors.email.message}</p>}
                  </div>
                  <div className="">
                    <div className="flex flex-col gap-3">
                      <label
                        htmlFor="password"
                        className="text-sm font-medium text-foreground"
                      >
                        Password <span className="text-sm text-destructive-foreground">*</span>
                      </label>
                      <div className="relative">
                        <Input
                          id="password"
                          {...loginPayload("password")}
                          // name="password"
                          type={showPassword ? "text" : "password"}
                          // value={loginPayload?.password}
                          // onChange={(e) => handleChange}
                          className="h-12 text-base pr-12"
                          placeholder="Enter your password"
                        // required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <Eye className="h-4 w-4 text-gray-400" />
                          ) : (
                            <EyeOff className="h-4 w-4 text-gray-400" />
                          )}
                        </Button>
                      </div>
                    </div>
                    {errors.password && <p className="mt-2 text-xs text-destructive-foreground font-medium pl-2">{errors.password.message}</p>}
                  </div>
                  <div className="text-right mb-2">
                    <a
                      href="#"
                      className="text-sm text-blue-600 hover:text-blue-800 transition-colors"
                    >
                      Forgot password?
                    </a>
                  </div>

                  <div className="flex justify-center mb-2">
                    <Button
                      type="submit"
                      className="flex items-center justify-center gap-2 w-[154px] h-[54px] px-5 py-[11px] bg-primary rounded-full border border-solid hover:bg-muted h-auto"
                    >
                      <span className="sm:hidden md:inline [font-family:'Manrope',Helvetica] font-semibold text-background text-base tracking-[0] leading-[normal]">
                        Login
                      </span>
                    </Button>
                  </div>
                  <div className="text-center mb-0 mt-2">
                    Don't have an account?
                    <a
                      href="/email-verification"
                      className="text-sm text-black-600 hover:text-blue-800 transition-colors ml-2 underline" style={{ fontWeight: "bold" }}
                    >
                      Register
                    </a>
                  </div>
                </form>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>

  );
};

export default Login;
