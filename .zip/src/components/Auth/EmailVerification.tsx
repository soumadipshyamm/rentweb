import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation
import { IMAGES } from "../../assets/index";
import { Card, CardContent } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Label } from "@radix-ui/react-label";
import Icon from "../icons/icon";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { toast } from "../../custom-hooks/use-toast";
import { verifyMember } from "../../actions/auth";

type getOtpSchema = {
  email: string,
  role: "TENANT" | "LANDLORD" | "PROPERTY MANAGER",
  type: string,
  otp?: string
}

type verifyOtpSchema = {
  email: string,
  role: "TENANT" | "LANDLORD" | "PROPERTY MANAGER",
  type: string,
  otp: string
}

interface EmailVerificationProps {
  onChange?: (value: string) => void;
}

const EmailVerification: React.FC<EmailVerificationProps> = ({ onChange }) => {
  const inputsRef = useRef<Array<any>>([]);
  const [otp, setOtp] = useState(Array(4).fill(""));
  const [timeLeft, setTimeLeft] = useState<number>(300); // 5 minutes = 300 seconds
  const [otpVisible, setOtpVisible] = useState<boolean>(false); // To control OTP input visibility
  const [buttonText, setButtonText] = useState<string>("Get OTP"); // Button text state
  const [otpDisabled, setOtpDisabled] = useState<boolean>(true); // To control OTP input field disabled state
  const navigate = useNavigate(); // Initialize navigate for redirection
  const [getOtpPayload, setGetOtpPayload] = useState<getOtpSchema>({ role: "TENANT", email: "", type: "email", otp: "" })
  const [verifyOtpPayload, setVerifyOtpPayload] = useState<verifyOtpSchema>({ role: "TENANT", email: "", "type": "otp", otp: "" })

  const { mutate: getOtp, isPending } = useMutation({
    mutationFn: verifyMember,
    onSuccess: (data) => {
      if (getOtpPayload?.type === "email") {
        setGetOtpPayload(prev => ({...prev, type: "otp"}))
        setOtpVisible(true); // Show OTP input
        setButtonText("Verify OTP"); // Change button text to "Verify OTP"
        setOtpDisabled(false); // Enable OTP input fields
      }
      console.log("getOtpPayload?.type ::: ", getOtpPayload?.type);
      
      if (getOtpPayload?.type === "otp") {
        console.log("data :: ", data)
        localStorage.setItem("userInfo", JSON?.stringify(data?.result))
        navigate("/registration");
      }
    },
    onError: (error: any) => {
      // setServerError(error.response?.err?.detail || 'Login failed');
      console.log("error ::: ", error?.response?.data?.err?.details[0]?.message);

      toast({
        title: "Error",
        description: 'Verificatopn failed',
        variant: "error",
      });
    },
  });

  useEffect(() => {
    let timerId: NodeJS.Timeout;
    if (timeLeft > 0) {
      timerId = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1);
      }, 1000);
    }

    // Cleanup the interval on component unmount
    return () => clearInterval(timerId);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}.${secs < 10 ? "0" : ""}${secs}`; // Format as MM.SS
  };

  const handleGetOtp = () => {
    getOtp(getOtpPayload)

  };


  const handleChange = (e: any) => {
    console.log("[e?.target?.name] : e.target.value", { [e?.target?.name]: e.target.value });

    setGetOtpPayload(prev => ({ ...prev, [e?.target?.name]: e.target.value }));

  }

  const handleChangeOtp = (e: any, index: number) => {
    const value = e.target.value;
    if (!/^[0-9]?$/.test(value)) return; // allow only one digit number

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Move to next input if not last and value entered
    if (value && index < length - 1) {
      inputsRef.current[index + 1].focus();
    }

    onChange?.(newOtp.join(""));
  }

  const handleKeyDown = (e: any, index: number) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputsRef.current[index - 1].focus();
    }
  };

  const handleVerifyOtp = () => {
    getOtp({ ...getOtpPayload, otp: otp?.join('') })
    // navigate("/registration");
  };


  return (
    // <div className="w-full bg-[#f3f7fd]">
    //   <Navbar />

    <main className="flex-1 flex items-center justify-center px-4 py-5">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-4">
          <p className="text-sm text-primary uppercase tracking-wide mb-2">
            WELCOME
          </p>
          <h1 className="text-3xl font-bold text-gray-900">
            Create an Account
          </h1>
        </div>

        <Card className="overflow-hidden shadow-lg bg-background">
          <CardContent className="p-0">
            <div className="flex flex-col justify-center p-7">
              <div className="w-full mx-auto space-y-6">
                <div className="flex flex-col gap-3">
                  <Label
                    htmlFor="role"
                    className="text-sm font-semibold text-foreground"
                  >
                    I Will Join As
                  </Label>
                  <div className="flex gap-10 items-center">
                    <Label className="flex items-center gap-2 cursor-pointer">
                      <Input id="type" type="radio" className="h-4" name="role" value="TENANT" onChange={handleChange} />
                      <span className="font-semibold text-primary-foreground">Tenant</span>
                    </Label>
                    <Label className="flex items-center gap-2 cursor-pointer">
                      <Input id="type" type="radio" className="h-4" name="role" value="LANDLORD" onChange={handleChange} />
                      <span className="font-semibold text-primary-foreground">Landlord</span>
                    </Label>
                    <Label className="flex items-center gap-2 cursor-pointer">
                      <Input id="type" type="radio" className="h-4" name="role" value="PROPERTY MANAGER" onChange={handleChange} />
                      <span className="whitespace-nowrap text-ellipsis font-semibold text-primary-foreground">Property Manager</span>
                    </Label>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <label
                    htmlFor="email"
                    className="text-sm font-semibold text-foreground"
                  >
                    Email ID *
                  </label>
                  <div className="relative">
                    <Input
                      id="email"
                      type="email"
                      name="email"
                      value={getOtpPayload?.email}
                      onChange={handleChange}
                      className="h-12 text-md pl-7"
                      placeholder="Enter your email"
                    />
                  </div>
                  <Icon name="Email" className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2" />
                </div>

                {otpVisible && (
                  <div className="space-y-1" id="otpinput">
                    <div className="flex">
                      <div className="w-full">
                        <label
                          htmlFor="otp"
                          className="text-sm font-medium text-foreground"
                        >
                          We sent a 4-digit OTP to your email ID
                        </label>
                        <div className="flex items-center gap-2">
                          <p className="big-text" id="useremail">
                            {getOtpPayload?.email}
                          </p>
                          <a href="#">
                            <img
                              src={IMAGES.edit}
                              alt=""
                              className="w-4 h-4"
                            />
                          </a>
                        </div>
                      </div>
                      <div className="w-full flex items-center gap-5">
                        {/* <div className="flex items-center gap-2">
                        <Input
                          id=""
                          type="text"
                          className="h-12 w-12 text-base"
                          placeholder="X"
                          disabled={otpDisabled}
                        />
                        <Input
                          id=""
                          type="text"
                          className="h-12 w-12 text-base"
                          placeholder="X"
                          disabled={otpDisabled}
                        />
                        <Input
                          id=""
                          type="text"
                          className="h-12 w-12 text-base"
                          placeholder="X"
                          disabled={otpDisabled}
                        />
                        <Input
                          id=""
                          type="text"
                          className="h-12 w-12 text-base"
                          placeholder="X"
                          disabled={otpDisabled}
                        />
                      </div> */}
                        <div className="flex gap-4 items-center justify-center mt-4">
                          {otp.map((value: string, index: number) => (
                            <div key={index} className="flex flex-col items-center">
                              <Label htmlFor={`otp-${index}`} className="sr-only">
                                OTP {index + 1}
                              </Label>
                              <Input
                                id={`otp-${index}`}
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                maxLength={1}
                                className="w-12 h-12 text-center text-lg font-semibold border border-input rounded-md focus:ring-2 focus:ring-primary"
                                value={value}
                                onChange={(e) => handleChangeOtp(e, index)}
                                onKeyDown={(e) => handleKeyDown(e, index)}
                                ref={(el) => { inputsRef.current[index] = el; }}
                              />
                            </div>
                          ))}
                        </div>
                        <div className="flex items-center gap-2">
                          <img src={IMAGES.watch} alt="" />
                          {/* Displaying the countdown timer */}
                          <p style={{ color: "#38AC79" }} id="countdown">
                            {formatTime(timeLeft)}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex justify-center mb-2">
                  <Button
                    onClick={
                      buttonText === "Get OTP"
                        ? handleGetOtp
                        : handleVerifyOtp
                    }
                    className="flex items-center justify-center gap-2 w-[154px] h-[54px] px-5 py-[11px] bg-primary rounded-full border border-solid hover:bg-muted h-auto"
                  >
                    <span className="sm:hidden md:inline [font-family:'Manrope',Helvetica] font-semibold text-background text-base tracking-[0] leading-[normal]">
                      {buttonText}
                    </span>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>

    //   <Footer />
    // </div>
  );
};

export default EmailVerification;
