import React from "react";
import { Calendar, EllipsisVertical, MapPin } from "lucide-react";
import { Button } from "../../ui/button";
import { Card, CardContent } from "../../ui/card";
import { IMAGES } from "../../../assets/index";
import ToggleButton from "../ToggleButton";
import { useNavigate } from "react-router-dom";

type PostProps = {
  id: string | number;
  title: string;
  description: string;
  type: string;
  location: string;
  sqft: string;
  beds: number;
  baths: number;
  image: string;
  postedDate: string;
  price: string | number;
  featured: boolean;
  forRent: boolean;
  isUrgent: boolean;
  responseQty: number;
};

const Post: React.FC<PostProps> = ({
  id,
  title,
  description,
  location,
  price,
  beds,
  baths,
  sqft,
  image,
  featured,
  forRent,
  postedDate,
  type,
  isUrgent,
  responseQty,
}) => {
  const navigate = useNavigate();
  return (
    <Card
      key={id}
      className={`overflow-hidden hover:shadow-lg bg-white transition-shadow mb-5 p-2`}
    >
      <div className="flex justify-between">
        <CardContent className="flex-1 p-2">
          <div className="flex items-center gap-3">
            <h3 className="font-semibold text-gray-900 text-lg">
              {title.length > 50 ? `${title.slice(0, 50)}...` : title}
            </h3>
            {isUrgent && (
              <p
                className="[font-family:'Manrope',Helvetica] font-medium"
                style={{
                  border: "1px solid #C10664",
                  padding: "0px 10px",
                  fontSize: "11px",
                  borderRadius: "12px",
                  backgroundColor: "#C10664",
                  color: "#fff",
                }}
              >
                Urgent
              </p>
            )}
          </div>
          <p
            className="[font-family:'Manrope',Helvetica]"
            style={{ fontSize: "12px" }}
          >
            {description.length > 150
              ? `${description.slice(0, 150)}...`
              : description}
          </p>

          <div className="flex items-center mb-3 mt-2 gap-10">
            <div className="flex items-center text-gray-600">
              <MapPin className="h-3 w-3 mr-1" />
              <span className="" style={{ fontSize: "12px" }}>
                {location.length > 35
                  ? `${location.slice(0, 35)}...`
                  : location}
              </span>
            </div>
            <div className="flex items-center text-gray-600">
              <Calendar className="h-4 w-4 mr-1" />
              <span className="" style={{ fontSize: "12px" }}>
                {postedDate}
              </span>
            </div>
          </div>
          <div className="flex flex-wrap items-start sm:gap-10 md:gap-10">
            <div className="flex items-center gap-1">
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                Price:
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                {price}
              </span>
            </div>

            <div
              className="flex items-center gap-1"
              style={{
                borderLeft: "1px solid #8a72af",
                paddingLeft: "30px",
              }}
            >
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                Property Type:
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                {type}
              </span>
            </div>

            <div
              className="flex items-center gap-1"
              style={{
                borderLeft: "1px solid #8a72af",
                paddingLeft: "30px",
              }}
            >
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                Size:
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                {sqft}
              </span>
            </div>

            <div
              className="flex items-center gap-1"
              style={{
                borderLeft: "1px solid #8a72af",
                paddingLeft: "30px",
              }}
            >
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                No Of Bed Rooms -
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                {beds}
              </span>
            </div>

            <div
              className="flex items-center gap-1"
              style={{
                borderLeft: "1px solid #8a72af",
                paddingLeft: "30px",
              }}
            >
              <span
                className="[font-family:'Manrope',Helvetica] font-normal text-on-suface-variant-1 tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                No Of Bathroom -
              </span>
              <span
                className="[font-family:'Manrope',Helvetica] font-semibold text-primary tracking-[0] leading-[19.6px]"
                style={{ fontSize: "12px" }}
              >
                {baths}
              </span>
            </div>
          </div>
        </CardContent>
        <div
          className="pl-4"
          style={{
            borderLeft: "1px solid #0000001A",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <div className="[font-family:'Manrope',Helvetica] text-[#1e1e1e] sm:text-sm md:text-md tracking-[0] leading-[25.2px]">
                Status
              </div>
              <ToggleButton defaultToggled={isUrgent}/>
            </div>
            <a href="">
              <EllipsisVertical style={{ color: "rgb(0 0 0 / 35%)" }} />
            </a>
          </div>
          <div className="flex items-center gap-2">
            <img src={IMAGES.chat} alt="" />
            <div className="[font-family:'Manrope',Helvetica] text-primary sm:text-md md:text-md tracking-[0] leading-[25.2px]">
              {responseQty} Responses
            </div>
          </div>
          <div className="">
            <Button
              onClick={() => navigate("/post-details")}
              variant="outline"
              style={{
                boxShadow: "0px 0px",
                border: "1px solid #3352a4",
                color: "#3352a4",
              }}
              className="px-4 hover:bg-primary rounded-[99px] h-10"
            >
              View Details
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default Post;
