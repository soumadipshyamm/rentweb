import React, { useState } from 'react';

// const ToggleButton: React.FC = () => {
//     const [isToggled, setIsToggled] = useState<boolean>(false);

//     const toggle = () => {
//         setIsToggled(!isToggled);
//     };
interface ToggleButtonProps {
    defaultToggled: boolean;
}

const ToggleButton: React.FC<ToggleButtonProps> = ({ defaultToggled }) => {
    const [isToggled, setIsToggled] = useState<boolean>(defaultToggled);

    const toggle = () => {
        setIsToggled(!isToggled);
    };
    return (
        <button
            onClick={toggle}
            className={`flex items-center w-10 h-5 rounded-full transition-colors duration-300 
                ${isToggled ? 'bg-blue-500' : 'bg-gray-300'}`}
        >
            <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-300 
                    ${isToggled ? 'translate-x-5' : 'translate-x-0'}`}
            />
        </button>
    );
};

export default ToggleButton;
