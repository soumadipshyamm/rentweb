import { z } from "zod";

export const signinSchema = z.object({
    email: z.string()
        .email({ message: "Invalid email address" }),
  
    password: z.string()
        .min(8, "Password must be at least 8 characters")
        // .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/, 
        // "Password must contain uppercase, lowercase, number, and special character"),
})

export type SigninSchemaType = z.infer<typeof signinSchema>;
