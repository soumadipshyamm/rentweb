// webpack.config.js
import path from "path";
import HtmlWebpackPlugin from "html-webpack-plugin";
import webpack from "webpack";
import dotenv from "dotenv";
import process from "process";

dotenv.config(); // ✅ loads .env
export default {
  entry: "./src/index.tsx",

  output: {
    path: path.resolve("dist"),
    filename: "bundle.[contenthash].js",
    assetModuleFilename: "assets/[hash][ext][query]",
    clean: true,
  },

  module: {
    rules: [
      // 🧠 Handle TypeScript/JSX
      {
        test: /\.[jt]sx?$/,
        exclude: /node_modules/,
        use: "babel-loader",
      },

      // 🖼️ Handle Images (PNG, JPG, GIF, SVG)
      {
        test: /\.(png|jpe?g|gif|svg)$/i,
        type: "asset/resource",
      },

      // 💅 Handle CSS
      {
        test: /\.css$/i,
        oneOf: [
          {
            exclude: /node_modules/,
            use: [
              "style-loader",
              {
                loader: "css-loader",
                options: { importLoaders: 1 },
              },
              "postcss-loader",
            ],
          },
          {
            include: /node_modules/,
            use: ["style-loader", "css-loader"],
          },
        ],
      }
    ],
  },

  resolve: {
    extensions: [".tsx", ".ts", ".js"],
    fallback: {
      process: "process/browser.js",
      util: "util/",
      buffer: "buffer/",
    },
  },


  plugins: [
    new HtmlWebpackPlugin({
      template: "./public/index.html",
    }),
    new webpack.DefinePlugin({
      "process.env.REACT_APP_PUBLIC_API_URL": JSON.stringify(process.env.REACT_APP_PUBLIC_API_URL),
    }),
    new webpack.ProvidePlugin({
      process: "process/browser.js",
      Buffer: ["buffer", "Buffer"],
    }),
  ],

  devServer: {
    port: 3000,
    open: true,
    historyApiFallback: true,
  },

  mode: "development",
};
