/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
      },
    },
  },
  plugins: [require("tailwindcss-animate"), require('tailwind-scrollbar-hide'), require('tailwind-scrollbar')({ nocompatible: true })],
};
