// export default {
//   plugins: {
//     '@tailwindcss/postcss': {},
//     autoprefixer: {},
//   },
// };
// postcss.config.cjs
// module.exports = {
//   plugins: [
//     require("tailwindcss"),
//     require("autoprefixer"),
//   ],
// };
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};


